import React from 'react';
import { ForensicExport } from '../../types';

interface ExportsTableProps {
  lang: 'ar' | 'en';
  exportsData: ForensicExport[];
}

const ExportsTable: React.FC<ExportsTableProps> = ({ lang, exportsData }) => (
  <div className="rounded-[2rem] bg-white border border-slate-100 p-5 shadow-sm space-y-3" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
    <h4 className="text-lg font-black text-slate-900">
      {lang === 'ar' ? 'سجل التصدير' : 'Exports Table'}
    </h4>
    <div className="space-y-2">
      {exportsData.map((entry) => (
        <div key={entry.export_id} className="rounded-xl border border-slate-100 bg-slate-50 p-3">
          <p className="text-sm font-black text-slate-900">{entry.export_id}</p>
          <p className="text-[11px] font-bold text-slate-600">{entry.incident_id}</p>
          <p className="text-[11px] font-mono text-slate-500 break-all">{entry.sha256_hash}</p>
        </div>
      ))}
      {exportsData.length === 0 && (
        <p className="text-sm font-bold text-slate-400 text-center py-4">
          {lang === 'ar' ? 'لا توجد عمليات تصدير.' : 'No exports yet.'}
        </p>
      )}
    </div>
  </div>
);

export default ExportsTable;
