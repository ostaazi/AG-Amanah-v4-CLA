import React from 'react';

interface CreateExportButtonProps {
  lang: 'ar' | 'en';
  onCreate: () => void;
}

const CreateExportButton: React.FC<CreateExportButtonProps> = ({ lang, onCreate }) => (
  <button
    onClick={onCreate}
    className="w-full py-3 rounded-xl bg-indigo-600 text-white font-black text-sm shadow"
  >
    {lang === 'ar' ? 'إنشاء تصدير جديد' : 'Create New Export'}
  </button>
);

export default CreateExportButton;
