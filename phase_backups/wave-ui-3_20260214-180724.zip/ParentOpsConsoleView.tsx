import React, { useEffect, useMemo, useState } from 'react';
import {
  Child,
  DeviceCommandAudit,
  EvidenceCustody,
  ForensicExport,
  IncidentReport,
  MonitoringAlert,
  ParentAccount,
} from '../../types';
import { fetchCustodyByIncident, logAuditEvent, sendRemoteCommand, subscribeToAuditLogs } from '../../services/firestoreService';
import { sovereignApi } from '../../services/sovereignApiService';
import { generateSHA256 } from '../../services/forensicsService';
import ParentSidebar from './ParentSidebar';
import DeviceCommandsDashboard from './DeviceCommandsDashboard';
import DeviceCommandControl from './DeviceCommandControl';
import CommandsStatusTable from './CommandsStatusTable';
import IncidentsTable from './IncidentsTable';
import IncidentDetailsTabs from './IncidentDetailsTabs';
import NotificationCenterView from './NotificationCenterView';
import ParentEvidenceVaultView from './EvidenceVaultView';
import CreateExportButton from './CreateExportButton';
import ExportsTable from './ExportsTable';
import HashVerifier from './HashVerifier';
import CustodyTimeline from './CustodyTimeline';
import ParentSafetyPlaybookHub from './SafetyPlaybookHub';

interface ParentOpsConsoleViewProps {
  lang: 'ar' | 'en';
  currentUser: ParentAccount;
  children: Child[];
  alerts: MonitoringAlert[];
}

type OpsTab =
  | 'commands'
  | 'incidents'
  | 'notifications'
  | 'evidence'
  | 'exports'
  | 'custody'
  | 'verify'
  | 'playbooks';

const ParentOpsConsoleView: React.FC<ParentOpsConsoleViewProps> = ({
  lang,
  currentUser,
  children,
  alerts,
}) => {
  const [tab, setTab] = useState<OpsTab>('commands');
  const [logs, setLogs] = useState<DeviceCommandAudit[]>([]);
  const [selectedIncidentId, setSelectedIncidentId] = useState('');
  const [custodyRows, setCustodyRows] = useState<EvidenceCustody[]>([]);
  const [exportsData, setExportsData] = useState<ForensicExport[]>([]);

  const incidents = useMemo(
    () => sovereignApi.listIncidentsFromAlerts(alerts, children),
    [alerts, children]
  );
  const selectedIncident: IncidentReport | null = useMemo(() => {
    if (!incidents.length) return null;
    if (!selectedIncidentId) return incidents[0];
    return incidents.find((x) => x.incident_id === selectedIncidentId) || incidents[0];
  }, [incidents, selectedIncidentId]);

  useEffect(() => {
    setSelectedIncidentId((prev) => prev || incidents[0]?.incident_id || '');
  }, [incidents]);

  useEffect(() => {
    const unsub = subscribeToAuditLogs(currentUser.id, (rows) => setLogs(rows));
    return () => unsub();
  }, [currentUser.id]);

  useEffect(() => {
    let active = true;
    const load = async () => {
      if (!selectedIncident?.incident_id) {
        setCustodyRows([]);
        return;
      }
      const incidentKey = selectedIncident.incident_id.replace(/^INC-/, '');
      const rows = await fetchCustodyByIncident(currentUser.id, incidentKey);
      if (!active) return;
      setCustodyRows(rows);
    };
    load();
    return () => {
      active = false;
    };
  }, [currentUser.id, selectedIncident?.incident_id]);

  const onSendCommand = async (childId: string, command: string, payload?: any) => {
    const createdAt = new Date().toISOString();
    const commandId = `cmd-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    await logAuditEvent(currentUser.id, {
      command_id: commandId,
      child_id: childId,
      actor_user_id: currentUser.id,
      actor_role: currentUser.role,
      command_type: command,
      payload: payload || true,
      status: 'queued',
      created_at: createdAt,
      updated_at: createdAt,
    });
    try {
      await sendRemoteCommand(childId, command, payload ?? true);
      await logAuditEvent(currentUser.id, {
        command_id: commandId,
        child_id: childId,
        actor_user_id: currentUser.id,
        actor_role: currentUser.role,
        command_type: command,
        payload: payload || true,
        status: 'acked',
        created_at: createdAt,
        updated_at: new Date().toISOString(),
      });
    } catch (error: any) {
      await logAuditEvent(currentUser.id, {
        command_id: commandId,
        child_id: childId,
        actor_user_id: currentUser.id,
        actor_role: currentUser.role,
        command_type: command,
        payload: payload || true,
        status: 'failed',
        error_message: String(error?.message || 'Unknown error'),
        created_at: createdAt,
        updated_at: new Date().toISOString(),
      });
    }
  };

  const createExport = async () => {
    const incident = selectedIncident;
    if (!incident) return;
    const digest = await generateSHA256(`${incident.incident_id}:${Date.now()}:${currentUser.id}`);
    const row: ForensicExport = {
      export_id: `EXP-${Math.random().toString(36).slice(2, 10).toUpperCase()}`,
      incident_id: incident.incident_id,
      generated_at: new Date().toISOString(),
      sha256_hash: digest,
      status: 'READY',
      metadata: {
        examiner: currentUser.name,
        classification: 'LEGAL_HOLD',
      },
    };
    setExportsData((prev) => [row, ...prev]);
  };

  const sidebarItems: Array<{ id: OpsTab; label: string }> = [
    { id: 'commands', label: lang === 'ar' ? 'الأوامر' : 'Commands' },
    { id: 'incidents', label: lang === 'ar' ? 'الحوادث' : 'Incidents' },
    { id: 'notifications', label: lang === 'ar' ? 'الإشعارات' : 'Notifications' },
    { id: 'evidence', label: lang === 'ar' ? 'الأدلة' : 'Evidence' },
    { id: 'exports', label: lang === 'ar' ? 'التصدير' : 'Exports' },
    { id: 'custody', label: lang === 'ar' ? 'الحيازة' : 'Custody' },
    { id: 'verify', label: lang === 'ar' ? 'التحقق' : 'Verify' },
    { id: 'playbooks', label: lang === 'ar' ? 'Playbooks' : 'Playbooks' },
  ];

  return (
    <div className="space-y-6" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <div className="rounded-[2.5rem] bg-slate-900 text-white p-8 border-b-8 border-indigo-600">
        <h2 className="text-3xl font-black">
          {lang === 'ar' ? 'كونسول عمليات الوالدين' : 'Parent Ops Console'}
        </h2>
        <p className="text-sm font-bold text-indigo-200 mt-2">{currentUser.name}</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <div className="xl:col-span-3">
          <ParentSidebar
            lang={lang}
            items={sidebarItems}
            active={tab}
            onSelect={(id) => setTab(id as OpsTab)}
          />
        </div>
        <div className="xl:col-span-9 space-y-4">
          {tab === 'commands' && (
            <>
              <DeviceCommandsDashboard lang={lang} logs={logs} />
              <DeviceCommandControl lang={lang} children={children} onSendCommand={onSendCommand} />
              <CommandsStatusTable lang={lang} logs={logs} />
            </>
          )}

          {tab === 'incidents' && (
            <>
              <IncidentsTable
                lang={lang}
                incidents={incidents}
                selectedIncidentId={selectedIncident?.incident_id}
                onSelect={setSelectedIncidentId}
              />
              <IncidentDetailsTabs lang={lang} incident={selectedIncident} />
            </>
          )}

          {tab === 'notifications' && <NotificationCenterView lang={lang} alerts={alerts} />}

          {tab === 'evidence' && <ParentEvidenceVaultView lang={lang} records={alerts} />}

          {tab === 'exports' && (
            <>
              <CreateExportButton lang={lang} onCreate={createExport} />
              <ExportsTable lang={lang} exportsData={exportsData} />
            </>
          )}

          {tab === 'custody' && <CustodyTimeline lang={lang} rows={custodyRows} />}

          {tab === 'verify' && <HashVerifier lang={lang} />}

          {tab === 'playbooks' && <ParentSafetyPlaybookHub lang={lang} currentUser={currentUser} />}
        </div>
      </div>
    </div>
  );
};

export default ParentOpsConsoleView;
