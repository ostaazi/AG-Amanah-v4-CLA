﻿# Route Smoke Report

Generated: 2026-02-15 14:50:40

- /command-center : PASS
- /dev-resolution : PASS
- /parent-ops : PASS
- /playbooks : PASS
- /war-room : PASS
- /vault : PASS
- /pulse : PASS
