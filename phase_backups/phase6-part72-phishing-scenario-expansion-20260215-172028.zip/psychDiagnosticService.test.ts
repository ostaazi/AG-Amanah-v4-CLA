﻿import { describe, expect, it } from 'vitest';
import { diagnosePsychScenarioFromAlerts } from '../../services/psychDiagnosticService';
import { AlertSeverity, Category, MonitoringAlert } from '../../types';

const buildAlert = (partial: Partial<MonitoringAlert>): MonitoringAlert => ({
  id: partial.id || 'a1',
  childName: partial.childName || 'Lina',
  platform: partial.platform || 'discord',
  content: partial.content || '',
  category: partial.category || Category.BLACKMAIL,
  severity: partial.severity || AlertSeverity.HIGH,
  timestamp: partial.timestamp || new Date(),
  aiAnalysis: partial.aiAnalysis || partial.content || 'signal',
  imageData: partial.imageData,
  actionTaken: partial.actionTaken,
  latency: partial.latency,
  suspectId: partial.suspectId,
  status: partial.status,
});

describe('psychDiagnosticService threat subtype', () => {
  it('classifies sexual blackmail track when exploitation signals dominate', () => {
    const alerts: MonitoringAlert[] = [
      buildAlert({
        id: 'sx-1',
        category: Category.SEXUAL_EXPLOITATION,
        content: 'sextortion with private photos',
        aiAnalysis: 'sexual blackmail attempt detected',
        severity: AlertSeverity.CRITICAL,
      }),
    ];

    const diagnosis = diagnosePsychScenarioFromAlerts('Lina', alerts);

    expect(diagnosis?.scenarioId).toBe('threat_exposure');
    expect(diagnosis?.threatSubtype).toBe('sexual_blackmail');
  });

  it('classifies financial blackmail track when payment coercion dominates', () => {
    const alerts: MonitoringAlert[] = [
      buildAlert({
        id: 'fin-1',
        category: Category.SCAM,
        content: 'urgent payment transfer to crypto wallet',
        aiAnalysis: 'blackmail payment pressure via gift card',
        severity: AlertSeverity.HIGH,
      }),
      buildAlert({
        id: 'fin-2',
        category: Category.BLACKMAIL,
        content: 'send transfer now',
        aiAnalysis: 'demanding bitcoin transfer',
        severity: AlertSeverity.HIGH,
      }),
    ];

    const diagnosis = diagnosePsychScenarioFromAlerts('Lina', alerts);

    expect(diagnosis?.scenarioId).toBe('threat_exposure');
    expect(diagnosis?.threatSubtype).toBe('financial_blackmail');
  });

  it('does not attach threat subtype when top scenario is not threat exposure', () => {
    const alerts: MonitoringAlert[] = [
      buildAlert({
        id: 'game-1',
        category: Category.SAFE,
        content: 'gaming rank grind and long screen time',
        aiAnalysis: 'gaming overuse and sleep disruption',
        severity: AlertSeverity.HIGH,
      }),
    ];

    const diagnosis = diagnosePsychScenarioFromAlerts('Lina', alerts);

    expect(diagnosis?.scenarioId).toBe('gaming');
    expect(diagnosis?.threatSubtype).toBeUndefined();
  });

  it('classifies phishing links as a standalone scenario when phishing category dominates', () => {
    const alerts: MonitoringAlert[] = [
      buildAlert({
        id: 'ph-1',
        category: Category.PHISHING_LINK,
        content: 'suspicious url requesting otp and password reset',
        aiAnalysis: 'phishing attempt via fake login page',
        severity: AlertSeverity.CRITICAL,
      }),
    ];

    const diagnosis = diagnosePsychScenarioFromAlerts('Lina', alerts);

    expect(diagnosis?.scenarioId).toBe('phishing_links');
    expect(diagnosis?.threatSubtype).toBeUndefined();
  });
});
