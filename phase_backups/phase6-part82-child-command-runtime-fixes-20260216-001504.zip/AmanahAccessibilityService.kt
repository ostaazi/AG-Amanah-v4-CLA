﻿package com.amanah.child.services

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.amanah.child.utils.SecurityCortex
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class AmanahAccessibilityService : AccessibilityService() {

    private val db = FirebaseFirestore.getInstance()
    private val serviceScope = CoroutineScope(Dispatchers.IO)
    private var lastProcessedText: String = ""
    private var lastProcessTime: Long = 0
    private var lastBlockedActionAt: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("AmanahService", "Accessibility Service Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName.contains("com.amanah.child")) return

        if (isCameraMicPolicyActive() && isCameraOrMicSensitiveApp(packageName)) {
            handleBlockedApp(packageName, "camera_mic_policy")
            return
        }

        if (isBlockedApp(packageName)) {
            handleBlockedApp(packageName, "blocked_app_list")
            return
        }

        val relevantEvent = event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED
        if (!relevantEvent) return

        val text = extractEventText(event)
        if (text.length < 3) return

        val currentTime = System.currentTimeMillis()
        val isDuplicate = text == lastProcessedText && (currentTime - lastProcessTime) <= 1500
        if (isDuplicate) return

        lastProcessedText = text
        lastProcessTime = currentTime
        processContent(text, packageName)
    }

    private fun extractEventText(event: AccessibilityEvent): String {
        val direct = event.text?.joinToString(" ").orEmpty()
        val sourceText = event.source?.text?.toString().orEmpty()
        val desc = event.contentDescription?.toString().orEmpty()

        return listOf(direct, sourceText, desc)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun processContent(text: String, appName: String) {
        serviceScope.launch {
            val result = SecurityCortex.analyzeText(text)
            if (result.isDanger) {
                uploadAlert(text, appName, result)
            }
        }
    }

    private fun isBlockedApp(packageName: String): Boolean {
        val blocked = getSharedPreferences("AmanahPrefs", MODE_PRIVATE)
            .getStringSet("blockedApps", emptySet())
            ?.map { it.lowercase() }
            ?.toSet()
            ?: emptySet()
        if (blocked.isEmpty()) return false

        val pkg = packageName.lowercase()
        return blocked.any { token -> token.isNotBlank() && (pkg == token || pkg.contains(token)) }
    }

    private fun handleBlockedApp(packageName: String, reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlockedActionAt < 1200) return
        lastBlockedActionAt = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        uploadPolicyAlert(packageName, reason)
    }

    private fun uploadPolicyAlert(packageName: String, reason: String) {
        val prefs = getSharedPreferences("AmanahPrefs", MODE_PRIVATE)
        val parentId = prefs.getString("parentId", null) ?: return
        val childId = prefs.getString("childDocumentId", null) ?: return
        val childName = prefs.getString("childName", "My Child")

        val content = if (reason == "camera_mic_policy") {
            "Camera/microphone sensitive app launch blocked by child policy."
        } else {
            "Blocked app launch prevented by child policy."
        }

        val alert = hashMapOf(
            "parentId" to parentId,
            "childId" to childId,
            "childName" to childName,
            "platform" to packageName,
            "content" to content,
            "category" to "TAMPER",
            "severity" to "MEDIUM",
            "aiAnalysis" to if (reason == "camera_mic_policy")
                "Package blocked by blockCameraAndMic policy."
            else
                "Package blocked by remote blockApp command.",
            "actionTaken" to "Forced return to Home screen",
            "timestamp" to Timestamp.now(),
            "status" to "NEW"
        )

        db.collection("alerts").add(alert)
            .addOnFailureListener { e ->
                Log.w("AmanahService", "Failed to upload blocked-app alert", e)
            }
    }

    private fun isCameraMicPolicyActive(): Boolean {
        return getSharedPreferences("AmanahPrefs", MODE_PRIVATE)
            .getBoolean("blockCameraAndMic", false)
    }

    private fun isCameraOrMicSensitiveApp(packageName: String): Boolean {
        val pkg = packageName.lowercase()
        val exactOrContains = listOf(
            "com.android.camera",
            "com.google.android.googlecamera",
            "com.sec.android.app.camera",
            "com.oplus.camera",
            "org.codeaurora.snapcam",
            "com.android.soundrecorder",
            "com.google.android.apps.recorder"
        )
        if (exactOrContains.any { token -> pkg == token || pkg.contains(token) }) {
            return true
        }
        return pkg.contains("camera") || pkg.contains("recorder") || pkg.contains("voice")
    }

    private fun uploadAlert(content: String, platform: String, analysis: SecurityCortex.AnalysisResult) {
        val prefs = getSharedPreferences("AmanahPrefs", MODE_PRIVATE)
        val parentId = prefs.getString("parentId", null)
        val childName = prefs.getString("childName", "My Child")
        val childId = prefs.getString("childDocumentId", null)

        if (parentId == null || childId == null) {
            Log.w("AmanahService", "Device not paired yet. Skipping upload.")
            return
        }

        val alert = hashMapOf(
            "parentId" to parentId,
            "childId" to childId,
            "childName" to childName,
            "platform" to platform,
            "content" to content,
            "category" to analysis.category,
            "severity" to analysis.severity,
            "aiAnalysis" to "Local text detection matched restricted patterns.",
            "actionTaken" to "Logged & Parent Notified",
            "timestamp" to Timestamp.now(),
            "status" to "NEW",
            "suspectId" to "Unknown"
        )

        db.collection("alerts")
            .add(alert)
            .addOnSuccessListener {
                Log.i("AmanahService", "Alert uploaded: ${analysis.category}")
            }
            .addOnFailureListener { e ->
                Log.e("AmanahService", "Failed to upload alert", e)
            }
    }

    override fun onInterrupt() {
        Log.d("AmanahService", "Service Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
