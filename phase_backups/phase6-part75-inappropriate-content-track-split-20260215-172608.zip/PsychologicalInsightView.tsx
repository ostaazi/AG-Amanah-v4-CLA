﻿import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AlertSeverity, Category, Child, CustomMode, MonitoringAlert, SafetyPlaybook } from '../types';
import {
  Bar,
  BarChart,
  CartesianGrid,
  PolarAngleAxis,
  PolarGrid,
  Radar as RadarComponent,
  RadarChart,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useNavigate } from 'react-router-dom';
import {
  diagnosePsychScenarioFromAlerts,
  InappropriateContentSubtype,
  PsychScenarioId,
  ThreatExposureSubtype,
} from '../services/psychDiagnosticService';
import { fetchPlaybooks, sendRemoteCommand } from '../services/firestoreService';
import { getDefenseActionsWithPlaybooks } from '../services/ruleEngineService';

interface PsychologicalInsightViewProps {
  theme: 'light' | 'dark';
  child?: Child;
  alerts?: MonitoringAlert[];
  lang?: 'ar' | 'en';
  onAcceptPlan: (plan: Partial<CustomMode>) => string | void;
  onApplyModeToChild?: (childId: string, modeId?: string) => Promise<void> | void;
  onPlanExecutionResult?: (summary: { done: number; failed: number; skipped: number }) => void;
  onSaveExecutionEvidence?: (payload: PlanExecutionEvidencePayload) => Promise<string | void> | string | void;
}

interface InterventionStep {
  week: string;
  goal: string;
  action: string;
}

interface GuidanceScenario {
  id: PsychScenarioId;
  title: string;
  icon: string;
  severity: AlertSeverity;
  severityColor: string;
  symptoms: string[];
  lurePatterns: string[];
  prevention: string[];
  interventionProgram: InterventionStep[];
  dialogues: {
    situation: string;
    opener: string;
    advice: string;
  }[];
  alertTemplates: string[];
  incidentPlan: string[];
}

interface AutoExecutionStep {
  id: string;
  title: string;
  description: string;
  command:
    | 'takeScreenshot'
    | 'blockApp'
    | 'setVideoSource'
    | 'setAudioSource'
    | 'startLiveStream'
    | 'lockDevice'
    | 'playSiren'
    | 'lockscreenBlackout'
    | 'walkieTalkieEnable'
    | 'cutInternet'
    | 'blockCameraAndMic'
    | 'notifyParent';
  value: any;
  minSeverity: AlertSeverity;
  enabledByDefault: boolean;
}

type AutoStepStatus = 'idle' | 'pending' | 'done' | 'error' | 'skipped';
type PlanVideoSource = 'camera_front' | 'camera_back' | 'screen';
type PlanAudioSource = 'mic' | 'system';
type PlanTimelineStatus = 'done' | 'error' | 'skipped' | 'info';

interface PlanTimelineEntry {
  id: string;
  title: string;
  detail: string;
  status: PlanTimelineStatus;
  at: Date;
}

interface PlanExecutionEvidencePayload {
  childId: string;
  childName: string;
  scenarioId: PsychScenarioId;
  threatSubtype?: ThreatExposureSubtype;
  contentSubtype?: InappropriateContentSubtype;
  scenarioTitle: string;
  severity: AlertSeverity;
  dominantPlatform: string;
  summary: { done: number; failed: number; skipped: number };
  timeline: Array<{
    title: string;
    detail: string;
    status: PlanTimelineStatus;
    at: string;
  }>;
}

const severityRank: Record<AlertSeverity, number> = {
  [AlertSeverity.LOW]: 1,
  [AlertSeverity.MEDIUM]: 2,
  [AlertSeverity.HIGH]: 3,
  [AlertSeverity.CRITICAL]: 4,
};

const scenarioBlockedDomains: Record<PsychScenarioId, string[]> = {
  bullying: ['discord.com', 'telegram.org'],
  threat_exposure: ['discord.com', 'telegram.org', 'snapchat.com'],
  gaming: ['roblox.com', 'epicgames.com', 'discord.com'],
  inappropriate_content: ['reddit.com', 'xvideos.com', 'pornhub.com'],
  cyber_crime: ['pastebin.com', 'discord.com', 'telegram.org'],
  crypto_scams: ['binance.com', 'okx.com', 'telegram.org'],
  phishing_links: ['bit.ly', 'tinyurl.com', 't.me', 'discord.com'],
};

const guidanceScenarios: GuidanceScenario[] = [
  {
    id: 'bullying',
    title: 'Ø§Ù„ØªÙ†Ù…Ø± Ø§Ù„Ø¥Ù„ÙƒØªØ±ÙˆÙ†ÙŠ',
    icon: 'ðŸ§©',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-rose-600',
    symptoms: [
      'ØªØ¬Ù†Ø¨ Ø§Ù„Ø·ÙÙ„ ØªØ·Ø¨ÙŠÙ‚Ø§Øª Ù…Ø­Ø¯Ø¯Ø© Ø£Ùˆ Ø­Ø°Ù Ø§Ù„Ø±Ø³Ø§Ø¦Ù„ Ø¨Ø³Ø±Ø¹Ø©.',
      'ØªØºÙŠØ± Ø§Ù„Ù…Ø²Ø§Ø¬ Ø¨Ø¹Ø¯ ÙØªØ±Ø§Øª Ø§Ø³ØªØ®Ø¯Ø§Ù… Ù‚ØµÙŠØ±Ø©.',
      'Ø§Ù†Ø³Ø­Ø§Ø¨ Ø§Ø¬ØªÙ…Ø§Ø¹ÙŠ Ø£Ùˆ Ø±ÙØ¶ Ø§Ù„Ø°Ù‡Ø§Ø¨ Ù„Ù„Ù…Ø¯Ø±Ø³Ø© Ø¯ÙˆÙ† Ù…Ø¨Ø±Ø± ÙˆØ§Ø¶Ø­.',
    ],
    lurePatterns: [
      'Ù…Ø¬Ù…ÙˆØ¹Ø§Øª ØªØ³ØªÙØ² Ø§Ù„Ø·ÙÙ„ Ø«Ù… ØªÙ†Ø´Ø± Ù„Ù‚Ø·Ø§Øª Ù…Ø­Ø±Ø¬Ø©.',
      'Ø­Ø³Ø§Ø¨Ø§Øª ÙˆÙ‡Ù…ÙŠØ© Ù„Ø¥Ù‡Ø§Ù†Ø© Ù…ØªÙƒØ±Ø±Ø© ÙˆØ¥Ù‚ØµØ§Ø¡ Ø§Ø¬ØªÙ…Ø§Ø¹ÙŠ.',
      'ØªØ¹Ù„ÙŠÙ‚Ø§Øª ØªØ­Ø±ÙŠØ¶ÙŠØ© ØªØ¯ÙØ¹ Ø§Ù„Ø·ÙÙ„ Ù„Ù„Ø±Ø¯ Ø§Ù„Ø§Ù†ÙØ¹Ø§Ù„ÙŠ.',
    ],
    prevention: [
      'ØªØ´Ø¯ÙŠØ¯ Ø§Ù„Ø®ØµÙˆØµÙŠØ©: Ù…Ù† ÙŠØ±Ø§Ø³Ù„/ÙŠØ´Ø§Ù‡Ø¯ Ø§Ù„Ù…Ù†Ø´ÙˆØ±Ø§Øª.',
      'Ù…Ù†Ø¹ Ø§Ù„Ø±Ø³Ø§Ø¦Ù„ Ù…Ù† Ø§Ù„ØºØ±Ø¨Ø§Ø¡ Ø¯Ø§Ø®Ù„ Ø§Ù„Ø£Ù„Ø¹Ø§Ø¨ ÙˆØ§Ù„Ù…Ù†ØµØ§Øª.',
      'ØªØ¯Ø±ÙŠØ¨ Ø§Ù„Ø·ÙÙ„ Ø¹Ù„Ù‰ Ù‚Ø§Ø¹Ø¯Ø©: ÙˆØ«Ù‘Ù‚ØŒ Ø§Ø­Ø¸Ø±ØŒ Ø¨Ù„Ù‘ØºØŒ Ù„Ø§ ØªØ±Ø¯.',
    ],
    interventionProgram: [
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 1', goal: 'Ø§Ø­ØªÙˆØ§Ø¡ ÙÙˆØ±ÙŠ', action: 'Ø¬Ù„Ø³Ø© Ø¯Ø¹Ù… + ØªÙˆØ«ÙŠÙ‚ Ø§Ù„Ø£Ø¯Ù„Ø© + Ø­Ø¸Ø± Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª Ø§Ù„Ù…Ø¤Ø°ÙŠØ©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 2', goal: 'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„Ø§Ø³ØªÙ†Ø²Ø§Ù', action: 'ØªØ­Ø¯ÙŠØ« Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø§Ù„Ø®ØµÙˆØµÙŠØ© ÙˆÙ…Ø±Ø§Ù‚Ø¨Ø© Ù†Ù‚Ø§Ø· Ø§Ù„ØªÙ…Ø§Ø³ Ø¹Ø§Ù„ÙŠØ© Ø§Ù„Ø®Ø·Ø±.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 3', goal: 'Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„Ø«Ù‚Ø©', action: 'Ø­ÙˆØ§Ø± ØªØ¯Ø±ÙŠØ¬ÙŠ ÙˆØ¥Ø´Ø±Ø§Ùƒ Ø§Ù„Ù…Ø¯Ø±Ø³Ø© Ø¥Ø°Ø§ ÙƒØ§Ù†Øª Ø§Ù„Ø¨ÙŠØ¦Ø© Ù…Ø´ØªØ±ÙƒØ©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 4', goal: 'ØªØ«Ø¨ÙŠØª Ø§Ù„ØªØ¹Ø§ÙÙŠ', action: 'Ø®Ø·Ø© Ù…ØªØ§Ø¨Ø¹Ø© Ø£Ø³Ø¨ÙˆØ¹ÙŠØ© Ù‚ØµÙŠØ±Ø© Ù…Ø¹ Ù‚ÙŠØ§Ø³ ØªØ­Ø³Ù† Ø§Ù„Ø³Ù„ÙˆÙƒ.' },
    ],
    dialogues: [
      {
        situation: 'Ø§ÙØªØªØ§Ø­ Ø¨Ù„Ø§ Ù„ÙˆÙ…',
        opener: 'Ø£Ù†Ø§ Ù…Ø¹ÙƒØŒ ÙˆØ£ÙŠ Ø¥Ø³Ø§Ø¡Ø© ÙˆØµÙ„Øª Ù„Ùƒ Ù„ÙŠØ³Øª Ø®Ø·Ø£Ùƒ. Ø§Ø­ÙƒÙŠ Ù„ÙŠ Ø¨Ù‡Ø¯ÙˆØ¡.',
        advice: 'Ù„Ø§ ØªØ¨Ø¯Ø£ Ø¨Ø§Ù„Ø£Ø³Ø¦Ù„Ø© Ø§Ù„Ø§ØªÙ‡Ø§Ù…ÙŠØ©ØŒ Ø§Ø¨Ø¯Ø£ Ø¨Ø§Ù„Ø£Ù…Ø§Ù† Ø§Ù„Ù†ÙØ³ÙŠ.',
      },
      {
        situation: 'ØªØ¹Ø·ÙŠÙ„ Ø§Ù„Ø¶Ø±Ø±',
        opener: 'Ø³Ù†ÙˆÙ‚Ù Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª Ø§Ù„Ù…Ø³ÙŠØ¦Ø© Ø§Ù„Ø¢Ù†ØŒ ÙˆÙ†Ø­ÙØ¸ Ø§Ù„Ø£Ø¯Ù„Ø© Ù‚Ø¨Ù„ Ø£ÙŠ Ø­Ø°Ù.',
        advice: 'Ø§Ù„ØªÙˆØ«ÙŠÙ‚ ÙŠØ³Ø¨Ù‚ Ø§Ù„Ø­Ø°Ù Ø¯Ø§Ø¦Ù…Ù‹Ø§.',
      },
      {
        situation: 'ØªØ«Ø¨ÙŠØª Ø§Ù„Ø«Ù‚Ø©',
        opener: 'Ø¥Ø¨Ù„Ø§ØºÙƒ Ù„Ù†Ø§ Ù‚ÙˆØ©ØŒ ÙˆÙ„ÙŠØ³ Ø¶Ø¹ÙÙ‹Ø§. Ù†Ø­Ù† ÙØ±ÙŠÙ‚ ÙˆØ§Ø­Ø¯.',
        advice: 'Ø£Ø¹Ø¯ ØªØ¹Ø±ÙŠÙ Ø§Ù„Ø´Ø¬Ø§Ø¹Ø© Ø¨Ø£Ù†Ù‡Ø§ Ø·Ù„Ø¨ Ù…Ø³Ø§Ø¹Ø¯Ø© Ù…Ø¨ÙƒØ±.',
      },
    ],
    alertTemplates: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…ØªÙˆØ³Ø·: Ù…Ø¤Ø´Ø±Ø§Øª Ø¶ØºØ· Ø§Ø¬ØªÙ…Ø§Ø¹ÙŠ Ø±Ù‚Ù…ÙŠØ©ØŒ ÙŠÙÙ†ØµØ­ Ø¨Ø­ÙˆØ§Ø± Ù‡Ø§Ø¯Ø¦ Ø§Ù„ÙŠÙˆÙ….',
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…Ø±ØªÙØ¹: Ù†Ù…Ø· ØªÙ†Ù…Ø± Ù…ØªÙƒØ±Ø±ØŒ Ø§Ø¨Ø¯Ø£ Ù…Ø³Ø§Ø± Ø§Ù„ØªÙˆØ«ÙŠÙ‚ ÙˆØ§Ù„Ø­Ø¸Ø±.',
    ],
    incidentPlan: [
      'Ø·Ù…Ø£Ù†Ø© Ø§Ù„Ø·ÙÙ„ ÙÙˆØ±Ù‹Ø§: Ù„Ø§ Ù„ÙˆÙ… ÙˆÙ„Ø§ Ø¹Ù‚ÙˆØ¨Ø© Ù„Ø­Ø¸Ø© Ø§Ù„Ø¥Ø¨Ù„Ø§Øº.',
      'Ø­ÙØ¸ Ø§Ù„Ø£Ø¯Ù„Ø©: Ù„Ù‚Ø·Ø§Øª Ø´Ø§Ø´Ø©ØŒ Ø£Ø³Ù…Ø§Ø¡ Ø§Ù„Ø­Ø³Ø§Ø¨Ø§ØªØŒ Ø§Ù„ØªÙˆÙ‚ÙŠØª.',
      'Ø­Ø¸Ø± ÙˆØ¥Ø¨Ù„Ø§Øº Ø¯Ø§Ø®Ù„ Ø§Ù„Ù…Ù†ØµØ©.',
      'Ø¶Ø¨Ø· Ø§Ù„Ø®ØµÙˆØµÙŠØ© ÙˆØªÙ‚ÙŠÙŠØ¯ Ø§Ù„Ø±Ø³Ø§Ø¦Ù„ Ù…Ù† Ø§Ù„ØºØ±Ø¨Ø§Ø¡.',
      'Ù…ØªØ§Ø¨Ø¹Ø© Ù†ÙØ³ÙŠØ© Ø®Ù„Ø§Ù„ 72 Ø³Ø§Ø¹Ø©.',
    ],
  },
  {
    id: 'threat_exposure',
    title: 'Ø§Ù„ØªÙ‡Ø¯ÙŠØ¯ ÙˆØ§Ù„Ø§Ø¨ØªØ²Ø§Ø²',
    icon: 'ðŸš¨',
    severity: AlertSeverity.CRITICAL,
    severityColor: 'bg-red-700',
    symptoms: [
      'Ø®ÙˆÙ ÙˆØ§Ø¶Ø­ Ø¹Ù†Ø¯ ÙˆØµÙˆÙ„ Ø¥Ø´Ø¹Ø§Ø±Ø§Øª Ù…Ù† Ø¬Ù‡Ø© Ø¨Ø¹ÙŠÙ†Ù‡Ø§.',
      'Ø¥Ø®ÙØ§Ø¡ Ø§Ù„Ù‡Ø§ØªÙ Ø£Ùˆ Ø­Ø°Ù Ù…Ø­Ø§Ø¯Ø«Ø§Øª Ø¨Ø´ÙƒÙ„ Ù…ØªØ³Ø§Ø±Ø¹.',
      'Ø·Ù„Ø¨ Ù…Ø§Ù„/Ø¨Ø·Ø§Ù‚Ø§Øª Ø¨Ø´ÙƒÙ„ ØºÙŠØ± Ù…Ø¨Ø±Ø± Ø£Ùˆ ØªÙˆØªØ± Ø­Ø§Ø¯.',
    ],
    lurePatterns: [
      'Ø¨Ù†Ø§Ø¡ Ø«Ù‚Ø© Ø²Ø§Ø¦ÙØ© Ø«Ù… Ø·Ù„Ø¨ ØµÙˆØ± Ø£Ùˆ Ù…Ø¹Ù„ÙˆÙ…Ø§Øª Ø®Ø§ØµØ©.',
      'ØªÙ‡Ø¯ÙŠØ¯ Ø¨Ø§Ù„Ù†Ø´Ø± Ø£Ùˆ Ø§Ù„ØªØ´Ù‡ÙŠØ± Ø¨Ø¹Ø¯ Ø§Ù„Ø­ØµÙˆÙ„ Ø¹Ù„Ù‰ Ù…Ø­ØªÙˆÙ‰ Ø­Ø³Ø§Ø³.',
      'Ø§Ø¨ØªØ²Ø§Ø² Ù…Ø§Ù„ÙŠ Ø¹Ø¨Ø± Ø¨Ø·Ø§Ù‚Ø§Øª Ø§Ù„Ù‡Ø¯Ø§ÙŠØ§ Ø£Ùˆ Ø§Ù„ØªØ­ÙˆÙŠÙ„Ø§Øª Ø§Ù„Ø±Ù‚Ù…ÙŠØ©.',
    ],
    prevention: [
      'Ù‚Ø§Ø¹Ø¯Ø© Ø°Ù‡Ø¨ÙŠØ©: Ù„Ø§ ØµÙˆØ± Ø®Ø§ØµØ©ØŒ Ù„Ø§ Ø±Ù…ÙˆØ² ØªØ­Ù‚Ù‚ØŒ Ù„Ø§ ØªÙØ§ÙˆØ¶.',
      'ØªÙØ¹ÙŠÙ„ 2FA Ù„Ù„Ø­Ø³Ø§Ø¨Ø§Øª Ø§Ù„Ø±Ø¦ÙŠØ³ÙŠØ©.',
      'ØªØ¹Ù„ÙŠÙ… Ø§Ù„Ø·ÙÙ„ Ø§Ø³ØªØ®Ø¯Ø§Ù… Ø²Ø± Ø§Ù„Ù…Ø³Ø§Ø¹Ø¯Ø© Ø§Ù„ÙÙˆØ±ÙŠ Ø¯Ø§Ø®Ù„ Ø§Ù„ØªØ·Ø¨ÙŠÙ‚.',
    ],
    interventionProgram: [
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 1', goal: 'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„Ù†Ø²Ù', action: 'ØªØ·Ø¨ÙŠÙ‚ Ø®Ø·Ø© 10 Ø¯Ù‚Ø§Ø¦Ù‚ Ø¨Ø§Ù„ÙƒØ§Ù…Ù„ ÙˆØªØµØ¹ÙŠØ¯ Ø§Ù„Ø­Ù…Ø§ÙŠØ©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 2', goal: 'ØªØ­ØµÙŠÙ† Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª', action: 'ØªØºÙŠÙŠØ± ÙƒÙ„Ù…Ø§Øª Ø§Ù„Ù…Ø±ÙˆØ±ØŒ Ù…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„Ø¬Ù„Ø³Ø§ØªØŒ Ø¥ØºÙ„Ø§Ù‚ Ø§Ù„Ù…Ø³Ø§Ø±Ø§Øª Ø§Ù„Ù…ÙƒØ´ÙˆÙØ©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 3', goal: 'Ø¯Ø¹Ù… Ù†ÙØ³ÙŠ', action: 'Ø¬Ù„Ø³Ø§Øª ØªÙØ±ÙŠØº Ù‚Ù„Ù‚ØŒ ÙˆØªØ£ÙƒÙŠØ¯ Ø¹Ø¯Ù… Ø§Ù„Ø°Ù†Ø¨ Ø¹Ù„Ù‰ Ø§Ù„Ø·ÙÙ„.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 4', goal: 'Ù…Ù†Ø¹ Ø§Ù„ØªÙƒØ±Ø§Ø±', action: 'ØªØ­Ø¯ÙŠØ« Ø³ÙŠØ§Ø³Ø§Øª Ø§Ù„Ø£Ø³Ø±Ø© Ø§Ù„Ø±Ù‚Ù…ÙŠØ© ÙˆØ±ÙØ¹ ÙˆØ¹ÙŠ Ø§Ù„Ø·ÙÙ„.' },
    ],
    dialogues: [
      {
        situation: 'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„ØªØµØ¹ÙŠØ¯',
        opener: 'Ø³Ù„Ø§Ù…ØªÙƒ Ø£ÙˆÙ„Ù‹Ø§. Ù„Ù† Ù†Ø±Ø¯ Ø¹Ù„Ù‰ Ø£ÙŠ ØªÙ‡Ø¯ÙŠØ¯ØŒ ÙˆØ³Ù†ØªØ¹Ø§Ù…Ù„ Ø±Ø³Ù…ÙŠÙ‹Ø§.',
        advice: 'Ù„Ø§ Ø¯ÙØ¹ØŒ Ù„Ø§ ØªÙØ§ÙˆØ¶ØŒ Ù„Ø§ Ø­Ø°Ù Ù‚Ø¨Ù„ Ø§Ù„ØªÙˆØ«ÙŠÙ‚.',
      },
      {
        situation: 'ØªØ«Ø¨ÙŠØª Ø§Ù„Ø£Ù…Ø§Ù†',
        opener: 'Ù„Ù† ØªÙˆØ§Ø¬Ù‡ Ù‡Ø°Ø§ ÙˆØ­Ø¯ÙƒØŒ Ø³Ù†Ø­Ù„ Ø§Ù„Ù…ÙˆØ¶ÙˆØ¹ Ø®Ø·ÙˆØ© Ø¨Ø®Ø·ÙˆØ©.',
        advice: 'Ø£Ø¨Ø±Ø² Ø£Ù† Ø§Ù„Ø·ÙÙ„ Ø¶Ø­ÙŠØ© ÙˆÙ„ÙŠØ³ Ù…Ø°Ù†Ø¨Ù‹Ø§.',
      },
      {
        situation: 'Ø§Ù„ØªØ­Ø±Ùƒ Ø§Ù„Ù‚Ø§Ù†ÙˆÙ†ÙŠ',
        opener: 'Ø³Ù†Ø¬Ù…Ø¹ Ø§Ù„Ø¯Ù„ÙŠÙ„ Ø«Ù… Ù†Ø¨Ù„Ù‘Øº Ø§Ù„Ù‚Ù†ÙˆØ§Øª Ø§Ù„Ù…Ø¹ØªÙ…Ø¯Ø© Ù„Ø­Ù…Ø§ÙŠØªÙƒ.',
        advice: 'Ø­ÙØ¸ Ø§Ù„Ù‡ÙˆÙŠØ© Ø§Ù„Ø±Ù‚Ù…ÙŠØ© Ù„Ù„Ø¬Ù‡Ø© Ø§Ù„Ù…Ù‡Ø¯Ø¯Ø© Ù…Ù‡Ù… Ù‚Ø¨Ù„ Ø§Ù„Ø¥Ø¨Ù„Ø§Øº.',
      },
    ],
    alertTemplates: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ø­Ø±Ø¬: Ø§Ø­ØªÙ…Ø§Ù„ ØªÙ‡Ø¯ÙŠØ¯/Ø§Ø¨ØªØ²Ø§Ø² Ù…Ø¨Ø§Ø´Ø±. Ø§Ø¨Ø¯Ø£ Ø®Ø·Ø© 10 Ø¯Ù‚Ø§Ø¦Ù‚ Ø§Ù„Ø¢Ù†.',
      'ØªÙ†Ø¨ÙŠÙ‡ Ø­Ø±Ø¬: Ø³Ù„ÙˆÙƒ Ø­Ø°Ù Ù…Ø­Ø§Ø¯Ø«Ø§Øª + Ø®ÙˆÙ + Ø·Ù„Ø¨ Ù…Ø§Ù„ÙŠØŒ ÙŠÙ„Ø²Ù… ØªØ¯Ø®Ù„ ÙÙˆØ±ÙŠ.',
    ],
    incidentPlan: [
      'Ù„Ø§ ØªÙØ§ÙˆØ¶ ÙˆÙ„Ø§ Ø¯ÙØ¹ ØªØ­Øª Ø£ÙŠ Ø¶ØºØ·.',
      'Ø­ÙØ¸ Ø§Ù„Ø£Ø¯Ù„Ø© Ø§Ù„Ø±Ù‚Ù…ÙŠØ© ÙÙˆØ±Ù‹Ø§.',
      'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„ØªÙˆØ§ØµÙ„ Ù…Ø¹ Ø§Ù„Ù…Ø¨ØªØ² ÙˆØ­Ø¸Ø±Ù‡.',
      'ØªØ£Ù…ÙŠÙ† Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª (ØªØºÙŠÙŠØ± ÙƒÙ„Ù…Ø© Ø§Ù„Ù…Ø±ÙˆØ± + 2FA).',
      'Ø¥Ø¨Ù„Ø§Øº Ø§Ù„Ù…Ù†ØµØ© ÙˆØ§Ù„Ø¬Ù‡Ø© Ø§Ù„Ù…Ø®ØªØµØ© Ø­Ø³Ø¨ Ø§Ù„Ø¥Ø¬Ø±Ø§Ø¡Ø§Øª Ø§Ù„Ù…Ø­Ù„ÙŠØ©.',
    ],
  },
  {
    id: 'gaming',
    title: 'Ø¥Ø¯Ù…Ø§Ù† Ø§Ù„Ø£Ù„Ø¹Ø§Ø¨',
    icon: 'ðŸŽ®',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-indigo-600',
    symptoms: [
      'Ø³Ù‡Ø± Ù…ÙØ±Ø· ÙˆØ§Ø¶Ø·Ø±Ø§Ø¨ Ù†ÙˆÙ… Ù…ØªÙƒØ±Ø±.',
      'Ø¹ØµØ¨ÙŠØ© Ø¹Ø§Ù„ÙŠØ© Ø¹Ù†Ø¯ Ø³Ø­Ø¨ Ø§Ù„Ø¬Ù‡Ø§Ø² Ø£Ùˆ Ø§Ù†ØªÙ‡Ø§Ø¡ Ø§Ù„ÙˆÙ‚Øª.',
      'ØªØ±Ø§Ø¬Ø¹ Ø¯Ø±Ø§Ø³ÙŠ ÙˆØ§Ù†Ø³Ø­Ø§Ø¨ Ù…Ù† Ø£Ù†Ø´Ø·Ø© ÙˆØ§Ù‚Ø¹ÙŠØ©.',
    ],
    lurePatterns: [
      'Ù…ÙƒØ§ÙØ¢Øª ÙŠÙˆÙ…ÙŠØ© ØªØ¨Ù†ÙŠ ØªØ¹Ù„Ù‚Ù‹Ø§ Ù‚Ù‡Ø±ÙŠÙ‹Ø§.',
      'Ø¶ØºØ· Ø§Ù„Ø£ØµØ¯Ù‚Ø§Ø¡ ÙÙŠ Ø§Ù„ÙØ±Ù‚ Ø§Ù„ØªÙ†Ø§ÙØ³ÙŠØ©.',
      'Ù…Ø´ØªØ±ÙŠØ§Øª Ø¯Ø§Ø®Ù„ Ø§Ù„Ù„Ø¹Ø¨Ø© ØªØ¹Ø²Ø² Ù…Ø·Ø§Ø±Ø¯Ø© Ø§Ù„Ø®Ø³Ø§Ø±Ø©.',
    ],
    prevention: [
      'ØªÙØ¹ÙŠÙ„ Bedtime ØªÙ„Ù‚Ø§Ø¦ÙŠ.',
      'Ø¬Ø¯ÙˆÙ„Ø© ÙˆÙ‚Øª Ø§Ù„Ù„Ø¹Ø¨ ÙˆØ±Ø¨Ø·Ù‡ Ø¨Ø§Ù„Ù…Ù‡Ø§Ù… Ø§Ù„ÙŠÙˆÙ…ÙŠØ©.',
      'Ù‚ÙÙ„ Ø§Ù„Ù…Ø´ØªØ±ÙŠØ§Øª Ø¨ÙƒÙ„Ù…Ø© Ù…Ø±ÙˆØ± ÙˆÙ„ÙŠ Ø§Ù„Ø£Ù…Ø±.',
    ],
    interventionProgram: [
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 1', goal: 'Ø§Ø³ØªÙ‚Ø±Ø§Ø± Ø§Ù„Ù†ÙˆÙ…', action: 'ØªØ«Ø¨ÙŠØª ÙˆÙ‚Øª Ù†ÙˆÙ… ÙˆÙ…Ù†Ø¹ Ø§Ù„Ø§Ø³ØªØ®Ø¯Ø§Ù… Ø§Ù„Ù„ÙŠÙ„ÙŠ.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 2', goal: 'Ø®ÙØ¶ ØªØ¯Ø±ÙŠØ¬ÙŠ', action: 'ØªÙ‚Ù„ÙŠÙ„ 10%-15% Ù…Ù† Ø§Ù„Ø§Ø³ØªØ®Ø¯Ø§Ù… Ø§Ù„ÙŠÙˆÙ…ÙŠ.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 3', goal: 'Ø¨Ø¯Ø§Ø¦Ù„ ÙˆØ§Ù‚Ø¹ÙŠØ©', action: 'Ø¥Ø¯Ø®Ø§Ù„ Ù†Ø´Ø§Ø· Ø¨Ø¯ÙŠÙ„ Ø«Ø§Ø¨Øª (Ø±ÙŠØ§Ø¶Ø©/Ù‡ÙˆØ§ÙŠØ©).' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 4', goal: 'ØªØ«Ø¨ÙŠØª Ø§Ù„Ø³Ù„ÙˆÙƒ', action: 'Ù†Ø¸Ø§Ù… Ù…ÙƒØ§ÙØ¢Øª Ù…Ø±ØªØ¨Ø· Ø¨Ø§Ù„Ø§Ù„ØªØ²Ø§Ù… Ø§Ù„Ø¯Ø±Ø§Ø³ÙŠ ÙˆØ§Ù„Ø³Ù„ÙˆÙƒÙŠ.' },
    ],
    dialogues: [
      {
        situation: 'Ø§ØªÙØ§Ù‚ Ù…Ù†ØµÙ',
        opener: 'Ø£Ù†Ø§ Ù„Ø§ Ø£Ø±ÙŠØ¯ Ø§Ù„Ù…Ù†Ø¹ Ø§Ù„ÙƒØ§Ù…Ù„ØŒ ÙÙ‚Ø· Ù†Ø­ØªØ§Ø¬ ØªÙˆØ§Ø²Ù†Ù‹Ø§ ÙŠØ­Ù…ÙŠÙƒ.',
        advice: 'Ø§Ø®ØªØ± ØµÙŠØºØ© Ø´Ø±Ø§ÙƒØ© Ù„Ø§ ØµÙŠØºØ© Ø¹Ù‚Ø§Ø¨.',
      },
      {
        situation: 'ØªÙ†Ø¸ÙŠÙ… ØªØ¯Ø±ÙŠØ¬ÙŠ',
        opener: 'Ø®Ù„Ù‘Ù†Ø§ Ù†Ø¨Ø¯Ø£ Ø¨Ø®Ø·Ø© Ø£Ø³Ø¨ÙˆØ¹ØŒ Ø«Ù… Ù†Ø±Ø§Ø¬Ø¹ Ø³ÙˆØ§ Ø§Ù„Ù†ØªØ§Ø¦Ø¬.',
        advice: 'Ø§Ù„ØªØºÙŠÙŠØ± Ø§Ù„ØªØ¯Ø±ÙŠØ¬ÙŠ ÙŠÙ†Ø¬Ø­ Ø£ÙƒØ«Ø± Ù…Ù† Ø§Ù„Ù‚Ø·Ø¹ Ø§Ù„Ù…ÙØ§Ø¬Ø¦.',
      },
      {
        situation: 'Ø¯Ø¹Ù… Ø§Ù„Ù…Ù‡Ø§Ø±Ø©',
        opener: 'Ù…Ù‡Ø§Ø±ØªÙƒ Ù…Ù…ØªØ§Ø²Ø©ØŒ ÙˆÙ†Ø±ÙŠØ¯Ù‡Ø§ ØªØ³ØªÙ…Ø± Ø¨Ø¯ÙˆÙ† Ø£Ù† ØªØ¶Ø± Ù†ÙˆÙ…Ùƒ ÙˆØ¯Ø±Ø§Ø³ØªÙƒ.',
        advice: 'Ø§Ø±Ø¨Ø· Ø§Ù„Ø«Ù†Ø§Ø¡ Ø¨Ø¶ÙˆØ§Ø¨Ø· Ø§Ù„Ø§Ø³ØªØ®Ø¯Ø§Ù….',
      },
    ],
    alertTemplates: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ù†ÙˆÙ…: Ø§Ø³ØªØ®Ø¯Ø§Ù… Ù…ØªØ£Ø®Ø± Ù…ØªÙƒØ±Ø±ØŒ ÙŠÙÙ†ØµØ­ Ø¨ØªÙØ¹ÙŠÙ„ ÙˆØ¶Ø¹ Ø§Ù„Ù†ÙˆÙ….',
      'ØªÙ†Ø¨ÙŠÙ‡ Ø³Ù„ÙˆÙƒÙŠ: ØªØ¬Ø§ÙˆØ²Ø§Øª ÙˆÙ‚Øª Ø§Ù„Ø´Ø§Ø´Ø© Ù…Ø¹ Ø§Ù†ÙØ¹Ø§Ù„ Ø¹Ù†Ø¯ Ø§Ù„Ø¥ÙŠÙ‚Ø§Ù.',
    ],
    incidentPlan: [
      'ØªÙ‡Ø¯Ø¦Ø© Ø§Ù„Ù…ÙˆÙ‚Ù ÙˆØ¹Ø¯Ù… Ø§Ù„Ø¯Ø®ÙˆÙ„ ÙÙŠ ØµØ¯Ø§Ù… Ù„Ø­Ø¸ÙŠ.',
      'ØªÙØ¹ÙŠÙ„ ÙˆØ¶Ø¹ Ø§Ù„Ù†ÙˆÙ… ÙˆØ¥ØºÙ„Ø§Ù‚ Ø§Ù„ØªØ·Ø¨ÙŠÙ‚Ø§Øª Ø¹Ø§Ù„ÙŠØ© Ø§Ù„Ø§Ø³ØªÙ‡Ù„Ø§Ùƒ.',
      'ØªØ­Ø¯ÙŠØ¯ Ø®Ø·Ø© Ø£Ø³Ø¨ÙˆØ¹ Ø®ÙØ¶ ØªØ¯Ø±ÙŠØ¬ÙŠ.',
      'Ø¥Ø¯Ø®Ø§Ù„ Ù†Ø´Ø§Ø· Ø¨Ø¯ÙŠÙ„ ÙŠÙˆÙ…ÙŠ.',
      'Ù…Ø±Ø§Ø¬Ø¹Ø© Ø£Ø³Ø¨ÙˆØ¹ÙŠØ© Ø¨Ø§Ù„Ø£Ø±Ù‚Ø§Ù… Ù„Ø§ Ø¨Ø§Ù„Ø§Ù†Ø·Ø¨Ø§Ø¹Ø§Øª.',
    ],
  },
  {
    id: 'inappropriate_content',
    title: 'Ø§Ù„Ù…Ø­ØªÙˆÙ‰ ØºÙŠØ± Ø§Ù„Ù…Ù†Ø§Ø³Ø¨',
    icon: 'ðŸ›¡ï¸',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-violet-700',
    symptoms: [
      'Ø¥ØºÙ„Ø§Ù‚ Ù…ÙØ§Ø¬Ø¦ Ù„Ù„Ø´Ø§Ø´Ø© Ø¹Ù†Ø¯ Ø§Ù„Ø§Ù‚ØªØ±Ø§Ø¨.',
      'ØªØµÙØ­ Ø®ÙÙŠ Ù…ØªÙƒØ±Ø± Ø£Ùˆ ØªØ§Ø±ÙŠØ® Ù…Ø­Ø°ÙˆÙ Ø¨Ø§Ø³ØªÙ…Ø±Ø§Ø±.',
      'ØªÙˆØªØ± Ø£Ùˆ Ø®Ø¬Ù„ Ø²Ø§Ø¦Ø¯ Ø¨Ø¹Ø¯ Ø§Ù„ØªÙˆØ§Ø¬Ø¯ Ø¹Ù„Ù‰ Ø§Ù„Ø¥Ù†ØªØ±Ù†Øª.',
    ],
    lurePatterns: [
      'Ø±ÙˆØ§Ø¨Ø· Ù…Ø¶Ù„Ù„Ø© Ø¯Ø§Ø®Ù„ ÙÙŠØ¯ÙŠÙˆÙ‡Ø§Øª Ø£Ùˆ Ø£Ù„Ø¹Ø§Ø¨.',
      'Ø­Ø³Ø§Ø¨Ø§Øª ÙØ¶ÙˆÙ„ÙŠØ© ØªÙ†Ø´Ø± Ù…ÙˆØ§Ø¯ ØµØ§Ø¯Ù…Ø© Ø¨Ø¹Ù†Ø§ÙˆÙŠÙ† Ø¨Ø±ÙŠØ¦Ø©.',
      'Ù†ÙˆØ§ÙØ° Ù…Ù†Ø¨Ø«Ù‚Ø© ØªØ³ØªØ¯Ø±Ø¬ Ø§Ù„Ø·ÙÙ„ Ø®Ø§Ø±Ø¬ Ø¨ÙŠØ¦Ø© Ø¢Ù…Ù†Ø©.',
    ],
    prevention: [
      'SafeSearch + DNS ÙÙ„ØªØ±Ø© Ø­Ø³Ø¨ Ø§Ù„Ø¹Ù…Ø±.',
      'Ù‚Ø§Ø¦Ù…Ø© Ù…ÙˆØ§Ù‚Ø¹/ØªØ·Ø¨ÙŠÙ‚Ø§Øª Ù…ÙˆØ«ÙˆÙ‚Ø© ÙÙ‚Ø·.',
      'Ø±Ø³Ø§Ù„Ø© Ø£Ø³Ø±ÙŠØ© Ø«Ø§Ø¨ØªØ©: Ø£ØºÙ„Ù‚ ÙˆØ¨Ù„Ù‘Øº Ø¨Ù„Ø§ Ø¹Ù‚ÙˆØ¨Ø©.',
    ],
    interventionProgram: [
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 1', goal: 'Ø­Ù…Ø§ÙŠØ© ÙÙˆØ±ÙŠØ©', action: 'ØªÙ‚ÙˆÙŠØ© Ø§Ù„ÙÙ„Ø§ØªØ± ÙˆØ¥Ø²Ø§Ù„Ø© Ø§Ù„Ù…ØµØ§Ø¯Ø± Ø§Ù„Ù…ÙƒØ´ÙˆÙØ©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 2', goal: 'Ø­ÙˆØ§Ø± ØªØ±Ø¨ÙˆÙŠ', action: 'Ù†Ù‚Ø§Ø´ Ø¢Ù…Ù† Ø¹Ù† Ø§Ù„Ù…Ø­ØªÙˆÙ‰ Ø§Ù„ØµØ§Ø¯Ù… ÙˆØ·Ø±Ù‚ Ø§Ù„ØªØ¨Ù„ÙŠØº.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 3', goal: 'Ø¨Ø¯Ø§Ø¦Ù„ ØµØ­ÙŠØ©', action: 'Ø¥Ø­Ù„Ø§Ù„ Ù…Ø­ØªÙˆÙ‰ Ù…Ù†Ø§Ø³Ø¨ Ù„Ù„Ø¹Ù…Ø± ÙˆÙ…Ø±Ø§Ù‚Ø¨.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 4', goal: 'ØªØ«Ø¨ÙŠØª Ø§Ù„Ø¹Ø§Ø¯Ø©', action: 'Ù…Ø±Ø§Ø¬Ø¹Ø© Ø£Ø³Ø¨ÙˆØ¹ÙŠØ© Ù„Ù„ØªØ¹Ø±Ø¶Ø§Øª ÙˆØªØ¹Ø¯ÙŠÙ„ Ø§Ù„Ø¶Ø¨Ø·.' },
    ],
    dialogues: [
      {
        situation: 'Ø¥Ø²Ø§Ù„Ø© Ø§Ù„Ø®ÙˆÙ',
        opener: 'Ù„Ùˆ Ø¸Ù‡Ø± Ø´ÙŠØ¡ Ù…Ø²Ø¹Ø¬ØŒ Ø£ØºÙ„Ù‚Ù‡ ÙˆØªØ¹Ø§Ù„ Ù…Ø¨Ø§Ø´Ø±Ø©ØŒ Ù…Ø§ ÙÙŠÙ‡ Ø¹Ù‚Ø§Ø¨.',
        advice: 'Ø£Ø²Ù„ ÙˆØµÙ…Ø© Ø§Ù„Ø§Ø¹ØªØ±Ø§Ù Ù…Ù† Ø§Ù„Ø¨Ø¯Ø§ÙŠØ©.',
      },
      {
        situation: 'ØªÙˆØ¬ÙŠÙ‡ Ø¹Ù…Ù„ÙŠ',
        opener: 'Ù†Ø¹Ø¯Ù„ Ø§Ù„Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø³ÙˆØ§ Ø­ØªÙ‰ Ù…Ø§ ÙŠØªÙƒØ±Ø± Ø§Ù„ÙˆØµÙˆÙ„ Ù„Ù‡Ø°Ø§ Ø§Ù„Ù…Ø­ØªÙˆÙ‰.',
        advice: 'Ø§Ù„Ø­ÙˆØ§Ø± ÙŠØ¬Ø¨ Ø£Ù† ÙŠÙ†ØªÙ‡ÙŠ Ø¨Ø®Ø·ÙˆØ© ØªÙ‚Ù†ÙŠØ© ÙˆØ§Ø¶Ø­Ø©.',
      },
      {
        situation: 'ØªØ«Ø¨ÙŠØª Ø§Ù„Ù‚Ø§Ø¹Ø¯Ø©',
        opener: 'Ø£ÙŠ Ø±Ø§Ø¨Ø· ØºØ±ÙŠØ¨ Ø£Ùˆ Ù…Ø­ØªÙˆÙ‰ ØµØ§Ø¯Ù…: Ù„Ø§ ÙØªØ­ØŒ ÙÙ‚Ø· Ø¨Ù„Ù‘Øº.',
        advice: 'Ø§Ù„ØªÙƒØ±Ø§Ø± Ø§Ù„ÙŠÙˆÙ…ÙŠ ÙŠØ¨Ù†ÙŠ Ø³Ù„ÙˆÙƒ Ø§Ù„Ø£Ù…Ø§Ù†.',
      },
    ],
    alertTemplates: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…Ø­ØªÙˆÙ‰: Ù…Ø­Ø§ÙˆÙ„Ø§Øª ÙˆØµÙˆÙ„ Ù„ØªØµÙ†ÙŠÙØ§Øª Ù…Ø­Ø¬ÙˆØ¨Ø© Ø£Ø¹Ù„Ù‰ Ù…Ù† Ø§Ù„Ù…Ø¹ØªØ§Ø¯.',
      'ØªÙ†Ø¨ÙŠÙ‡ ÙˆÙ‚Ø§Ø¦ÙŠ: ÙŠÙÙ†ØµØ­ Ø¨ØªØ­Ø¯ÙŠØ« Ù…Ø±Ø´Ø­Ø§Øª Ø§Ù„Ù…Ø­ØªÙˆÙ‰ Ù„Ù‡Ø°Ø§ Ø§Ù„Ø¹Ù…Ø±.',
    ],
    incidentPlan: [
      'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„Ù…ØµØ¯Ø± Ø§Ù„Ù…Ø³Ø¨Ø¨ (Ø±Ø§Ø¨Ø·/Ø­Ø³Ø§Ø¨/ØªØ·Ø¨ÙŠÙ‚).',
      'Ù…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„ÙÙ„Ø§ØªØ± ÙˆØ¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø§Ù„Ø¨Ø­Ø« Ø§Ù„Ø¢Ù…Ù†.',
      'Ø­ÙˆØ§Ø± Ø§Ø­ØªÙˆØ§Ø¡ Ù‚ØµÙŠØ± Ù…Ø¹ Ø§Ù„Ø·ÙÙ„ Ø¯ÙˆÙ† Ù„ÙˆÙ….',
      'ØªÙØ¹ÙŠÙ„ Ù‚Ø§Ø¦Ù…Ø© Ø¨Ø¯Ø§Ø¦Ù„ Ø¢Ù…Ù†Ø© Ù„Ù„Ù…Ø­ØªÙˆÙ‰.',
      'Ù…ØªØ§Ø¨Ø¹Ø© 7 Ø£ÙŠØ§Ù… Ù„Ù‚ÙŠØ§Ø³ Ø§Ù„ØªÙƒØ±Ø§Ø±.',
    ],
  },
  {
    id: 'cyber_crime',
    title: 'Ø§Ù„Ø§Ù†Ø­Ø±Ø§Ù Ø§Ù„Ø³ÙŠØ¨Ø±Ø§Ù†ÙŠ',
    icon: 'ðŸ‘¨â€ðŸ’»',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-slate-800',
    symptoms: [
      'Ø§Ø³ØªØ®Ø¯Ø§Ù… Ø£Ø¯ÙˆØ§Øª ØºÙŠØ± Ù…ÙˆØ«ÙˆÙ‚Ø© Ø¨ØµÙŠØºØ© Ù‡Ø¬ÙˆÙ…ÙŠØ©.',
      'Ø§Ù„Ø­Ø¯ÙŠØ« Ø¹Ù† Ø§Ø®ØªØ±Ø§Ù‚ Ø­Ø³Ø§Ø¨Ø§Øª Ø¨Ø§Ø¹ØªØ¨Ø§Ø±Ù‡ Ø¥Ù†Ø¬Ø§Ø²Ù‹Ø§.',
      'Ø¥Ø®ÙØ§Ø¡ Ø§Ù„Ù‡ÙˆÙŠØ© Ø¨Ø´ÙƒÙ„ Ù…Ø¨Ø§Ù„Øº Ø¯ÙˆÙ† Ù…Ø¨Ø±Ø± ÙˆØ§Ù‚Ø¹ÙŠ.',
    ],
    lurePatterns: [
      'Ù‚Ù†ÙˆØ§Øª ØªÙ‚Ø¯Ù… Ø³ÙƒØ±Ø¨ØªØ§Øª Ø¬Ø§Ù‡Ø²Ø© Ø¨Ø¯Ø§ÙØ¹ Ø§Ù„ÙØ¶ÙˆÙ„.',
      'Ù…Ø¬Ù…ÙˆØ¹Ø§Øª ØªØ¹Ø·ÙŠ Ù…Ù‡Ø§Ù… ØªØ®Ø±ÙŠØ¨ÙŠØ© ÙƒÙ…Ù†Ø§ÙØ³Ø©.',
      'ØªØ­ÙÙŠØ² Ø§Ø¬ØªÙ…Ø§Ø¹ÙŠ Ø­ÙˆÙ„ Ø§Ù„Ù‚ÙˆØ© Ø§Ù„ØªÙ‚Ù†ÙŠØ© Ù…Ù‚Ø§Ø¨Ù„ ÙƒØ³Ø± Ø§Ù„Ù‚ÙˆØ§Ù†ÙŠÙ†.',
    ],
    prevention: [
      'Ø­Ø¸Ø± Ù…ØµØ§Ø¯Ø± Ø§Ù„Ø£Ø¯ÙˆØ§Øª Ø§Ù„Ù…Ø¬Ù‡ÙˆÙ„Ø©.',
      'Ø´Ø±Ø­ Ø§Ù„ÙØ±Ù‚ Ø¨ÙŠÙ† Ø§Ù„ØªØ¹Ù„Ù… Ø§Ù„Ø£Ù…Ù†ÙŠ Ø§Ù„Ù‚Ø§Ù†ÙˆÙ†ÙŠ ÙˆØ§Ù„ØªØ¹Ø¯ÙŠ.',
      'ØªÙˆØ¬ÙŠÙ‡ Ø§Ù„Ù…ÙˆÙ‡Ø¨Ø© Ø¥Ù„Ù‰ Ù…Ù†ØµØ§Øª CTF ØªØ¹Ù„ÙŠÙ…ÙŠØ© Ø¨Ø¥Ø´Ø±Ø§Ù.',
    ],
    interventionProgram: [
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 1', goal: 'Ø§Ø­ØªÙˆØ§Ø¡ Ø§Ù„Ø³Ù„ÙˆÙƒ', action: 'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„Ø£Ø¯ÙˆØ§Øª Ø§Ù„Ø®Ø·Ø±Ø© ÙˆÙ…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„Ø¬Ù‡Ø§Ø².' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 2', goal: 'Ø¨Ø¯ÙŠÙ„ Ù‚Ø§Ù†ÙˆÙ†ÙŠ', action: 'Ø¨Ø¯Ø¡ Ù…Ø³Ø§Ø± ØªØ¹Ù„Ù… Ø£Ø®Ù„Ø§Ù‚ÙŠ Ù„Ù„Ø£Ù…Ù† Ø§Ù„Ø³ÙŠØ¨Ø±Ø§Ù†ÙŠ.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 3', goal: 'ÙˆØ¹ÙŠ Ù‚Ø§Ù†ÙˆÙ†ÙŠ', action: 'Ø¬Ù„Ø³Ø© Ø¹ÙˆØ§Ù‚Ø¨ Ø¬Ù†Ø§Ø¦ÙŠØ© Ù…Ø¨Ø³Ø·Ø© ÙˆÙ…Ø¨Ø§Ø´Ø±Ø©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 4', goal: 'Ø§Ù„ØªØ²Ø§Ù… Ù…Ø³ØªÙ…Ø±', action: 'Ø®Ø·Ø© Ø§Ø³ØªØ®Ø¯Ø§Ù… ØªÙ‚Ù†ÙŠØ© Ø®Ø§Ø¶Ø¹Ø© Ù„Ù…Ø±Ø§Ø¬Ø¹Ø© Ø£Ø³Ø¨ÙˆØ¹ÙŠØ©.' },
    ],
    dialogues: [
      {
        situation: 'Ø¥Ø¹Ø§Ø¯Ø© ØªÙˆØ¬ÙŠÙ‡ Ø§Ù„Ù…Ù‡Ø§Ø±Ø©',
        opener: 'Ø°ÙƒØ§Ø¤Ùƒ Ø§Ù„ØªÙ‚Ù†ÙŠ Ù…Ù‡Ù…ØŒ ÙˆØ§Ù„Ø£ÙØ¶Ù„ ØªØ­ÙˆÙŠÙ„Ù‡ Ù„Ù…Ø³Ø§Ø± Ø§Ø­ØªØ±Ø§ÙÙŠ Ù‚Ø§Ù†ÙˆÙ†ÙŠ.',
        advice: 'Ø§Ø¹ØªØ±Ù Ø¨Ø§Ù„Ù…ÙˆÙ‡Ø¨Ø© Ø£ÙˆÙ„Ù‹Ø§ Ø«Ù… Ø£Ø¹Ø¯ ØªÙˆØ¬ÙŠÙ‡Ù‡Ø§.',
      },
      {
        situation: 'Ø­Ø¯ÙˆØ¯ ÙˆØ§Ø¶Ø­Ø©',
        opener: 'Ø£ÙŠ Ù‡Ø¬ÙˆÙ… Ø±Ù‚Ù…ÙŠ Ù‚Ø¯ ÙŠØµØ¨Ø­ Ù‚Ø¶ÙŠØ© Ø¬Ù†Ø§Ø¦ÙŠØ© ØªØ¤Ø«Ø± Ø¹Ù„Ù‰ Ù…Ø³ØªÙ‚Ø¨Ù„Ùƒ.',
        advice: 'ÙˆØ¶Ø­ Ø§Ù„Ø¹ÙˆØ§Ù‚Ø¨ Ø¨Ø¯ÙˆÙ† ØªÙ‡ÙˆÙŠÙ„ Ø¹Ø§Ø·ÙÙŠ.',
      },
      {
        situation: 'Ù…Ø³Ø§Ø± Ø¨Ø¯ÙŠÙ„',
        opener: 'Ù†Ø®ØªØ§Ø± Ù…Ø¹Ù‹Ø§ Ù…Ù†ØµØ© ØªØ¯Ø±ÙŠØ¨ Ù‚Ø§Ù†ÙˆÙ†ÙŠØ© ÙˆÙ†Ø¨Ù†ÙŠ Ù…Ù‡Ø§Ø±Ø§ØªÙƒ Ø¨Ø´ÙƒÙ„ Ø¢Ù…Ù†.',
        advice: 'Ø§Ù„Ø¨Ø¯ÙŠÙ„ Ø§Ù„Ø¹Ù…Ù„ÙŠ ÙŠÙ‚Ù„Ù„ Ø§Ù„Ø¹ÙˆØ¯Ø© Ù„Ù„Ø³Ù„ÙˆÙƒ Ø§Ù„Ø®Ø·Ø±.',
      },
    ],
    alertTemplates: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ø³Ù„ÙˆÙƒÙŠ: Ù†Ø´Ø§Ø· ØªÙ‚Ù†ÙŠ Ù‡Ø¬ÙˆÙ…ÙŠ Ù…ØªÙƒØ±Ø± ÙŠØ­ØªØ§Ø¬ Ø¥Ø¹Ø§Ø¯Ø© ØªÙˆØ¬ÙŠÙ‡ ÙÙˆØ±ÙŠ.',
      'ØªÙ†Ø¨ÙŠÙ‡ ØªÙ‚Ù†ÙŠ: ØªØ«Ø¨ÙŠØª Ø£Ø¯ÙˆØ§Øª Ù…Ø¬Ù‡ÙˆÙ„Ø© Ø§Ù„Ù…ØµØ¯Ø± Ø¹Ù„Ù‰ Ø¬Ù‡Ø§Ø² Ø§Ù„Ø·ÙÙ„.',
    ],
    incidentPlan: [
      'Ø¥ÙŠÙ‚Ø§Ù Ø§Ù„Ø£Ø¯ÙˆØ§Øª Ø§Ù„Ù…Ø¬Ù‡ÙˆÙ„Ø© ÙÙˆØ±Ù‹Ø§.',
      'ÙØ­Øµ Ø§Ù„Ø¬Ù‡Ø§Ø² ÙˆØ¥Ø²Ø§Ù„Ø© Ø§Ù„Ù…ØµØ§Ø¯Ø± ØºÙŠØ± Ø§Ù„Ù…ÙˆØ«ÙˆÙ‚Ø©.',
      'Ø¬Ù„Ø³Ø© ØªÙˆØ¶ÙŠØ­ Ù‚Ø§Ù†ÙˆÙ†ÙŠ Ù‚ØµÙŠØ±Ø©.',
      'Ø¥Ø¯Ø±Ø§Ø¬ Ù…Ø³Ø§Ø± ØªØ¹Ù„Ù… Ø£Ø®Ù„Ø§Ù‚ÙŠ Ø¨Ø¯ÙŠÙ„.',
      'Ù…ØªØ§Ø¨Ø¹Ø© Ø§Ù„ØªØ²Ø§Ù… Ø£Ø³Ø¨ÙˆØ¹ÙŠØ©.',
    ],
  },
  {
    id: 'phishing_links',
    title: 'التصيد والروابط الخبيثة',
    icon: '🔗',
    severity: AlertSeverity.CRITICAL,
    severityColor: 'bg-cyan-700',
    symptoms: [
      'استقبال روابط مختصرة أو صفحات دخول غير مألوفة بشكل متكرر.',
      'طلب رموز تحقق أو كلمة مرور بحجة التحقق من الحساب.',
      'خروج مفاجئ من الحسابات أو تنبيهات تسجيل دخول غير معروفة.',
    ],
    lurePatterns: [
      'رسائل عاجلة تطلب تحديث كلمة المرور فوراً.',
      'صفحات تسجيل دخول مزيفة مشابهة للمنصات المعروفة.',
      'روابط جوائز/هدايا تقود إلى جمع بيانات الحساب.',
    ],
    prevention: [
      'قاعدة ثابتة: لا فتح روابط حساسة قبل التحقق من الرابط الكامل.',
      'تفعيل 2FA وعدم مشاركة رموز التحقق مطلقاً.',
      'استخدام مدير كلمات مرور لتفادي إدخال بيانات في صفحات مزيفة.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'احتواء فوري', action: 'عزل الروابط، تغيير كلمات المرور، وإغلاق الجلسات المشبوهة.' },
      { week: 'الأسبوع 2', goal: 'تحصين الحسابات', action: 'تفعيل 2FA لكل الحسابات ومراجعة إعدادات الاسترداد.' },
      { week: 'الأسبوع 3', goal: 'رفع الوعي', action: 'تدريب عملي على التحقق من الروابط والبريد.' },
      { week: 'الأسبوع 4', goal: 'منع التكرار', action: 'قائمة نطاقات محظورة وتنبيهات استباقية للأسرة.' },
    ],
    dialogues: [
      {
        situation: 'إيقاف الضرر',
        opener: 'لن نفتح أي رابط جديد الآن. سنراجع كل الروابط معاً بخطوات واضحة.',
        advice: 'ابدأ بالطمأنة ثم انتقل مباشرة للإجراء التقني.',
      },
      {
        situation: 'تأمين الحساب',
        opener: 'سنغيّر كلمات المرور ونفعل التحقق الثنائي فوراً لحمايتك.',
        advice: 'اجعل الطفل شريكاً في عملية الأمان لا مجرد متلقي أوامر.',
      },
      {
        situation: 'تعزيز السلوك',
        opener: 'أي رابط يطلب كلمة مرور أو رمز تحقق يعتبر مشبوهاً حتى يثبت العكس.',
        advice: 'كرّر القاعدة يومياً حتى تتحول لعادات ثابتة.',
      },
    ],
    alertTemplates: [
      'تنبيه حرج: نمط تصيد/روابط خبيثة مرصود. تم تفعيل عزل الرابط وتأمين الحسابات.',
      'تنبيه متابعة: جارٍ تدوير كلمات المرور والتحقق من جلسات الدخول.',
    ],
    incidentPlan: [
      'إيقاف فتح الروابط المشبوهة فوراً.',
      'تغيير كلمات المرور للحسابات المتأثرة.',
      'تفعيل 2FA وإغلاق كل الجلسات النشطة غير الموثوقة.',
      'توثيق الرابط والرسالة الأصلية قبل الحذف.',
      'إبلاغ المنصة عن رسالة التصيد.',
    ],
  },
  {
    id: 'crypto_scams',
    title: 'Ø§Ù„Ø§Ø­ØªÙŠØ§Ù„ Ø§Ù„Ù…Ø§Ù„ÙŠ Ø§Ù„Ø±Ù‚Ù…ÙŠ',
    icon: 'ðŸ’¸',
    severity: AlertSeverity.MEDIUM,
    severityColor: 'bg-amber-600',
    symptoms: [
      'Ø§Ù†Ø¯ÙØ§Ø¹ ØªØ¬Ø§Ù‡ Ø£Ø±Ø¨Ø§Ø­ Ø³Ø±ÙŠØ¹Ø© ØºÙŠØ± Ù…ÙÙ‡ÙˆÙ…Ø©.',
      'Ø·Ù„Ø¨ Ù…ÙØ§Ø¬Ø¦ Ù„Ø¨Ø·Ø§Ù‚Ø§Øª Ø£Ùˆ ØªØ­ÙˆÙŠÙ„Ø§Øª Ø±Ù‚Ù…ÙŠØ©.',
      'Ø§Ù„ØªØ±ÙˆÙŠØ¬ Ù„Ù‚Ù†ÙˆØ§Øª Ø§Ø³ØªØ«Ù…Ø§Ø± ØºÙŠØ± Ù…ÙˆØ«ÙˆÙ‚Ø© Ø¨ÙŠÙ† Ø§Ù„Ø£ØµØ¯Ù‚Ø§Ø¡.',
    ],
    lurePatterns: [
      'ÙˆØ¹ÙˆØ¯ Ø¨Ø¹ÙˆØ§Ø¦Ø¯ Ù…Ø¶Ù…ÙˆÙ†Ø© Ø®Ù„Ø§Ù„ ÙˆÙ‚Øª Ù‚ØµÙŠØ±.',
      'Ø±ÙˆØ§Ø¨Ø· Airdrop/Ù…Ø­Ø§ÙØ¸ Ù…Ø²ÙŠÙØ©.',
      'Ø¶ØºØ· Ù…Ù† Ù…Ø¤Ø«Ø±ÙŠÙ† Ø£Ùˆ Ù…Ø¬Ù…ÙˆØ¹Ø§Øª ØªÙˆØµÙŠØ§Øª Ù…Ø¬Ù‡ÙˆÙ„Ø©.',
    ],
    prevention: [
      'Ø¥ÙŠÙ‚Ø§Ù Ø£ÙŠ ØªØ­ÙˆÙŠÙ„ Ø¨Ù„Ø§ Ù…ÙˆØ§ÙÙ‚Ø© ÙˆÙ„ÙŠ Ø§Ù„Ø£Ù…Ø±.',
      'Ø­Ø¸Ø± Ø§Ù„ÙƒÙ„Ù…Ø§Øª ÙˆØ§Ù„Ù‚Ù†ÙˆØ§Øª Ø§Ù„Ø§Ø­ØªÙŠØ§Ù„ÙŠØ© Ø§Ù„Ù…ØªÙƒØ±Ø±Ø©.',
      'ØªØ¹Ù„ÙŠÙ… Ù‚ÙˆØ§Ø¹Ø¯ Ø§Ù„ØªØ­Ù‚Ù‚ Ø§Ù„Ù…Ø§Ù„ÙŠ Ø§Ù„Ø£Ø³Ø§Ø³ÙŠ.',
    ],
    interventionProgram: [
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 1', goal: 'ØªØ¬Ù…ÙŠØ¯ Ø§Ù„Ù…Ø®Ø§Ø·Ø±', action: 'ÙˆÙ‚Ù Ø§Ù„Ù…Ø¯ÙÙˆØ¹Ø§Øª ØºÙŠØ± Ø§Ù„Ù…Ø¹ØªÙ…Ø¯Ø© ÙˆÙ…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„Ø­Ø±ÙƒØ© Ø§Ù„Ù…Ø§Ù„ÙŠØ©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 2', goal: 'ØªÙ†Ø¸ÙŠÙ Ø§Ù„Ù…ØµØ§Ø¯Ø±', action: 'Ø­Ø¸Ø± Ø§Ù„Ù‚Ù†ÙˆØ§Øª Ø§Ù„Ù…Ø´Ø¨ÙˆÙ‡Ø© ÙˆØªØ¯Ù‚ÙŠÙ‚ Ø§Ù„Ø±ÙˆØ§Ø¨Ø·.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 3', goal: 'Ø±ÙØ¹ Ø§Ù„ÙˆØ¹ÙŠ', action: 'Ø¬Ù„Ø³Ø© ÙˆØ¹ÙŠ Ù…Ø§Ù„ÙŠ Ù„Ù„Ø£Ø³Ø±Ø© Ù…Ø¹ Ø£Ù…Ø«Ù„Ø© Ø§Ø­ØªÙŠØ§Ù„ Ø´Ø§Ø¦Ø¹Ø©.' },
      { week: 'Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹ 4', goal: 'Ø¶Ø¨Ø· Ø¯Ø§Ø¦Ù…', action: 'Ø­Ø¯ÙˆØ¯ Ù…Ø§Ù„ÙŠØ© Ø´Ù‡Ø±ÙŠØ© ÙˆØ¥Ø´Ø¹Ø§Ø±Ø§Øª ÙÙˆØ±ÙŠØ©.' },
    ],
    dialogues: [
      {
        situation: 'ØªØµØ­ÙŠØ­ Ø§Ù„Ù…ÙÙ‡ÙˆÙ…',
        opener: 'Ø£ÙŠ Ø±Ø¨Ø­ Ø³Ø±ÙŠØ¹ Ù…Ø¶Ù…ÙˆÙ† ØºØ§Ù„Ø¨Ù‹Ø§ Ø®Ø·Ø±ØŒ Ø®Ù„Ù†Ø§ Ù†ØªØ­Ù‚Ù‚ Ù‚Ø¨Ù„ Ø£ÙŠ Ø®Ø·ÙˆØ©.',
        advice: 'Ø§Ù„ØªÙˆØ¹ÙŠØ© Ø§Ù„Ù…Ø§Ù„ÙŠØ© Ø§Ù„Ù…Ø¨ÙƒØ±Ø© ØªÙ‚Ù„Ù„ Ø§Ù„ØªÙˆØ±Ø·.',
      },
      {
        situation: 'Ø­Ø¯ÙˆØ¯ Ø§Ù„Ø£Ø³Ø±Ø©',
        opener: 'Ø£ÙŠ Ù…Ø¹Ø§Ù…Ù„Ø© Ø±Ù‚Ù…ÙŠØ© Ù„Ø§Ø²Ù… ØªÙ…Ø± Ø¨Ù…Ø±Ø§Ø¬Ø¹Ø© ÙˆÙ„ÙŠ Ø§Ù„Ø£Ù…Ø±.',
        advice: 'ØªØ­ÙˆÙŠÙ„ Ø§Ù„Ù‚Ø§Ø¹Ø¯Ø© Ø¥Ù„Ù‰ Ø¥Ø¬Ø±Ø§Ø¡ ÙˆØ§Ø¶Ø­ Ø¯Ø§Ø®Ù„ Ø§Ù„ØªØ·Ø¨ÙŠÙ‚.',
      },
      {
        situation: 'Ø¨Ø¯Ø§Ø¦Ù„ Ø¢Ù…Ù†Ø©',
        opener: 'Ù†ØªØ¹Ù„Ù… Ø§Ù„Ø§Ø³ØªØ«Ù…Ø§Ø± Ø§Ù„ØµØ­ÙŠØ­ Ù…Ù† Ù…ØµØ§Ø¯Ø± Ù…ÙˆØ«ÙˆÙ‚Ø© Ø¨Ø¯Ù„ Ø§Ù„Ù‚Ù†ÙˆØ§Øª Ø§Ù„Ø¹Ø´ÙˆØ§Ø¦ÙŠØ©.',
        advice: 'Ø§Ø³ØªØ¨Ø¯Ù„ Ø§Ù„Ù…Ù†Ø¹ Ø§Ù„Ù…Ø¬Ø±Ø¯ Ø¨Ù…Ø³Ø§Ø± ØªØ¹Ù„Ù… Ø¨Ø¯ÙŠÙ„.',
      },
    ],
    alertTemplates: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…Ø§Ù„ÙŠ: Ù†Ø´Ø§Ø· ØªØ­ÙˆÙŠÙ„ ØºÙŠØ± Ø§Ø¹ØªÙŠØ§Ø¯ÙŠ ÙŠØ­ØªØ§Ø¬ Ù…Ø±Ø§Ø¬Ø¹Ø© ÙÙˆØ±ÙŠØ©.',
      'ØªÙ†Ø¨ÙŠÙ‡ Ø§Ø­ØªÙŠØ§Ù„: Ø±ØµØ¯ ØªÙØ§Ø¹Ù„ Ù…Ø¹ Ù‚Ù†ÙˆØ§Øª Ø±Ø¨Ø­ Ø³Ø±ÙŠØ¹ Ù…Ø¬Ù‡ÙˆÙ„Ø©.',
    ],
    incidentPlan: [
      'Ø¥ÙŠÙ‚Ø§Ù Ø£ÙŠ Ø¹Ù…Ù„ÙŠØ© Ø¯ÙØ¹ Ù‚ÙŠØ¯ Ø§Ù„ØªÙ†ÙÙŠØ°.',
      'Ø­ØµØ± Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª ÙˆØ§Ù„Ù‚Ù†ÙˆØ§Øª Ø§Ù„Ù…ØªÙˆØ±Ø·Ø©.',
      'ØªØ£Ù…ÙŠÙ† ÙˆØ³ÙŠÙ„Ø© Ø§Ù„Ø¯ÙØ¹ Ø§Ù„Ù…Ø±ØªØ¨Ø·Ø©.',
      'Ø¥Ø¨Ù„Ø§Øº Ø§Ù„Ù…Ù†ØµØ©/Ø§Ù„Ø¨Ù†Ùƒ Ø­Ø³Ø¨ Ø§Ù„Ø­Ø§Ù„Ø©.',
      'Ø¬Ù„Ø³Ø© ØªÙˆØ¹ÙŠØ© Ù…Ø§Ù„ÙŠØ© Ù…Ø¨Ø§Ø´Ø±Ø© Ù„Ù„Ø·ÙÙ„.',
    ],
  },
];

const severityClassMap: Record<AlertSeverity, string> = {
  [AlertSeverity.CRITICAL]: 'bg-red-100 text-red-700 border-red-200',
  [AlertSeverity.HIGH]: 'bg-orange-100 text-orange-700 border-orange-200',
  [AlertSeverity.MEDIUM]: 'bg-amber-100 text-amber-700 border-amber-200',
  [AlertSeverity.LOW]: 'bg-emerald-100 text-emerald-700 border-emerald-200',
};

const severityTextMap: Record<AlertSeverity, string> = {
  [AlertSeverity.CRITICAL]: 'Ø­Ø±Ø¬',
  [AlertSeverity.HIGH]: 'Ù…Ø±ØªÙØ¹',
  [AlertSeverity.MEDIUM]: 'Ù…ØªÙˆØ³Ø·',
  [AlertSeverity.LOW]: 'Ù…Ù†Ø®ÙØ¶',
};

const inferScenarioId = (child?: Child): GuidanceScenario['id'] => {
  const profile = child?.psychProfile;
  if (profile?.priorityScenario) {
    return profile.priorityScenario;
  }

  const hay = (profile?.recentKeywords || []).join(' ');
  if (hay.includes('ØªÙ‡Ø¯ÙŠØ¯') || hay.includes('Ø§Ø¨ØªØ²Ø§Ø²')) return 'threat_exposure';
  if (hay.includes('ØªÙ†Ù…Ø±')) return 'bullying';
  if (hay.toLowerCase().includes('phishing') || hay.includes('تصيد') || hay.includes('رابط')) return 'phishing_links';
  if (hay.includes('Ø³Ù‡Ø±') || hay.includes('Ø¥Ø¯Ù…Ø§Ù†') || hay.includes('Ù„Ø¹Ø¨')) return 'gaming';
  if (hay.includes('Ø§Ø®ØªØ±Ø§Ù‚') || hay.includes('Ø³ÙƒØ±Ø¨Øª')) return 'cyber_crime';
  if (hay.includes('Ø§Ø³ØªØ«Ù…Ø§Ø±') || hay.includes('ØªØ­ÙˆÙŠÙ„')) return 'crypto_scams';
  if (hay.includes('Ø¥Ø¨Ø§Ø­ÙŠØ©') || hay.includes('Ù…Ø­ØªÙˆÙ‰')) return 'inappropriate_content';
  return 'bullying';
};

const scenarioToCategory = (
  scenarioId: PsychScenarioId,
  threatSubtype: ThreatExposureSubtype = 'direct_threat',
  contentSubtype: InappropriateContentSubtype = 'sexual_content'
): Category => {
  switch (scenarioId) {
    case 'bullying':
      return Category.BULLYING;
    case 'threat_exposure':
      if (threatSubtype === 'financial_blackmail') return Category.SCAM;
      if (threatSubtype === 'sexual_blackmail') return Category.SEXUAL_EXPLOITATION;
      return Category.BLACKMAIL;
    case 'gaming':
      return Category.SAFE;
    case 'inappropriate_content':
      return contentSubtype === 'violent_content' ? Category.VIOLENCE : Category.ADULT_CONTENT;
    case 'cyber_crime':
      return Category.PREDATOR;
    case 'crypto_scams':
      return Category.SCAM;
    case 'phishing_links':
      return Category.PHISHING_LINK;
    default:
      return Category.BULLYING;
  }
};

interface ThreatTrackProfile {
  id: ThreatExposureSubtype;
  badgeLabelAr: string;
  badgeLabelEn: string;
  narrativeAr: string;
  narrativeEn: string;
  incidentPlanAr: string[];
  incidentPlanEn: string[];
  alertTemplatesAr: string[];
  alertTemplatesEn: string[];
  preferWalkie: boolean;
  preferBlackout: boolean;
  preferCutInternet: boolean;
  preferSiren: boolean;
}

const threatTrackProfiles: Record<ThreatExposureSubtype, ThreatTrackProfile> = {
  direct_threat: {
    id: 'direct_threat',
    badgeLabelAr: 'ØªÙ‡Ø¯ÙŠØ¯ Ù…Ø¨Ø§Ø´Ø±',
    badgeLabelEn: 'Direct Threat',
    narrativeAr:
      'Ø§Ù„Ø®Ø·Ø± Ø§Ù„Ø­Ø§Ù„ÙŠ Ø£Ù‚Ø±Ø¨ Ø¥Ù„Ù‰ ØªÙ‡Ø¯ÙŠØ¯ Ù…Ø¨Ø§Ø´Ø±Ø› Ø§Ù„Ø£ÙˆÙ„ÙˆÙŠØ© Ù„Ø¹Ø²Ù„ Ø§Ù„ØªÙˆØ§ØµÙ„ Ø§Ù„Ù…Ø¤Ø°ÙŠØŒ ØªØ«Ø¨ÙŠØª Ø§Ù„Ù‚Ù†Ø§Ø© Ø§Ù„ØµÙˆØªÙŠØ© Ø§Ù„Ø¢Ù…Ù†Ø©ØŒ ÙˆØªÙˆØ«ÙŠÙ‚ Ø§Ù„Ø£Ø¯Ù„Ø© ÙÙˆØ±Ø§Ù‹.',
    narrativeEn:
      'The current pattern matches direct threat exposure. Prioritize immediate containment, safe voice channel, and evidence capture.',
    incidentPlanAr: [
      'Ù„Ø§ ØªÙØ§ÙˆØ¶ ÙˆÙ„Ø§ Ø±Ø¯ Ø§Ù†ÙØ¹Ø§Ù„ÙŠ Ù…Ø¹ Ø§Ù„Ø­Ø³Ø§Ø¨ Ø§Ù„Ù…Ù‡Ø¯Ø¯.',
      'ØªÙØ¹ÙŠÙ„ Ø§Ù„Ù‚ÙÙ„ Ø§Ù„ÙˆÙ‚Ø§Ø¦ÙŠ Ø§Ù„ÙÙˆØ±ÙŠ Ù…Ø¹ Ø´Ø§Ø´Ø© Ø­Ù…Ø§ÙŠØ©.',
      'ØªØ´ØºÙŠÙ„ Ù‚Ù†Ø§Ø© ØªÙˆØ§ØµÙ„ Ù…Ø¨Ø§Ø´Ø± (Walkie) Ù…Ø¹ Ø§Ù„Ø·ÙÙ„.',
      'Ø§Ù„ØªÙ‚Ø§Ø· Ø£Ø¯Ù„Ø© Ø§Ù„Ø´Ø§Ø´Ø© Ø«Ù… Ø±ÙØ¹ Ø¨Ù„Ø§Øº Ø§Ù„Ù…Ù†ØµØ©.',
      'ØªØµØ¹ÙŠØ¯ ÙÙˆØ±ÙŠ Ù„ÙˆÙ„ÙŠ Ø§Ù„Ø£Ù…Ø± Ø§Ù„Ù…Ù†Ø§ÙˆØ¨ Ø¹Ù†Ø¯ Ø§Ø³ØªÙ…Ø±Ø§Ø± Ø§Ù„ØªÙ‡Ø¯ÙŠØ¯.',
    ],
    incidentPlanEn: [
      'Do not negotiate or react emotionally to the threatening account.',
      'Enable immediate protective lock and blackout screen.',
      'Open a direct walkie channel with the child.',
      'Capture screen evidence, then report on platform.',
      'Escalate to on-duty guardian if threat persists.',
    ],
    alertTemplatesAr: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ø­Ø±Ø¬: Ù†Ù…Ø· ØªÙ‡Ø¯ÙŠØ¯ Ù…Ø¨Ø§Ø´Ø± Ù…Ø±ØµÙˆØ¯. ØªÙ… ØªÙØ¹ÙŠÙ„ Ø§Ù„Ø§Ø­ØªÙˆØ§Ø¡ Ø§Ù„ÙˆÙ‚Ø§Ø¦ÙŠ.',
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…ØªØ§Ø¨Ø¹Ø©: ØªÙ… ØªÙˆØ«ÙŠÙ‚ Ø§Ù„Ø£Ø¯Ù„Ø© ÙˆÙŠÙ†ØªØ¸Ø± Ø§Ù„Ø¥Ø¨Ù„Ø§Øº Ø§Ù„Ø±Ø³Ù…ÙŠ Ù„Ù„Ù…Ù†ØµØ©.',
    ],
    alertTemplatesEn: [
      'Critical alert: direct threat pattern detected. Protective containment enabled.',
      'Follow-up alert: evidence captured, pending official platform report.',
    ],
    preferWalkie: true,
    preferBlackout: true,
    preferCutInternet: false,
    preferSiren: true,
  },
  financial_blackmail: {
    id: 'financial_blackmail',
    badgeLabelAr: 'Ø§Ø¨ØªØ²Ø§Ø² Ù…Ø§Ù„ÙŠ',
    badgeLabelEn: 'Financial Blackmail',
    narrativeAr:
      'Ø§Ù„Ø®Ø·Ø± Ø§Ù„Ø­Ø§Ù„ÙŠ ÙŠØªØ¶Ù…Ù† Ø¶ØºØ·Ø§Ù‹ Ù…Ø§Ù„ÙŠØ§Ù‹Ø› Ø§Ù„Ø£ÙˆÙ„ÙˆÙŠØ© Ù„Ù‚Ø·Ø¹ Ù…Ø³Ø§Ø±Ø§Øª Ø§Ù„Ø¯ÙØ¹ØŒ Ø¹Ø²Ù„ Ø§Ù„Ø´Ø¨ÙƒØ© Ù…Ø¤Ù‚ØªØ§Ù‹ØŒ ÙˆØªØ£Ù…ÙŠÙ† Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª Ø§Ù„Ù…Ø±ØªØ¨Ø·Ø© Ø¨Ø§Ù„ØªØ­ÙˆÙŠÙ„.',
    narrativeEn:
      'The current pattern indicates financial blackmail. Prioritize payment freeze, temporary network quarantine, and account hardening.',
    incidentPlanAr: [
      'Ø¥ÙŠÙ‚Ø§Ù Ø£ÙŠ ØªØ­ÙˆÙŠÙ„ Ø£Ùˆ Ø¯ÙØ¹ ÙÙˆØ±ÙŠ ØªØ­Øª Ø§Ù„Ø¶ØºØ·.',
      'ØªÙØ¹ÙŠÙ„ Ø¹Ø²Ù„ Ø§Ù„Ø´Ø¨ÙƒØ© Ù…Ø¤Ù‚ØªØ§Ù‹ Ø­ØªÙ‰ Ø§Ù†ØªÙ‡Ø§Ø¡ Ø§Ù„Ù…Ø±Ø§Ø¬Ø¹Ø©.',
      'ØªØ£Ù…ÙŠÙ† Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª Ø§Ù„Ù…Ø§Ù„ÙŠØ© ÙˆØªØºÙŠÙŠØ± ÙƒÙ„Ù…Ø§Øª Ø§Ù„Ù…Ø±ÙˆØ±.',
      'ØªÙˆØ«ÙŠÙ‚ Ø§Ù„Ø±Ø³Ø§Ø¦Ù„ Ø§Ù„Ù…Ø§Ù„ÙŠØ© ÙˆØ±ÙˆØ§Ø¨Ø· Ø§Ù„Ø¯ÙØ¹ Ø§Ù„Ù…Ø´Ø¨ÙˆÙ‡Ø©.',
      'Ø¥Ø¨Ù„Ø§Øº Ø§Ù„Ù…Ù†ØµØ© ÙˆØ®Ø¯Ù…Ø© Ø§Ù„Ø¯ÙØ¹ Ø¹Ù† Ù…Ø­Ø§ÙˆÙ„Ø© Ø§Ù„Ø§Ø¨ØªØ²Ø§Ø².',
    ],
    incidentPlanEn: [
      'Stop all pressured transfers or payments immediately.',
      'Enable temporary network quarantine during investigation.',
      'Harden financial accounts and rotate passwords.',
      'Preserve payment requests and suspicious links as evidence.',
      'Report blackmail attempt to platform and payment provider.',
    ],
    alertTemplatesAr: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ø­Ø±Ø¬: Ù†Ù…Ø· Ø§Ø¨ØªØ²Ø§Ø² Ù…Ø§Ù„ÙŠ Ù…Ø±ØµÙˆØ¯. ØªÙ… ØªØ¬Ù…ÙŠØ¯ Ù…Ø³Ø§Ø±Ø§Øª Ø§Ù„Ø¯ÙØ¹ Ù…Ø¤Ù‚ØªØ§Ù‹.',
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…ØªØ§Ø¨Ø¹Ø©: ØªØ­Ù‚Ù‚ Ù…Ù† Ø§Ù„Ø­Ø³Ø§Ø¨Ø§Øª Ø§Ù„Ù…Ø§Ù„ÙŠØ© ÙˆØªÙˆØ«ÙŠÙ‚ Ø±ÙˆØ§Ø¨Ø· Ø§Ù„ØªØ­ÙˆÙŠÙ„ Ø¬Ø§Ø±Ù.',
    ],
    alertTemplatesEn: [
      'Critical alert: financial blackmail pattern detected. Payment channels temporarily frozen.',
      'Follow-up alert: financial account verification and transfer-link evidence in progress.',
    ],
    preferWalkie: false,
    preferBlackout: false,
    preferCutInternet: true,
    preferSiren: false,
  },
  sexual_blackmail: {
    id: 'sexual_blackmail',
    badgeLabelAr: 'Ø§Ø¨ØªØ²Ø§Ø² Ø¬Ù†Ø³ÙŠ',
    badgeLabelEn: 'Sexual Blackmail',
    narrativeAr:
      'Ø§Ù„Ø®Ø·Ø± Ø§Ù„Ø­Ø§Ù„ÙŠ ÙŠØ´ÙŠØ± Ø¥Ù„Ù‰ Ø§Ø¨ØªØ²Ø§Ø² Ø¬Ù†Ø³ÙŠØ› Ø§Ù„Ø£ÙˆÙ„ÙˆÙŠØ© Ù„Ù„ØªØ£Ù…ÙŠÙ† Ø§Ù„ÙÙˆØ±ÙŠØŒ Ù…Ù†Ø¹ Ø§Ù„ØªÙØ§ÙˆØ¶ØŒ Ø­ÙØ¸ Ø§Ù„Ø£Ø¯Ù„Ø©ØŒ ÙˆØ¨Ø¯Ø¡ Ù…Ø³Ø§Ø± Ø¥Ø¨Ù„Ø§Øº Ø±Ø³Ù…ÙŠ Ø³Ø±ÙŠØ¹.',
    narrativeEn:
      'The current pattern indicates sexual blackmail. Prioritize immediate protection, no negotiation, evidence preservation, and fast formal reporting.',
    incidentPlanAr: [
      'Ù„Ø§ ØªÙØ§ÙˆØ¶ ÙˆÙ„Ø§ Ø¥Ø±Ø³Ø§Ù„ Ø£ÙŠ Ù…Ø­ØªÙˆÙ‰ Ø¥Ø¶Ø§ÙÙŠ Ù…Ø·Ù„Ù‚Ø§Ù‹.',
      'ØªÙØ¹ÙŠÙ„ Ø§Ù„Ù‚ÙÙ„ Ø§Ù„ÙˆÙ‚Ø§Ø¦ÙŠ ÙˆØ´Ø§Ø´Ø© Ø§Ù„Ø­Ù…Ø§ÙŠØ© ÙÙˆØ±Ø§Ù‹.',
      'Ø§Ù„ØªÙ‚Ø§Ø· Ø§Ù„Ø£Ø¯Ù„Ø© (Ø§Ù„Ù…Ø¹Ø±ÙØ§Øª/Ø§Ù„Ø±Ø³Ø§Ø¦Ù„/Ø§Ù„ÙˆÙ‚Øª) Ù‚Ø¨Ù„ Ø£ÙŠ Ø­Ø°Ù.',
      'ÙØªØ­ Ù‚Ù†Ø§Ø© Walkie Ù„Ø¯Ø¹Ù… Ø§Ù„Ø·ÙÙ„ ÙˆØ·Ù…Ø£Ù†ØªÙ‡ ÙÙˆØ±ÙŠØ§Ù‹.',
      'Ø¨Ø¯Ø¡ Ù…Ø³Ø§Ø± Ø¥Ø¨Ù„Ø§Øº Ø±Ø³Ù…ÙŠ Ù„Ù„Ù…Ù†ØµØ© ÙˆØ§Ù„Ø¬Ù‡Ø§Øª Ø§Ù„Ù…Ø®ØªØµØ©.',
    ],
    incidentPlanEn: [
      'Do not negotiate and never send any additional content.',
      'Enable immediate protective lock and safety blackout screen.',
      'Capture identifiers/messages/timestamps before any deletion.',
      'Open walkie channel for immediate reassurance and support.',
      'Trigger fast formal reporting to platform and authorities.',
    ],
    alertTemplatesAr: [
      'ØªÙ†Ø¨ÙŠÙ‡ Ø­Ø±Ø¬ Ø¬Ø¯Ø§Ù‹: Ø§Ø´ØªØ¨Ø§Ù‡ Ø§Ø¨ØªØ²Ø§Ø² Ø¬Ù†Ø³ÙŠ. ØªÙ… ØªÙØ¹ÙŠÙ„ Ø§Ù„Ø­Ù…Ø§ÙŠØ© Ø§Ù„ÙÙˆØ±ÙŠØ©.',
      'ØªÙ†Ø¨ÙŠÙ‡ Ù…ØªØ§Ø¨Ø¹Ø©: Ø­ÙØ¸ Ø§Ù„Ø£Ø¯Ù„Ø© ÙˆØ¨Ø¯Ø¡ Ù…Ø³Ø§Ø± Ø§Ù„Ø¥Ø¨Ù„Ø§Øº Ø§Ù„Ø±Ø³Ù…ÙŠ.',
    ],
    alertTemplatesEn: [
      'Extreme alert: suspected sexual blackmail. Immediate protection has been activated.',
      'Follow-up alert: evidence preserved and formal reporting flow started.',
    ],
    preferWalkie: true,
    preferBlackout: true,
    preferCutInternet: false,
    preferSiren: false,
  },
};

const inferThreatSubtypeFromKeywords = (keywords: string[]): ThreatExposureSubtype => {
  const hay = (keywords || []).join(' ').toLowerCase();
  if (
    hay.includes('Ø§Ø¨ØªØ²Ø§Ø² Ø¬Ù†Ø³ÙŠ') ||
    hay.includes('Ø§Ø³ØªØºÙ„Ø§Ù„ Ø¬Ù†Ø³ÙŠ') ||
    hay.includes('sextortion') ||
    hay.includes('private photos') ||
    hay.includes('nude')
  ) {
    return 'sexual_blackmail';
  }
  if (
    hay.includes('Ø§Ø¨ØªØ²Ø§Ø² Ù…Ø§Ù„ÙŠ') ||
    hay.includes('ØªØ­ÙˆÙŠÙ„') ||
    hay.includes('Ø¯ÙØ¹') ||
    hay.includes('gift card') ||
    hay.includes('wallet')
  ) {
    return 'financial_blackmail';
  }
  return 'direct_threat';
};

interface ContentTrackProfile {
  id: InappropriateContentSubtype;
  badgeLabelAr: string;
  badgeLabelEn: string;
  narrativeAr: string;
  narrativeEn: string;
  incidentPlanAr: string[];
  incidentPlanEn: string[];
  alertTemplatesAr: string[];
  alertTemplatesEn: string[];
  preferBlackout: boolean;
  preferSiren: boolean;
}

const contentTrackProfiles: Record<InappropriateContentSubtype, ContentTrackProfile> = {
  sexual_content: {
    id: 'sexual_content',
    badgeLabelAr: 'محتوى جنسي',
    badgeLabelEn: 'Sexual Content',
    narrativeAr:
      'المؤشر الحالي يرتبط بتعرض لمحتوى جنسي غير مناسب؛ الأولوية لتشديد الفلترة، التهدئة، وحوار احتوائي بلا لوم.',
    narrativeEn:
      'Current pattern indicates exposure to sexual explicit content. Prioritize tighter filtering, calm handling, and non-blaming guidance.',
    incidentPlanAr: [
      'إيقاف المصدر المسبب فوراً (رابط/حساب/تطبيق).',
      'رفع مستوى الفلترة وSafeSearch بحسب العمر.',
      'جلسة حوار قصيرة بلا لوم مع الطفل.',
      'تفعيل قائمة مواقع بديلة آمنة.',
      'متابعة أسبوعية لقياس التكرار.',
    ],
    incidentPlanEn: [
      'Block the source immediately (link/account/app).',
      'Increase filtering and SafeSearch strictness.',
      'Run a short non-blaming discussion with the child.',
      'Provide trusted safe alternatives.',
      'Track recurrence weekly.',
    ],
    alertTemplatesAr: [
      'تنبيه مرتفع: تعرض محتمل لمحتوى جنسي غير مناسب. تم تشديد الفلترة.',
      'تنبيه متابعة: تم تنفيذ خطة احتواء تربوي ومراجعة مصدر الوصول.',
    ],
    alertTemplatesEn: [
      'High alert: potential sexual explicit-content exposure. Filtering has been tightened.',
      'Follow-up alert: educational containment plan and source review completed.',
    ],
    preferBlackout: false,
    preferSiren: false,
  },
  violent_content: {
    id: 'violent_content',
    badgeLabelAr: 'محتوى عنيف',
    badgeLabelEn: 'Violent Content',
    narrativeAr:
      'المؤشر الحالي يرتبط بتعرض متكرر لمحتوى عنيف/تحريضي؛ الأولوية للاحتواء الفوري، التهدئة، وتقليل محفزات العنف.',
    narrativeEn:
      'Current pattern indicates repeated exposure to violent/harmful content. Prioritize immediate containment and de-escalation.',
    incidentPlanAr: [
      'إيقاف المصدر العنيف وحظر الحساب/القناة المرتبطة.',
      'تفعيل شاشة حماية مؤقتة مع رسالة تهدئة.',
      'مراجعة سجل المشاهدة وتحديد نقاط الاستدراج.',
      'جلسة توعية حول الفرق بين المحتوى الترفيهي والتحريض.',
      'متابعة يومية قصيرة حتى استقرار النمط.',
    ],
    incidentPlanEn: [
      'Block the violent source and related account/channel.',
      'Enable temporary safety blackout with calming message.',
      'Review watch history and lure vectors.',
      'Run a brief guidance talk about harmful content.',
      'Track daily until pattern stabilizes.',
    ],
    alertTemplatesAr: [
      'تنبيه حرج: تعرض متكرر لمحتوى عنيف/تحريضي. تم بدء الاحتواء الوقائي.',
      'تنبيه متابعة: جارٍ تقليل محفزات العنف ومراجعة القنوات المرتبطة.',
    ],
    alertTemplatesEn: [
      'Critical alert: repeated violent-content exposure detected. Protective containment started.',
      'Follow-up alert: violence triggers are being reduced and channels reviewed.',
    ],
    preferBlackout: true,
    preferSiren: true,
  },
};

const inferContentSubtypeFromKeywords = (keywords: string[]): InappropriateContentSubtype => {
  const hay = (keywords || []).join(' ').toLowerCase();
  if (
    hay.includes('violent') ||
    hay.includes('gore') ||
    hay.includes('عنيف') ||
    hay.includes('تحريض') ||
    hay.includes('دموي')
  ) {
    return 'violent_content';
  }
  return 'sexual_content';
};

const PsychologicalInsightView: React.FC<PsychologicalInsightViewProps> = ({
  theme,
  child,
  alerts = [],
  lang = 'ar',
  onAcceptPlan,
  onApplyModeToChild,
  onPlanExecutionResult,
  onSaveExecutionEvidence,
}) => {
  const profile = child?.psychProfile;
  const navigate = useNavigate();
  const primaryCardRef = useRef<HTMLDivElement | null>(null);
  const radarContainerRef = useRef<HTMLDivElement | null>(null);
  const trendContainerRef = useRef<HTMLDivElement | null>(null);
  const [radarSize, setRadarSize] = useState({ width: 0, height: 0 });
  const [trendSize, setTrendSize] = useState({ width: 0, height: 0 });
  const diagnosis = useMemo(
    () => diagnosePsychScenarioFromAlerts(child?.name || '', alerts),
    [child?.name, alerts]
  );

  const [activeScenarioId, setActiveScenarioId] = useState<GuidanceScenario['id']>(
    diagnosis?.scenarioId || inferScenarioId(child)
  );
  const [copiedPlan, setCopiedPlan] = useState(false);
  const [autoSelection, setAutoSelection] = useState<Record<string, boolean>>({});
  const [autoStatus, setAutoStatus] = useState<Record<string, AutoStepStatus>>({});
  const [isAutoRunning, setIsAutoRunning] = useState(false);
  const [autoRunSummary, setAutoRunSummary] = useState('');
  const [executionTimeline, setExecutionTimeline] = useState<PlanTimelineEntry[]>([]);
  const [timelineFilter, setTimelineFilter] = useState<'all' | PlanTimelineStatus>('all');
  const [isSavingExecutionEvidence, setIsSavingExecutionEvidence] = useState(false);
  const [planVideoSource, setPlanVideoSource] = useState<PlanVideoSource>('screen');
  const [planAudioSource, setPlanAudioSource] = useState<PlanAudioSource>('mic');
  const [playbooks, setPlaybooks] = useState<SafetyPlaybook[]>([]);
  const [blackoutMessage, setBlackoutMessage] = useState(
    lang === 'ar'
      ? 'ØªÙ… Ù‚ÙÙ„ Ø§Ù„Ø¬Ù‡Ø§Ø² Ù„Ø¯ÙˆØ§Ø¹ÙŠ Ø§Ù„Ø£Ù…Ø§Ù†. ÙŠØ±Ø¬Ù‰ Ø§Ù„ØªÙˆØ§ØµÙ„ Ù…Ø¹ Ø§Ù„ÙˆØ§Ù„Ø¯ÙŠÙ†.'
      : 'Device locked for safety. Please contact a parent.'
  );

  const activeScenario = useMemo(
    () => guidanceScenarios.find((s) => s.id === activeScenarioId) || guidanceScenarios[0],
    [activeScenarioId]
  );

  const threatSubtype = useMemo<ThreatExposureSubtype>(() => {
    if (activeScenario.id !== 'threat_exposure') return 'direct_threat';
    return diagnosis?.threatSubtype || inferThreatSubtypeFromKeywords(child?.psychProfile?.recentKeywords || []);
  }, [activeScenario.id, child?.psychProfile?.recentKeywords, diagnosis?.threatSubtype]);

  const contentSubtype = useMemo<InappropriateContentSubtype>(() => {
    if (activeScenario.id !== 'inappropriate_content') return 'sexual_content';
    return diagnosis?.contentSubtype || inferContentSubtypeFromKeywords(child?.psychProfile?.recentKeywords || []);
  }, [activeScenario.id, child?.psychProfile?.recentKeywords, diagnosis?.contentSubtype]);

  const activeThreatTrack = useMemo(
    () => threatTrackProfiles[threatSubtype],
    [threatSubtype]
  );

  const activeContentTrack = useMemo(
    () => contentTrackProfiles[contentSubtype],
    [contentSubtype]
  );

  const resolvedIncidentPlan = useMemo(() => {
    if (activeScenario.id === 'threat_exposure') {
      return lang === 'ar' ? activeThreatTrack.incidentPlanAr : activeThreatTrack.incidentPlanEn;
    }
    if (activeScenario.id === 'inappropriate_content') {
      return lang === 'ar' ? activeContentTrack.incidentPlanAr : activeContentTrack.incidentPlanEn;
    }
    return activeScenario.incidentPlan;
  }, [activeScenario.id, activeScenario.incidentPlan, activeThreatTrack, activeContentTrack, lang]);

  const resolvedAlertTemplates = useMemo(() => {
    if (activeScenario.id === 'threat_exposure') {
      return lang === 'ar' ? activeThreatTrack.alertTemplatesAr : activeThreatTrack.alertTemplatesEn;
    }
    if (activeScenario.id === 'inappropriate_content') {
      return lang === 'ar' ? activeContentTrack.alertTemplatesAr : activeContentTrack.alertTemplatesEn;
    }
    return activeScenario.alertTemplates;
  }, [activeScenario.id, activeScenario.alertTemplates, activeThreatTrack, activeContentTrack, lang]);

  const fallbackBlackoutMessage = useMemo(
    () =>
      lang === 'ar'
        ? 'ØªÙ… Ù‚ÙÙ„ Ø§Ù„Ø¬Ù‡Ø§Ø² Ù„Ø¯ÙˆØ§Ø¹ÙŠ Ø§Ù„Ø£Ù…Ø§Ù†. ÙŠØ±Ø¬Ù‰ Ø§Ù„ØªÙˆØ§ØµÙ„ Ù…Ø¹ Ø§Ù„ÙˆØ§Ù„Ø¯ÙŠÙ†.'
        : 'Device locked for safety. Please contact a parent.',
    [lang]
  );

  useEffect(() => {
    setActiveScenarioId(diagnosis?.scenarioId || inferScenarioId(child));
  }, [
    child?.id,
    child?.psychProfile?.priorityScenario,
    child?.psychProfile?.recentKeywords,
    diagnosis?.scenarioId,
  ]);

  useEffect(() => {
    let mounted = true;
    const loadPlaybooks = async () => {
      if (!child?.parentId) {
        if (mounted) setPlaybooks([]);
        return;
      }
      try {
        const stored = await fetchPlaybooks(child.parentId);
        if (!mounted) return;
        setPlaybooks(stored);
      } catch (error) {
        if (!mounted) return;
        console.warn('Failed to load psychological playbooks:', error);
        setPlaybooks([]);
      }
    };
    void loadPlaybooks();
    return () => {
      mounted = false;
    };
  }, [child?.parentId]);

  useEffect(() => {
    if (!blackoutMessage.trim()) {
      setBlackoutMessage(fallbackBlackoutMessage);
    }
  }, [blackoutMessage, fallbackBlackoutMessage]);

  useEffect(() => {
    const el = primaryCardRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollIntoView({ behavior: 'auto', block: 'start' });
      el.focus({ preventScroll: true });
    });
  }, [child?.id]);

  useEffect(() => {
    const node = radarContainerRef.current;
    if (!node) return;

    let raf = 0;
    const checkReady = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const rect = node.getBoundingClientRect();
        setRadarSize({
          width: Math.max(0, Math.floor(rect.width)),
          height: Math.max(0, Math.floor(rect.height)),
        });
      });
    };

    checkReady();
    const observer = new ResizeObserver(checkReady);
    observer.observe(node);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [child?.id]);

  useEffect(() => {
    const node = trendContainerRef.current;
    if (!node) return;

    let raf = 0;
    const checkReady = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const rect = node.getBoundingClientRect();
        setTrendSize({
          width: Math.max(0, Math.floor(rect.width)),
          height: Math.max(0, Math.floor(rect.height)),
        });
      });
    };

    checkReady();
    const observer = new ResizeObserver(checkReady);
    observer.observe(node);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [child?.id]);

  if (!child || !profile) {
    return <div className="p-20 text-center font-black">Ø¬Ø§Ø±ÙŠ ØªØ­Ù„ÙŠÙ„ Ø§Ù„Ù†Ø¨Ø¶ Ø§Ù„Ù†ÙØ³ÙŠ...</div>;
  }

  const stabilityScore = Math.round((profile.moodScore + (100 - profile.anxietyLevel)) / 2);
  const readinessScore = profile.incidentReadinessScore ?? Math.max(35, 95 - profile.anxietyLevel);
  const frustrationScore = Math.max(0, Math.min(100, Math.round(100 - profile.moodScore)));
  const aggressionScore = Math.max(
    0,
    Math.min(
      100,
      Math.round(
        profile.anxietyLevel * 0.4 +
          profile.isolationRisk * 0.35 +
          frustrationScore * 0.25
      )
    )
  );
  const quickAdvisorTip =
    diagnosis?.topSignals?.[0]?.suggestedAction ||
    activeScenario.dialogues[0]?.advice ||
    profile.recommendation;

  const radarData = [
    { subject: 'Ù‚Ù„Ù‚', A: profile.anxietyLevel, fullMark: 100 },
    { subject: 'Ø¥Ø­Ø¨Ø§Ø·', A: frustrationScore, fullMark: 100 },
    { subject: 'Ø¹Ø²Ù„Ø©', A: profile.isolationRisk, fullMark: 100 },
    { subject: 'Ø¹Ø¯ÙˆØ§Ù†ÙŠØ©', A: aggressionScore, fullMark: 100 },
    { subject: 'Ù‡Ø¯ÙˆØ¡', A: profile.moodScore, fullMark: 100 },
  ];

  const weeklyTrend =
    profile.weeklyTrend && profile.weeklyTrend.length > 0
      ? profile.weeklyTrend
      : [
          { label: 'Ø§Ù„Ø§Ø«Ù†ÙŠÙ†', value: 58 },
          { label: 'Ø§Ù„Ø«Ù„Ø§Ø«Ø§Ø¡', value: 62 },
          { label: 'Ø§Ù„Ø£Ø±Ø¨Ø¹Ø§Ø¡', value: 55 },
          { label: 'Ø§Ù„Ø®Ù…ÙŠØ³', value: 64 },
          { label: 'Ø§Ù„Ø¬Ù…Ø¹Ø©', value: 60 },
        ];

  const riskSignals = useMemo(() => {
    const diagnosticSignals = diagnosis?.topSignals || [];
    const profileSignals = profile.riskSignals || [];
    const merged = [...diagnosticSignals, ...profileSignals];
    if (merged.length > 0) {
      const unique = new Map<string, (typeof merged)[number]>();
      for (const signal of merged) {
        const key = `${signal.title}-${signal.severity}`;
        if (!unique.has(key)) {
          unique.set(key, signal);
        }
      }
      return Array.from(unique.values()).slice(0, 4);
    }
    return [
      {
        id: `fallback-${activeScenario.id}`,
        title: activeScenario.title,
        severity: activeScenario.severity,
        reason: activeScenario.symptoms[0],
        suggestedAction: resolvedIncidentPlan[0] || activeScenario.incidentPlan[0],
      },
    ];
  }, [diagnosis?.topSignals, profile.riskSignals, activeScenario, resolvedIncidentPlan]);

  const childAlerts = useMemo(() => {
    const norm = (value?: string) => (value || '').toLowerCase().replace(/\s+/g, ' ').trim();
    const childNameNorm = norm(child.name);
    return alerts
      .filter((alert) => {
        const alertNameNorm = norm(alert.childName);
        return (
          !!alertNameNorm &&
          !!childNameNorm &&
          (alertNameNorm === childNameNorm ||
            alertNameNorm.includes(childNameNorm) ||
            childNameNorm.includes(alertNameNorm))
        );
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [alerts, child.name]);

  const dominantPlatform = useMemo(() => {
    const count = new Map<string, number>();
    for (const alert of childAlerts) {
      const key = (alert.platform || 'Unknown').trim();
      count.set(key, (count.get(key) || 0) + 1);
    }
    const sorted = Array.from(count.entries()).sort((a, b) => b[1] - a[1]);
    return sorted[0]?.[0] || childAlerts[0]?.platform || 'Discord';
  }, [childAlerts]);

  const dominantSeverity = useMemo<AlertSeverity>(() => {
    if (diagnosis?.topSignals?.[0]?.severity) {
      return diagnosis.topSignals[0].severity;
    }
    const fromAlerts = childAlerts[0]?.severity;
    return fromAlerts || activeScenario.severity;
  }, [diagnosis?.topSignals, childAlerts, activeScenario.severity]);

  const highRiskApp = useMemo(() => {
    const apps = child.appUsage || [];
    if (apps.length === 0) return null;
    const platformNorm = dominantPlatform.toLowerCase();
    const direct = apps.find((app) => app.appName.toLowerCase().includes(platformNorm));
    if (direct) return direct;
    const fallback = apps.find((app) =>
      ['discord', 'telegram', 'roblox', 'tiktok', 'snapchat', 'youtube'].some((name) =>
        app.appName.toLowerCase().includes(name)
      )
    );
    return fallback || apps[0];
  }, [child.appUsage, dominantPlatform]);

  const blockedDomains = useMemo(
    () => scenarioBlockedDomains[activeScenario.id] || [],
    [activeScenario.id]
  );

  const playbookDrivenSteps = useMemo<AutoExecutionStep[]>(() => {
    const category = scenarioToCategory(activeScenario.id, threatSubtype, contentSubtype);
    const actions = getDefenseActionsWithPlaybooks(category, dominantSeverity, playbooks);

    const priorityToSeverity = (priority: string): AlertSeverity => {
      if (priority === 'critical') return AlertSeverity.CRITICAL;
      if (priority === 'high') return AlertSeverity.HIGH;
      if (priority === 'medium') return AlertSeverity.MEDIUM;
      return AlertSeverity.LOW;
    };

    return actions
      .map((action) => ({
        id: `pb-${action.id}`,
        title: lang === 'ar' ? `Ø¥Ø¬Ø±Ø§Ø¡ Ø¨Ø±ÙˆØªÙˆÙƒÙˆÙ„: ${action.label}` : `Playbook Action: ${action.label}`,
        description:
          lang === 'ar'
            ? 'Ø®Ø·ÙˆØ© Ù…Ø³ØªØ±Ø¬Ø¹Ø© Ù…Ù† Ø¨Ø±ÙˆØªÙˆÙƒÙˆÙ„Ø§Øª Ø§Ù„Ø­Ù…Ø§ÙŠØ© Ø§Ù„Ù…Ø®ØµØµØ© Ù„Ù„Ø¹Ø§Ø¦Ù„Ø©.'
            : 'A family-configured action restored from safety playbooks.',
        command: action.command as AutoExecutionStep['command'],
        value: action.payload ?? true,
        minSeverity: priorityToSeverity(action.priority),
        enabledByDefault: true,
      }));
  }, [activeScenario.id, contentSubtype, dominantSeverity, lang, playbooks, threatSubtype]);

  useEffect(() => {
    if (activeScenario.id === 'gaming') {
      setPlanVideoSource('screen');
      setPlanAudioSource('system');
      return;
    }
    if (activeScenario.id === 'bullying') {
      setPlanVideoSource('camera_front');
      setPlanAudioSource('mic');
      return;
    }
    if (activeScenario.id === 'threat_exposure') {
      if (threatSubtype === 'financial_blackmail') {
        setPlanVideoSource('screen');
        setPlanAudioSource('system');
        return;
      }
      setPlanVideoSource('camera_front');
      setPlanAudioSource('mic');
      return;
    }
    if (activeScenario.id === 'inappropriate_content') {
      if (contentSubtype === 'violent_content') {
        setPlanVideoSource('camera_front');
        setPlanAudioSource('mic');
        return;
      }
      setPlanVideoSource('screen');
      setPlanAudioSource('system');
      return;
    }
    if (activeScenario.id === 'phishing_links') {
      setPlanVideoSource('screen');
      setPlanAudioSource('system');
      return;
    }
    setPlanVideoSource('screen');
    setPlanAudioSource('mic');
  }, [activeScenario.id, child.id, contentSubtype, threatSubtype]);

  const digitalBalanceNarrative = useMemo(() => {
    const appLabel = highRiskApp?.appName || dominantPlatform;
    if (activeScenario.id === 'threat_exposure') {
      const base = lang === 'ar' ? activeThreatTrack.narrativeAr : activeThreatTrack.narrativeEn;
      return `${base} (${appLabel}).`;
    }
    if (activeScenario.id === 'inappropriate_content') {
      const base = lang === 'ar' ? activeContentTrack.narrativeAr : activeContentTrack.narrativeEn;
      return `${base} (${appLabel}).`;
    }
    if (activeScenario.id === 'bullying') {
      return `نوصي بتشديد الخصوصية داخل ${appLabel}، تقييد المراسلة من الغرباء، وتفعيل بروتوكول "وثّق/احظر/بلّغ" تلقائياً.`;
    }
    if (activeScenario.id === 'gaming') {
      return `نوصي بضبط ${appLabel} عبر وضع متوازن: جلسات لعب مجدولة + إيقاف الإشعارات المشتتة + منع الانضمام لغرف عامة مرتفعة المخاطر.`;
    }
    return `نوصي بخطة توازن رقمي مخصصة لـ ${appLabel}: تقليل سطح التعرض، رفع الرقابة اللحظية، وتفعيل استجابة تلقائية عند ارتفاع المخاطر.`;
  }, [activeScenario.id, activeContentTrack, activeThreatTrack, dominantPlatform, highRiskApp?.appName, lang]);

  const autoExecutionSteps = useMemo<AutoExecutionStep[]>(
    () => {
      const baseSteps: AutoExecutionStep[] = [
      {
        id: 'snapshot',
        title: 'ØªÙˆØ«ÙŠÙ‚ ÙÙˆØ±ÙŠ',
        description: 'Ø£Ø®Ø° Ù„Ù‚Ø·Ø© Ø´Ø§Ø´Ø© ÙÙˆØ±ÙŠØ© Ù„Ø¥Ø«Ø¨Ø§Øª Ø§Ù„Ø­Ø§Ù„Ø© Ø§Ù„Ø­Ø§Ù„ÙŠØ©.',
        command: 'takeScreenshot',
        value: true,
        minSeverity: AlertSeverity.LOW,
        enabledByDefault: true,
      },
      {
        id: 'block-app',
        title: 'Ø­Ø¸Ø± Ø§Ù„ØªØ·Ø¨ÙŠÙ‚ Ø§Ù„Ø£Ø¹Ù„Ù‰ Ø®Ø·ÙˆØ±Ø©',
        description: highRiskApp
          ? `ØªÙØ¹ÙŠÙ„ Ø­Ø¸Ø± ${highRiskApp.appName} Ù…Ø¤Ù‚ØªÙ‹Ø§ Ù„Ø­ÙŠÙ† Ù…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„Ù…Ø´Ø±Ù.`
          : 'Ù„Ø§ ÙŠÙˆØ¬Ø¯ ØªØ·Ø¨ÙŠÙ‚ Ù…Ø±ØµÙˆØ¯ Ù„ÙŠØªÙ… Ø­Ø¸Ø±Ù‡ ØªÙ„Ù‚Ø§Ø¦ÙŠÙ‹Ø§.',
        command: 'blockApp',
        value: highRiskApp
          ? { appId: highRiskApp.id, isBlocked: true, reason: 'digital_balance_auto' }
          : null,
        minSeverity: AlertSeverity.MEDIUM,
        enabledByDefault: !!highRiskApp,
      },
      {
        id: 'video-source',
        title: 'Ø¶Ø¨Ø· Ù…ØµØ¯Ø± Ø§Ù„ØµÙˆØ±Ø©',
        description: 'ØªØ­Ø¯ÙŠØ¯ Ù…ØµØ¯Ø± Ø§Ù„Ø¨Ø«: Ø´Ø§Ø´Ø© Ø§Ù„Ø¬Ù‡Ø§Ø².',
        command: 'setVideoSource',
        value: planVideoSource,
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: true,
      },
      {
        id: 'audio-source',
        title: 'Ø¶Ø¨Ø· Ù…ØµØ¯Ø± Ø§Ù„ØµÙˆØª',
        description: 'ØªØ­Ø¯ÙŠØ¯ Ù…ØµØ¯Ø± Ø§Ù„ØµÙˆØª: Ù…ÙŠÙƒØ±ÙˆÙÙˆÙ† Ø§Ù„Ø¬Ù‡Ø§Ø².',
        command: 'setAudioSource',
        value: planAudioSource,
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: true,
      },
      {
        id: 'start-stream',
        title: 'Ø¨Ø¯Ø¡ Ø¨Ø« Ø±Ù‚Ø§Ø¨ÙŠ Ù…Ø¨Ø§Ø´Ø±',
        description: 'ØªØ´ØºÙŠÙ„ Ø¨Ø« Ù…Ø¨Ø§Ø´Ø± Ù„Ù„Ù…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„Ø³Ø±ÙŠØ¹Ø© Ù…Ù† ÙˆÙ„ÙŠ Ø§Ù„Ø£Ù…Ø±.',
        command: 'startLiveStream',
        value: {
          videoSource: planVideoSource,
          audioSource: planAudioSource,
          source: 'digital_balance_auto',
        },
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: true,
      },
      {
        id: 'lock-device',
        title: 'Ù‚ÙÙ„ ÙˆÙ‚Ø§Ø¦ÙŠ Ù…Ø¤Ù‚Øª',
        description: 'Ù‚ÙÙ„ Ù…Ø¤Ù‚Øª Ù„Ù„Ø¬Ù‡Ø§Ø² Ø­ØªÙ‰ Ø§ÙƒØªÙ…Ø§Ù„ Ø§Ù„ØªÙ‚ÙŠÙŠÙ….',
        command: 'lockDevice',
        value: true,
        minSeverity: AlertSeverity.CRITICAL,
        enabledByDefault: true,
      },
      {
        id: 'blackout-screen',
        title: 'Ø´Ø§Ø´Ø© Ø³ÙˆØ¯Ø§Ø¡ Ø¨Ø±Ø³Ø§Ù„Ø© Ø­Ù…Ø§ÙŠØ©',
        description: 'ØªÙØ¹ÙŠÙ„ Ø­Ø¬Ø¨ Ø§Ù„Ø¬Ù‡Ø§Ø² Ù…Ø¹ Ø±Ø³Ø§Ù„Ø© Ø¥Ø±Ø´Ø§Ø¯ÙŠØ© Ù„Ù„Ø·ÙÙ„ Ø­ØªÙ‰ Ù…Ø±Ø§Ø¬Ø¹Ø© Ø§Ù„ÙˆØ§Ù„Ø¯ÙŠÙ†.',
        command: 'lockscreenBlackout',
        value: { enabled: true, source: 'digital_balance_auto' },
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault:
          activeScenario.id === 'bullying' ||
          (activeScenario.id === 'threat_exposure' && activeThreatTrack.preferBlackout) ||
          (activeScenario.id === 'inappropriate_content' && activeContentTrack.preferBlackout),
      },
      {
        id: 'walkie-enable',
        title: 'ØªÙØ¹ÙŠÙ„ Ù‚Ù†Ø§Ø© Walkie-Talkie',
        description: 'ØªÙØ¹ÙŠÙ„ Ù‚Ù†Ø§Ø© Ø§Ù„ØªÙˆØ§ØµÙ„ Ø§Ù„ØµÙˆØªÙŠ Ø§Ù„ÙÙˆØ±ÙŠ Ø¨ÙŠÙ† Ø§Ù„ÙˆØ§Ù„Ø¯ ÙˆØ§Ù„Ø·ÙÙ„.',
        command: 'walkieTalkieEnable',
        value: { enabled: true, source: 'mic' },
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault:
          activeScenario.id === 'threat_exposure' && activeThreatTrack.preferWalkie,
      },
      {
        id: 'net-quarantine',
        title: 'عزل الشبكة مؤقتاً',
        description: 'قطع اتصال الإنترنت مؤقتاً لمنع التحويلات أو استكمال المسارات الخطرة.',
        command: 'cutInternet',
        value: true,
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault:
          (activeScenario.id === 'threat_exposure' && activeThreatTrack.preferCutInternet) ||
          activeScenario.id === 'phishing_links',
      },
      {
        id: 'siren',
        title: 'ØµØ§ÙØ±Ø© Ø±Ø¯Ø¹',
        description: 'ØªØ´ØºÙŠÙ„ ØµØ§ÙØ±Ø© ÙÙŠ Ø§Ù„Ø­Ø§Ù„Ø§Øª Ø§Ù„Ø­Ø±Ø¬Ø© Ø¬Ø¯Ù‹Ø§.',
        command: 'playSiren',
        value: true,
        minSeverity: AlertSeverity.CRITICAL,
        enabledByDefault:
          (activeScenario.id === 'threat_exposure' && activeThreatTrack.preferSiren) ||
          (activeScenario.id === 'inappropriate_content' && activeContentTrack.preferSiren),
      },
      ];

      const merged = [...baseSteps];
      for (const step of playbookDrivenSteps) {
        if (!merged.some((existing) => existing.command === step.command)) {
          merged.push(step);
        }
      }
      return merged;
    },
    [
      activeContentTrack,
      activeScenario.id,
      activeThreatTrack,
      highRiskApp,
      planAudioSource,
      planVideoSource,
      playbookDrivenSteps,
    ]
  );

  useEffect(() => {
    const initSelection: Record<string, boolean> = {};
    const initStatus: Record<string, AutoStepStatus> = {};
    for (const step of autoExecutionSteps) {
      initSelection[step.id] = step.enabledByDefault;
      initStatus[step.id] = 'idle';
    }
    setAutoSelection(initSelection);
    setAutoStatus(initStatus);
    setAutoRunSummary('');
    setExecutionTimeline([]);
    setTimelineFilter('all');
  }, [child.id, activeScenario.id, dominantSeverity, highRiskApp?.id, autoExecutionSteps]);

  const pushTimeline = (entry: Omit<PlanTimelineEntry, 'id' | 'at'>) => {
    setExecutionTimeline((prev) =>
      [
        {
          id: `timeline-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          at: new Date(),
          ...entry,
        },
        ...prev,
      ].slice(0, 40)
    );
  };

  const buildSuggestedPlan = (): Partial<CustomMode> => {
    const frequentApps = [...(child.appUsage || [])]
      .sort((a, b) => b.minutesUsed - a.minutesUsed)
      .slice(0, 3)
      .map((app) => app.appName);

    return {
      name: `Digital Balance Mode - ${child.name}`,
      icon: 'DB',
      color: 'bg-indigo-900',
      allowedApps: frequentApps.length > 0 ? frequentApps : ['School App', 'WhatsApp'],
      allowedUrls: [],
      blacklistedUrls: blockedDomains,
      isInternetCut:
        dominantSeverity === AlertSeverity.CRITICAL ||
        (activeScenario.id === 'threat_exposure' && activeThreatTrack.preferCutInternet) ||
        activeScenario.id === 'phishing_links',
      isDeviceLocked: false,
      isScreenDimmed: true,
      cameraEnabled: dominantSeverity !== AlertSeverity.CRITICAL,
      micEnabled: true,
      internetStartTime: '06:00',
      internetEndTime: '22:00',
      activeDays: [0, 1, 2, 3, 4, 5, 6],
      preferredVideoSource: planVideoSource,
      preferredAudioSource: planAudioSource,
      autoStartLiveStream: severityRank[dominantSeverity] >= severityRank[AlertSeverity.HIGH],
      autoTakeScreenshot: true,
      blackoutOnApply:
        severityRank[dominantSeverity] >= severityRank[AlertSeverity.HIGH] &&
        (activeScenario.id === 'threat_exposure'
          ? activeThreatTrack.preferBlackout
          : activeScenario.id === 'inappropriate_content'
            ? activeContentTrack.preferBlackout
            : true),
      blackoutMessage: blackoutMessage.trim() || fallbackBlackoutMessage,
      enableWalkieTalkieOnApply:
        activeScenario.id === 'bullying' ||
        (activeScenario.id === 'threat_exposure' && activeThreatTrack.preferWalkie),
    };
  };

  const handleApplyEmergencyPlan = () => {
    const suggested = buildSuggestedPlan();
    onAcceptPlan(suggested);
    navigate('/modes', { state: { suggestedMode: suggested } });
  };

  const toggleAutoStep = (stepId: string) => {
    if (isAutoRunning) return;
    setAutoSelection((prev) => ({ ...prev, [stepId]: !prev[stepId] }));
  };

  const runAutoExecutionPlan = async () => {
    if (isAutoRunning) return;
    setIsAutoRunning(true);
    setAutoRunSummary('');
    pushTimeline({
      title: lang === 'ar' ? 'Ø¨Ø¯Ø¡ Ø§Ù„ØªÙ†ÙÙŠØ°' : 'Execution started',
      detail:
        lang === 'ar'
          ? `Ø¨Ø¯Ø¡ ØªØ´ØºÙŠÙ„ Ø§Ù„Ø®Ø·Ø© Ø¹Ù„Ù‰ ${child.name}.`
          : `Started running the plan for ${child.name}.`,
      status: 'info',
    });

    let done = 0;
    let failed = 0;
    let skipped = 0;
    const currentSeverityRank = severityRank[dominantSeverity];

    for (const step of autoExecutionSteps) {
      if (!autoSelection[step.id]) {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'skipped' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'ØªÙ… Ø§Ù„ØªØ®Ø·ÙŠ (ØºÙŠØ± Ù…Ø­Ø¯Ø¯).' : 'Skipped (not selected).',
          status: 'skipped',
        });
        skipped += 1;
        continue;
      }

      if (currentSeverityRank < severityRank[step.minSeverity]) {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'skipped' }));
        pushTimeline({
          title: step.title,
          detail:
            lang === 'ar'
              ? `ØªÙ… Ø§Ù„ØªØ®Ø·ÙŠ Ù„Ø£Ù† Ù…Ø³ØªÙˆÙ‰ Ø§Ù„Ø®Ø·Ø± Ø§Ù„Ø­Ø§Ù„ÙŠ Ø£Ù‚Ù„ Ù…Ù† Ø§Ù„Ø­Ø¯ Ø§Ù„Ø£Ø¯Ù†Ù‰ (${step.minSeverity}).`
              : `Skipped because current severity is below minimum (${step.minSeverity}).`,
          status: 'skipped',
        });
        skipped += 1;
        continue;
      }

      if (step.command === 'blockApp' && !highRiskApp) {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'skipped' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'ØªÙ… Ø§Ù„ØªØ®Ø·ÙŠ Ù„Ø¹Ø¯Ù… ÙˆØ¬ÙˆØ¯ ØªØ·Ø¨ÙŠÙ‚ Ø¹Ø§Ù„ÙŠ Ø§Ù„Ø®Ø·ÙˆØ±Ø©.' : 'Skipped (no high-risk app).',
          status: 'skipped',
        });
        skipped += 1;
        continue;
      }

      try {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'pending' }));
        let commandValue = step.value;
        if (step.command === 'lockscreenBlackout') {
          commandValue = {
            enabled: true,
            message: blackoutMessage.trim() || fallbackBlackoutMessage,
            source: 'digital_balance_auto',
          };
        }
        if (step.command === 'walkieTalkieEnable') {
          commandValue = {
            enabled: true,
            source: planAudioSource,
            sourceTag: 'digital_balance_auto',
          };
        }
        await sendRemoteCommand(child.id, step.command, commandValue);
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'done' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'ØªÙ… Ø§Ù„ØªÙ†ÙÙŠØ° Ø¨Ù†Ø¬Ø§Ø­.' : 'Executed successfully.',
          status: 'done',
        });
        done += 1;
      } catch (error) {
        console.error(`Auto step failed: ${step.id}`, error);
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'error' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'ÙØ´Ù„ Ø§Ù„ØªÙ†ÙÙŠØ°.' : 'Execution failed.',
          status: 'error',
        });
        failed += 1;
      }
    }

    const summary = { done, skipped, failed };
    setIsAutoRunning(false);
    setAutoRunSummary(
      lang === 'ar'
        ? `ØªÙ… ØªÙ†ÙÙŠØ° ${done} Ø®Ø·ÙˆØ©ØŒ ØªØ®Ø·ÙŠ ${skipped}ØŒ ÙˆÙØ´Ù„ ${failed}.`
        : `Executed ${done} steps, skipped ${skipped}, failed ${failed}.`
    );
    pushTimeline({
      title: lang === 'ar' ? 'Ù…Ù„Ø®Øµ Ø§Ù„ØªÙ†ÙÙŠØ°' : 'Execution summary',
      detail:
        lang === 'ar'
          ? `${done} ØªÙ…ØŒ ${skipped} ØªØ®Ø·ÙŠØŒ ${failed} ÙØ´Ù„.`
          : `${done} done, ${skipped} skipped, ${failed} failed.`,
      status: failed > 0 ? 'error' : 'done',
    });
    onPlanExecutionResult?.(summary);
    return summary;
  };

  const runPlanAndCreateMode = async () => {
    await runAutoExecutionPlan();
    const suggested = buildSuggestedPlan();
    const modeId = onAcceptPlan(suggested);
    pushTimeline({
      title: lang === 'ar' ? 'Ø­ÙØ¸ Ø§Ù„ÙˆØ¶Ø¹ Ø§Ù„Ø°ÙƒÙŠ' : 'Smart mode saved',
      detail:
        lang === 'ar'
          ? `ØªÙ… Ø­ÙØ¸ Ø§Ù„ÙˆØ¶Ø¹ ${suggested.name || ''}.`
          : `Saved mode ${suggested.name || ''}.`,
      status: 'done',
    });
    if (!modeId) {
      pushTimeline({
        title: lang === 'ar' ? 'Ù…Ø¹Ø±Ù Ø§Ù„ÙˆØ¶Ø¹' : 'Mode ID',
        detail:
          lang === 'ar'
            ? 'ØªÙ… Ø­ÙØ¸ Ø§Ù„ÙˆØ¶Ø¹ Ø¨Ø¯ÙˆÙ† Ù…Ø¹Ø±Ù ÙÙˆØ±ÙŠØŒ ÙŠÙ…ÙƒÙ† ØªØ·Ø¨ÙŠÙ‚Ù‡ Ù…Ù† ØµÙØ­Ø© Ø§Ù„Ø£ÙˆØ¶Ø§Ø¹.'
            : 'Mode saved without immediate id. You can apply it from Modes page.',
        status: 'info',
      });
      navigate('/modes', { state: { suggestedMode: suggested } });
      return;
    }
    if (onApplyModeToChild) {
      try {
        await onApplyModeToChild(child.id, modeId);
        pushTimeline({
          title: lang === 'ar' ? 'ØªØ·Ø¨ÙŠÙ‚ Ø§Ù„ÙˆØ¶Ø¹' : 'Mode applied',
          detail:
            lang === 'ar'
              ? `ØªÙ… ØªØ·Ø¨ÙŠÙ‚ Ø§Ù„ÙˆØ¶Ø¹ Ø¹Ù„Ù‰ ${child.name}.`
              : `Applied mode to ${child.name}.`,
          status: 'done',
        });
      } catch (error) {
        pushTimeline({
          title: lang === 'ar' ? 'ØªØ·Ø¨ÙŠÙ‚ Ø§Ù„ÙˆØ¶Ø¹' : 'Mode apply',
          detail: lang === 'ar' ? 'ÙØ´Ù„ ØªØ·Ø¨ÙŠÙ‚ Ø§Ù„ÙˆØ¶Ø¹.' : 'Failed to apply mode.',
          status: 'error',
        });
        console.error('Apply mode from pulse failed', error);
      }
    }
  };

  const stepStateClass = (status: AutoStepStatus) => {
    if (status === 'done') return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (status === 'pending') return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    if (status === 'error') return 'bg-rose-100 text-rose-700 border-rose-200';
    if (status === 'skipped') return 'bg-slate-100 text-slate-500 border-slate-200';
    return 'bg-slate-50 text-slate-500 border-slate-100';
  };

  const stepStateLabel = (status: AutoStepStatus) => {
    if (lang === 'ar') {
      if (status === 'done') return 'ØªÙ…';
      if (status === 'pending') return 'Ù‚ÙŠØ¯ Ø§Ù„ØªÙ†ÙÙŠØ°';
      if (status === 'error') return 'ÙØ´Ù„';
      if (status === 'skipped') return 'ØªØ®Ø·ÙŠ';
      return 'Ø¬Ø§Ù‡Ø²';
    }
    if (status === 'done') return 'Done';
    if (status === 'pending') return 'Running';
    if (status === 'error') return 'Failed';
    if (status === 'skipped') return 'Skipped';
    return 'Idle';
  };

  const timelineBadgeClass = (status: PlanTimelineStatus) => {
    if (status === 'done') return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (status === 'error') return 'bg-rose-100 text-rose-700 border-rose-200';
    if (status === 'skipped') return 'bg-slate-100 text-slate-600 border-slate-200';
    return 'bg-indigo-100 text-indigo-700 border-indigo-200';
  };

  const timelineStatusLabel = (status: PlanTimelineStatus) => {
    if (lang !== 'ar') return status;
    if (status === 'done') return 'ØªÙ…';
    if (status === 'error') return 'ÙØ´Ù„';
    if (status === 'skipped') return 'ØªØ®Ø·ÙŠ';
    return 'Ù…Ø¹Ù„ÙˆÙ…Ø©';
  };

  const filteredExecutionTimeline = useMemo(() => {
    if (timelineFilter === 'all') return executionTimeline;
    return executionTimeline.filter((entry) => entry.status === timelineFilter);
  }, [executionTimeline, timelineFilter]);

  const executionSummary = useMemo(() => {
    return executionTimeline.reduce(
      (acc, entry) => {
        if (entry.status === 'done') acc.done += 1;
        if (entry.status === 'error') acc.failed += 1;
        if (entry.status === 'skipped') acc.skipped += 1;
        return acc;
      },
      { done: 0, failed: 0, skipped: 0 }
    );
  }, [executionTimeline]);

  const saveExecutionTimelineToVault = async () => {
    if (!onSaveExecutionEvidence || executionTimeline.length === 0 || isSavingExecutionEvidence) return;

    setIsSavingExecutionEvidence(true);
    try {
      const recordId = await onSaveExecutionEvidence({
        childId: child.id,
        childName: child.name,
        scenarioId: activeScenario.id,
        threatSubtype: activeScenario.id === 'threat_exposure' ? threatSubtype : undefined,
        contentSubtype: activeScenario.id === 'inappropriate_content' ? contentSubtype : undefined,
        scenarioTitle: activeScenario.title,
        severity: dominantSeverity,
        dominantPlatform,
        summary: executionSummary,
        timeline: executionTimeline.map((entry) => ({
          title: entry.title,
          detail: entry.detail,
          status: entry.status,
          at: entry.at.toISOString(),
        })),
      });

      pushTimeline({
        title: lang === 'ar' ? 'Ø­ÙØ¸ ÙÙŠ Ø§Ù„Ø®Ø²Ù†Ø©' : 'Saved to vault',
        detail:
          lang === 'ar'
            ? 'ØªÙ… Ø­ÙØ¸ Ø³Ø¬Ù„ Ø§Ù„ØªÙ†ÙÙŠØ° ÙƒØ¯Ù„ÙŠÙ„ ÙÙŠ Ø§Ù„Ø£Ø±Ø´ÙŠÙ Ø§Ù„Ø¬Ù†Ø§Ø¦ÙŠ.'
            : 'Execution timeline was saved as forensic evidence.',
        status: 'done',
      });

      if (recordId) {
        navigate('/vault', { state: { openAlertId: recordId, presetFilter: 'pulse' } });
      }
    } catch (error) {
      console.error('Save execution evidence failed', error);
      pushTimeline({
        title: lang === 'ar' ? 'Ø­ÙØ¸ ÙÙŠ Ø§Ù„Ø®Ø²Ù†Ø©' : 'Save to vault',
        detail:
          lang === 'ar'
            ? 'ÙØ´Ù„ Ø­ÙØ¸ Ø³Ø¬Ù„ Ø§Ù„ØªÙ†ÙÙŠØ° ÙÙŠ Ø§Ù„Ø®Ø²Ù†Ø©.'
            : 'Failed to save execution timeline to vault.',
        status: 'error',
      });
    } finally {
      setIsSavingExecutionEvidence(false);
    }
  };

  const exportExecutionTimeline = () => {
    if (filteredExecutionTimeline.length === 0) return;

    const exportPayload = filteredExecutionTimeline.map((entry) => ({
      title: entry.title,
      detail: entry.detail,
      status: entry.status,
      timestamp: entry.at.toISOString(),
      childName: child.name,
      scenarioId: activeScenario.id,
      severity: dominantSeverity,
    }));

    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = `amanah-execution-timeline-${child.id}-${Date.now()}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(objectUrl);
  };

  const copyIncidentPlan = async () => {
    const payload = [
      `Ø®Ø·Ø© 10 Ø¯Ù‚Ø§Ø¦Ù‚: ${activeScenario.title}`,
      ...resolvedIncidentPlan.map((step, idx) => `${idx + 1}. ${step}`),
    ].join('\n');

    try {
      await navigator.clipboard.writeText(payload);
      setCopiedPlan(true);
      setTimeout(() => setCopiedPlan(false), 1500);
    } catch {
      setCopiedPlan(false);
    }
  };

  const renderRadarAxisTick = (tickProps: any) => {
    const { x, y, cx, cy, payload } = tickProps;
    const dx = x - cx;
    const dy = y - cy;
    const length = Math.sqrt(dx * dx + dy * dy) || 1;

    // Keep Arabic labels away from polygon edges, especially left/right axes.
    const radialOffset = Math.abs(dx) > Math.abs(dy) ? 34 : dy > 0 ? 28 : 24;
    const tx = x + (dx / length) * radialOffset;
    const ty = y + (dy / length) * radialOffset + (dy > 0 ? 5 : -3);

    let textAnchor: 'middle' | 'start' | 'end' = 'middle';
    if (Math.abs(dx) > 8) {
      textAnchor = dx > 0 ? 'start' : 'end';
    }

    return (
      <text
        x={tx}
        y={ty}
        textAnchor={textAnchor}
        dominantBaseline="central"
        direction="rtl"
        unicodeBidi="plaintext"
        fill="#64748b"
        fontSize={14}
        fontWeight={800}
        fontFamily="Cairo"
      >
        {payload?.value}
      </text>
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-72 animate-in fade-in" dir="rtl">
      <div className="bg-slate-900 rounded-[4rem] p-12 text-white shadow-2xl border-b-8 border-indigo-600">
        <h2 className="text-5xl font-black tracking-tighter mb-2">Amanah Pulse Pro</h2>
        <p className="text-indigo-300 font-bold text-lg opacity-90">
          ØªØ­Ù„ÙŠÙ„ Ø§Ù„Ø§Ø³ØªÙ‚Ø±Ø§Ø± Ø§Ù„Ø±Ù‚Ù…ÙŠ ÙˆØ§Ù„Ù†Ø¨Ø¶ Ø§Ù„Ø¹Ø§Ø·ÙÙŠ Ù„Ù€ {child.name}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div
          ref={primaryCardRef}
          tabIndex={-1}
          className="bg-[#f4f6fa] rounded-[3.5rem] p-8 md:p-10 shadow-xl border border-[#e8ecf3] h-full flex flex-col items-center focus:outline-none focus-visible:ring-4 focus-visible:ring-indigo-200"
        >
          <div className="w-full flex justify-center mb-9">
            <div className="px-8 py-4 bg-[#eef1f6] rounded-full">
              <h3 className="text-[2rem] md:text-[2.2rem] leading-none font-black text-slate-800 text-center">
                Ù…Ø¤Ø´Ø±Ø§Øª Ø§Ù„ØªÙˆØ§Ø²Ù† Ø§Ù„Ù†ÙØ³ÙŠ
              </h3>
            </div>
          </div>
          <div ref={radarContainerRef} className="w-full h-[26rem] relative flex items-center justify-center min-w-0">
            {radarSize.width > 40 && radarSize.height > 40 ? (
              <RadarChart width={radarSize.width} height={radarSize.height} cx="50%" cy="50%" outerRadius="64%" data={radarData}>
                <PolarGrid stroke="#d3dae5" strokeWidth={1.5} />
                <PolarAngleAxis dataKey="subject" tick={renderRadarAxisTick} />
                <RadarComponent
                  name="Amanah Pulse"
                  dataKey="A"
                  stroke="#5f63df"
                  strokeWidth={6}
                  fill="#7b80e7"
                  fillOpacity={0.38}
                />
              </RadarChart>
            ) : (
              <div className="h-full w-full rounded-3xl bg-[#eef2f9]" />
            )}
          </div>
          <div className="w-full mt-3 pt-2">
            <div className="max-w-md mx-auto grid grid-cols-[1fr_auto_1fr] items-center gap-6 text-center">
              <div>
                <p className="text-6xl md:text-7xl leading-none font-black text-rose-500">{profile.anxietyLevel}</p>
                <p className="mt-2 text-xl md:text-2xl font-black text-slate-400">Ø§Ù„Ù‚Ù„Ù‚</p>
              </div>
              <div className="h-32 md:h-36 w-px bg-slate-300"></div>
              <div>
                <p className="text-6xl md:text-7xl leading-none font-black text-indigo-600">{stabilityScore}</p>
                <p className="mt-2 text-xl md:text-2xl font-black text-slate-400">Ø§Ù„Ø§Ø³ØªÙ‚Ø±Ø§Ø±</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-indigo-50 rounded-[4rem] p-10 shadow-2xl border border-indigo-100 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <h3 className="text-2xl font-black text-slate-800">Ø¨Ø±ÙˆØªÙˆÙƒÙˆÙ„ Ø§Ù„Ø±Ø¯ Ø§Ù„Ù…Ù‚ØªØ±Ø­</h3>
            <div className="bg-white p-7 rounded-[2.5rem] border border-indigo-100 italic font-bold text-indigo-900 leading-relaxed">
              {profile.recommendation}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white border border-indigo-100 rounded-2xl p-4 text-center">
                <p className="text-[11px] font-black text-slate-500 mb-1">Ø¬Ø§Ù‡Ø²ÙŠØ© Ø¥Ø¯Ø§Ø±Ø© Ø§Ù„Ø­Ø§Ø¯Ø«</p>
                <p className="text-3xl font-black text-indigo-700">{readinessScore}</p>
              </div>
              <div className="bg-white border border-indigo-100 rounded-2xl p-4 text-center">
                <p className="text-[11px] font-black text-slate-500 mb-1">Ø§Ù„Ø¹Ø§Ø·ÙØ© Ø§Ù„ØºØ§Ù„Ø¨Ø©</p>
                <p className="text-xl font-black text-slate-800">{profile.dominantEmotion}</p>
              </div>
            </div>
          </div>
          <button
            onClick={handleApplyEmergencyPlan}
            className="py-5 bg-slate-900 text-white rounded-[2rem] font-black text-lg shadow-2xl active:scale-95 transition-all"
          >
            ØªÙØ¹ÙŠÙ„ ÙˆØ¶Ø¹ Ø§Ù„Ø­Ù…Ø§ÙŠØ© Ø§Ù„Ù…ØªÙˆØ§Ø²Ù†
          </button>
        </div>
      </div>

      <section className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h3 className="text-xl font-black text-slate-900">Ù†ØªÙŠØ¬Ø© Ø§Ù„ØªØ­Ù„ÙŠÙ„ Ø§Ù„ØªØ´Ø®ÙŠØµÙŠ Ù„Ù„ØªÙ†Ø¨ÙŠÙ‡Ø§Øª</h3>
          {diagnosis ? (
            <span className="px-4 py-2 rounded-full bg-indigo-100 text-indigo-700 text-xs font-black">
              Ø¯Ù‚Ø© Ø§Ù„ØªØ´Ø®ÙŠØµ: {diagnosis.confidence}%
            </span>
          ) : (
            <span className="px-4 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-black">
              Ù„Ø§ ØªÙˆØ¬Ø¯ ØªÙ†Ø¨ÙŠÙ‡Ø§Øª ÙƒØ§ÙÙŠØ© Ù„Ù„ØªØ­Ù„ÙŠÙ„
            </span>
          )}
        </div>

        {diagnosis ? (
          <>
            <p className="text-xs font-bold text-slate-600">
              ØªÙ… ØªØ­Ù„ÙŠÙ„ {diagnosis.analyzedAlertCount} ØªÙ†Ø¨ÙŠÙ‡ Ø®Ø§Øµ Ø¨Ø§Ù„Ø·ÙÙ„ØŒ ÙˆØªÙ… ØªØ±Ø¬ÙŠØ­ Ø³ÙŠÙ†Ø§Ø±ÙŠÙˆ{' '}
              <span className="text-indigo-700 font-black">{activeScenario.title}</span> Ø§Ø¹ØªÙ…Ø§Ø¯Ù‹Ø§ Ø¹Ù„Ù‰ Ø§Ù„Ø´Ø¯Ø© + Ø§Ù„ÙØ¦Ø© +
              Ø§Ù„Ø³ÙŠØ§Ù‚ Ø§Ù„Ù†ØµÙŠ + Ø­Ø¯Ø§Ø«Ø© Ø§Ù„Ø­Ø¯Ø«.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {diagnosis.reasons.map((reason, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-4">
                  <p className="text-xs font-bold text-slate-700 leading-relaxed">{reason}</p>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-xs font-bold text-slate-500">
            Ø³ÙŠØªÙ… ØªÙØ¹ÙŠÙ„ Ø§Ù„Ø±Ø¨Ø· Ø§Ù„ØªÙ„Ù‚Ø§Ø¦ÙŠ ÙÙˆØ± ØªÙˆÙØ± ØªÙ†Ø¨ÙŠÙ‡Ø§Øª Ù…Ø±ØªØ¨Ø·Ø© Ø¨Ù‡Ø°Ø§ Ø§Ù„Ø·ÙÙ„.
          </p>
        )}
      </section>

      <section className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-xl space-y-6">
        <h3 className="text-2xl font-black text-slate-900">Ù…Ø¤Ø´Ø±Ø§Øª Ø§Ù„Ø®Ø·Ø± Ø§Ù„Ø­Ø§Ù„ÙŠØ©</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {riskSignals.map((signal) => (
            <article key={signal.id} className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-black text-sm text-slate-900">{signal.title}</h4>
                <span
                  className={`px-3 py-1 rounded-full border text-[10px] font-black ${severityClassMap[signal.severity]}`}
                >
                  {severityTextMap[signal.severity]}
                </span>
              </div>
              <p className="text-xs font-bold text-slate-700 leading-relaxed">{signal.reason}</p>
              <p className="text-xs font-black text-indigo-700">Ø¥Ø¬Ø±Ø§Ø¡ Ù…Ù‚ØªØ±Ø­: {signal.suggestedAction}</p>
            </article>
          ))}
        </div>

        <div className="bg-slate-50 border border-slate-100 rounded-[2rem] p-5">
          <p className="text-[11px] font-black text-slate-500 mb-3">Ø§ØªØ¬Ø§Ù‡ Ø§Ù„Ù†Ø¨Ø¶ Ø®Ù„Ø§Ù„ Ø§Ù„Ø£Ø³Ø¨ÙˆØ¹</p>
          <div ref={trendContainerRef} className="w-full h-56 min-w-0">
            {trendSize.width > 40 && trendSize.height > 40 ? (
              <BarChart width={trendSize.width} height={trendSize.height} data={weeklyTrend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="label" tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }} />
                <Tooltip cursor={{ fill: '#eef2ff' }} />
                <Bar dataKey="value" fill="#6366f1" radius={[10, 10, 0, 0]} />
              </BarChart>
            ) : (
              <div className="h-full w-full rounded-2xl bg-slate-100" />
            )}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-indigo-700 to-indigo-500 rounded-[3rem] p-8 text-white shadow-2xl border border-indigo-300/30 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-2 max-w-3xl">
            <h3 className="text-2xl md:text-3xl font-black tracking-tight">
              {lang === 'ar' ? 'Ø®Ø·Ø© Ø§Ù„ØªÙˆØ§Ø²Ù† Ø§Ù„Ø±Ù‚Ù…ÙŠ' : 'Digital Balance Plan'}
            </h3>
            <p className="text-indigo-100 font-bold leading-relaxed">{digitalBalanceNarrative}</p>
          </div>
          <div className="flex flex-col gap-2 text-xs font-black">
            <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20">
              {lang === 'ar' ? 'Ø§Ù„Ø³ÙŠÙ†Ø§Ø±ÙŠÙˆ' : 'Scenario'}: {activeScenario.title}
            </span>
            {activeScenario.id === 'threat_exposure' && (
              <span className="px-3 py-1 rounded-full bg-rose-500/25 border border-rose-200/50">
                {lang === 'ar' ? 'المسار' : 'Track'}:{' '}
                {lang === 'ar' ? activeThreatTrack.badgeLabelAr : activeThreatTrack.badgeLabelEn}
              </span>
            )}
            {activeScenario.id === 'inappropriate_content' && (
              <span className="px-3 py-1 rounded-full bg-amber-400/25 border border-amber-100/50">
                {lang === 'ar' ? 'المسار' : 'Track'}:{' '}
                {lang === 'ar' ? activeContentTrack.badgeLabelAr : activeContentTrack.badgeLabelEn}
              </span>
            )}
            <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20">
              {lang === 'ar' ? 'Ø§Ù„Ù…Ù†ØµØ©' : 'Platform'}: {highRiskApp?.appName || dominantPlatform}
            </span>
            <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20">
              {lang === 'ar' ? 'Ø§Ù„Ø­Ø¯Ø©' : 'Severity'}: {dominantSeverity}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {blockedDomains.map((domain) => (
            <span key={domain} className="px-3 py-1 rounded-lg text-[11px] font-black bg-white/15 border border-white/20">
              {domain}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <label className="text-xs font-black text-indigo-100 flex flex-col gap-2">
            {lang === 'ar' ? 'Ù…ØµØ¯Ø± Ø§Ù„ØµÙˆØ±Ø©' : 'Video Source'}
            <select
              value={planVideoSource}
              onChange={(event) => setPlanVideoSource(event.target.value as PlanVideoSource)}
              className="bg-white/15 border border-white/30 rounded-xl px-3 py-2 text-white font-black outline-none"
            >
              <option className="text-slate-900" value="camera_front">
                {lang === 'ar' ? 'Ø§Ù„ÙƒØ§Ù…ÙŠØ±Ø§ Ø§Ù„Ø£Ù…Ø§Ù…ÙŠØ©' : 'Front Camera'}
              </option>
              <option className="text-slate-900" value="camera_back">
                {lang === 'ar' ? 'Ø§Ù„ÙƒØ§Ù…ÙŠØ±Ø§ Ø§Ù„Ø®Ù„ÙÙŠØ©' : 'Back Camera'}
              </option>
              <option className="text-slate-900" value="screen">
                {lang === 'ar' ? 'Ø§Ù„Ø´Ø§Ø´Ø©' : 'Screen'}
              </option>
            </select>
          </label>
          <label className="text-xs font-black text-indigo-100 flex flex-col gap-2">
            {lang === 'ar' ? 'Ù…ØµØ¯Ø± Ø§Ù„ØµÙˆØª' : 'Audio Source'}
            <select
              value={planAudioSource}
              onChange={(event) => setPlanAudioSource(event.target.value as PlanAudioSource)}
              className="bg-white/15 border border-white/30 rounded-xl px-3 py-2 text-white font-black outline-none"
            >
              <option className="text-slate-900" value="mic">
                {lang === 'ar' ? 'Ø§Ù„Ù…ÙŠÙƒØ±ÙˆÙÙˆÙ†' : 'Microphone'}
              </option>
              <option className="text-slate-900" value="system">
                {lang === 'ar' ? 'ØµÙˆØª Ø§Ù„Ù†Ø¸Ø§Ù…' : 'System Audio'}
              </option>
            </select>
          </label>
        </div>

        <label className="text-xs font-black text-indigo-100 flex flex-col gap-2">
          {lang === 'ar' ? 'Ø±Ø³Ø§Ù„Ø© Ø´Ø§Ø´Ø© Ø§Ù„Ø­Ø¬Ø¨ Ø§Ù„ÙˆÙ‚Ø§Ø¦ÙŠ' : 'Blackout Screen Message'}
          <input
            value={blackoutMessage}
            onChange={(event) => setBlackoutMessage(event.target.value)}
            className="bg-white/15 border border-white/30 rounded-xl px-3 py-2 text-white font-bold outline-none placeholder:text-indigo-200/70"
            placeholder={
              lang === 'ar'
                ? 'Ù…Ø«Ø§Ù„: ØªÙ… Ù‚ÙÙ„ Ø§Ù„Ø¬Ù‡Ø§Ø² Ù„Ø¯ÙˆØ§Ø¹ÙŠ Ø§Ù„Ø£Ù…Ø§Ù†. ÙŠØ±Ø¬Ù‰ Ø§Ù„ØªÙˆØ§ØµÙ„ Ù…Ø¹ Ø§Ù„ÙˆØ§Ù„Ø¯ÙŠÙ†.'
                : 'Example: Device locked for safety. Please contact a parent.'
            }
          />
        </label>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleApplyEmergencyPlan}
            className="px-5 py-3 rounded-xl bg-white text-indigo-700 font-black text-sm shadow active:scale-95"
          >
            {lang === 'ar' ? 'Ø¥Ù†Ø´Ø§Ø¡ ÙˆØ¶Ø¹ Ø°ÙƒÙŠ Ù…Ù‚ØªØ±Ø­' : 'Create Suggested Smart Mode'}
          </button>
          <button
            onClick={runAutoExecutionPlan}
            disabled={isAutoRunning}
            className="px-5 py-3 rounded-xl bg-slate-900 text-white font-black text-sm shadow disabled:opacity-50 active:scale-95"
          >
            {isAutoRunning
              ? lang === 'ar'
                ? 'Ø¬Ø§Ø±Ù Ø§Ù„ØªÙ†ÙÙŠØ°...'
                : 'Running...'
              : lang === 'ar'
                ? 'ØªÙ†ÙÙŠØ° Ø§Ù„Ø®Ø·Ø© ØªÙ„Ù‚Ø§Ø¦ÙŠØ§Ù‹'
                : 'Execute Plan Automatically'}
          </button>
          <button
            onClick={runPlanAndCreateMode}
            disabled={isAutoRunning}
            className="px-5 py-3 rounded-xl bg-emerald-500 text-white font-black text-sm shadow disabled:opacity-50 active:scale-95"
          >
            {isAutoRunning
              ? lang === 'ar'
                ? 'Ø¬Ø§Ø±Ù Ø§Ù„ØªÙ†ÙÙŠØ°...'
                : 'Running...'
              : lang === 'ar'
                ? 'ØªÙ†ÙÙŠØ° + Ø­ÙØ¸ + ØªØ·Ø¨ÙŠÙ‚'
                : 'Execute + Save as Mode'}
          </button>
        </div>
      </section>

      <section className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-xl space-y-5">
        <div>
          <h3 className="text-xl font-black text-slate-900">
            {lang === 'ar' ? 'Ø®Ø·ÙˆØ§Øª Ø§Ù„ØªÙ†ÙÙŠØ° Ø§Ù„ØªÙ„Ù‚Ø§Ø¦ÙŠ' : 'Auto Execution Steps'}
          </h3>
          <p className="text-xs font-bold text-slate-500 mt-1">
            {lang === 'ar'
              ? 'ÙŠØªÙ… ØªØ´ØºÙŠÙ„ Ø§Ù„Ø£ÙˆØ§Ù…Ø± Ø§Ù„Ù…Ø®ØªØ§Ø±Ø© Ù…Ø¨Ø§Ø´Ø±Ø© Ø¹Ù„Ù‰ Ø¬Ù‡Ø§Ø² Ø§Ù„Ø·ÙÙ„ Ø¨Ù†Ø§Ø¡Ù‹ Ø¹Ù„Ù‰ Ù…Ø³ØªÙˆÙ‰ Ø§Ù„Ø®Ø·Ø± Ø§Ù„Ø­Ø§Ù„ÙŠ.'
              : 'Selected commands run directly on the child device based on the current risk severity.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {autoExecutionSteps.map((step) => {
            const checked = !!autoSelection[step.id];
            const status = autoStatus[step.id] || 'idle';
            return (
              <article key={step.id} className="rounded-2xl border border-slate-100 bg-slate-50 p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="space-y-1">
                    <h4 className="font-black text-sm text-slate-900">{step.title}</h4>
                    <p className="text-xs font-bold text-slate-600 leading-relaxed">{step.description}</p>
                  </div>
                  <button
                    onClick={() => toggleAutoStep(step.id)}
                    disabled={isAutoRunning}
                    className={`w-12 h-7 rounded-full p-1 transition-all disabled:opacity-50 ${checked ? 'bg-indigo-600' : 'bg-slate-300'}`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${
                        checked ? '-translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="px-3 py-1 rounded-lg text-[10px] font-black bg-slate-200 text-slate-700">
                    {lang === 'ar' ? 'Ø§Ù„Ø­Ø¯ Ø§Ù„Ø£Ø¯Ù†Ù‰' : 'Min'}: {step.minSeverity}
                  </span>
                  <span className={`px-3 py-1 rounded-lg text-[10px] font-black border ${stepStateClass(status)}`}>
                    {stepStateLabel(status)}
                  </span>
                </div>
              </article>
            );
          })}
        </div>

        {autoRunSummary && (
          <div className="rounded-2xl border border-indigo-100 bg-indigo-50 text-indigo-700 px-4 py-3 text-xs font-black">
            {autoRunSummary}
          </div>
        )}

        <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="text-sm font-black text-slate-900">
              {lang === 'ar' ? 'Ø§Ù„Ø³Ø¬Ù„ Ø§Ù„Ø²Ù…Ù†ÙŠ Ù„Ù„ØªÙ†ÙÙŠØ°' : 'Execution Timeline'}
            </h4>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-slate-500">
                {lang === 'ar'
                  ? `${filteredExecutionTimeline.length} / ${executionTimeline.length} Ø£Ø­Ø¯Ø§Ø«`
                  : `${filteredExecutionTimeline.length} / ${executionTimeline.length} events`}
              </span>
              <button
                onClick={saveExecutionTimelineToVault}
                disabled={
                  executionTimeline.length === 0 ||
                  isSavingExecutionEvidence ||
                  !onSaveExecutionEvidence
                }
                className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-black disabled:opacity-40"
              >
                {isSavingExecutionEvidence
                  ? lang === 'ar'
                    ? 'Ø¬Ø§Ø±Ù Ø§Ù„Ø­ÙØ¸...'
                    : 'Saving...'
                  : lang === 'ar'
                    ? 'Ø­ÙØ¸ Ø¨Ø§Ù„Ø®Ø²Ù†Ø©'
                    : 'Save to Vault'}
              </button>
              <button
                onClick={exportExecutionTimeline}
                disabled={filteredExecutionTimeline.length === 0}
                className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-[10px] font-black disabled:opacity-40"
              >
                {lang === 'ar' ? 'ØªØµØ¯ÙŠØ± JSON' : 'Export JSON'}
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {(['all', 'done', 'error', 'skipped', 'info'] as const).map((statusKey) => {
              const isActive = timelineFilter === statusKey;
              const label =
                statusKey === 'all'
                  ? lang === 'ar'
                    ? 'Ø§Ù„ÙƒÙ„'
                    : 'All'
                  : timelineStatusLabel(statusKey);
              return (
                <button
                  key={statusKey}
                  onClick={() => setTimelineFilter(statusKey)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-black border ${
                    isActive
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>

          {filteredExecutionTimeline.length > 0 ? (
            <div className="space-y-2 max-h-56 overflow-y-auto custom-scrollbar pr-1">
              {filteredExecutionTimeline.map((entry) => (
                <article
                  key={entry.id}
                  className="bg-white border border-slate-100 rounded-xl px-3 py-2 flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <p className="text-xs font-black text-slate-900">{entry.title}</p>
                    <p className="text-[11px] font-bold text-slate-600">{entry.detail}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className={`px-2 py-0.5 rounded-md border text-[10px] font-black ${timelineBadgeClass(entry.status)}`}>
                      {timelineStatusLabel(entry.status)}
                    </span>
                    <span className="text-[10px] font-bold text-slate-400">
                      {entry.at.toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                      })}
                    </span>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <p className="text-[11px] font-bold text-slate-500">
              {lang === 'ar'
                ? executionTimeline.length > 0
                  ? 'Ù„Ø§ ØªÙˆØ¬Ø¯ Ø£Ø­Ø¯Ø§Ø« Ø¶Ù…Ù† Ø§Ù„ÙÙ„ØªØ± Ø§Ù„Ø­Ø§Ù„ÙŠ.'
                  : 'Ø§Ø¨Ø¯Ø£ Ø§Ù„ØªÙ†ÙÙŠØ° Ù„Ø¹Ø±Ø¶ Ø³Ø¬Ù„ Ø§Ù„Ø®Ø·ÙˆØ§Øª ØªÙ„Ù‚Ø§Ø¦ÙŠÙ‹Ø§.'
                : executionTimeline.length > 0
                  ? 'No events for the selected filter.'
                  : 'Run the plan to populate execution timeline.'}
            </p>
          )}
        </div>
      </section>

      <section className="bg-white rounded-[4rem] p-8 md:p-12 shadow-2xl border border-slate-100 space-y-8">
        <div>
          <h3 className="text-3xl font-black text-slate-900 tracking-tighter mb-2">Ù…Ø±ÙƒØ² Ø§Ù„Ù†Ø¨Ø¶ Ø§Ù„Ù†ÙØ³ÙŠ</h3>
          <p className="text-slate-500 font-bold">Ø§Ø®ØªØ± Ø§Ù„Ù…Ø´ÙƒÙ„Ø© Ù„Ø¹Ø±Ø¶ Ø§Ù„Ø£Ø¹Ø±Ø§Ø¶ØŒ Ø§Ù„Ø§Ø³ØªØ¯Ø±Ø§Ø¬ØŒ Ø§Ù„ÙˆÙ‚Ø§ÙŠØ©ØŒ ÙˆØ¨Ø±Ù†Ø§Ù…Ø¬ Ø§Ù„ØªØ¯Ø®Ù„.</p>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-4 custom-scrollbar">
          {guidanceScenarios.map((scenario) => (
            <button
              key={scenario.id}
              onClick={() => setActiveScenarioId(scenario.id)}
              className={`flex items-center gap-2 px-6 py-4 rounded-2xl whitespace-nowrap transition-all border-2 ${
                activeScenarioId === scenario.id
                  ? `${scenario.severityColor} border-transparent text-white shadow-lg`
                  : 'bg-slate-50 border-slate-100 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <span className="text-xl">{scenario.icon}</span>
              <span className="font-black text-xs">{scenario.title}</span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-7 rounded-[2.5rem] text-white shadow-xl bg-slate-800 space-y-5">
            <div>
              <h4 className="text-2xl font-black mb-2">{activeScenario.title}</h4>
              {activeScenario.id === 'threat_exposure' && (
                <div className="mb-3 rounded-xl bg-white/10 border border-white/20 px-3 py-2 text-[11px] font-black text-rose-100">
                  {lang === 'ar' ? 'المسار النشط' : 'Active Track'}:{' '}
                  {lang === 'ar' ? activeThreatTrack.badgeLabelAr : activeThreatTrack.badgeLabelEn}
                </div>
              )}
              {activeScenario.id === 'inappropriate_content' && (
                <div className="mb-3 rounded-xl bg-white/10 border border-white/20 px-3 py-2 text-[11px] font-black text-amber-100">
                  {lang === 'ar' ? 'المسار النشط' : 'Active Track'}:{' '}
                  {lang === 'ar' ? activeContentTrack.badgeLabelAr : activeContentTrack.badgeLabelEn}
                </div>
              )}
              <p className="text-[11px] font-black text-slate-300">Ø§Ù„Ø£Ø¹Ø±Ø§Ø¶ ÙˆØ§Ù„Ù…Ø´ÙƒÙ„Ø§Øª</p>
              <ul className="space-y-2 mt-3">
                {activeScenario.symptoms.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs font-bold leading-relaxed">
                    <span className="mt-1 w-1.5 h-1.5 bg-white rounded-full flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="text-[11px] font-black text-slate-300">Ø£Ø³Ø§Ù„ÙŠØ¨ Ø§Ù„Ø§Ø³ØªØ¯Ø±Ø§Ø¬ Ø§Ù„Ø´Ø§Ø¦Ø¹Ø©</p>
              <ul className="space-y-2 mt-3">
                {activeScenario.lurePatterns.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs font-bold leading-relaxed">
                    <span className="mt-1 w-1.5 h-1.5 bg-indigo-300 rounded-full flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-indigo-50 border border-indigo-100 rounded-[2.5rem] p-7 space-y-5">
            <div>
              <p className="text-[11px] font-black text-indigo-500 uppercase tracking-widest mb-3">Ù†ØµÙŠØ­Ø© Ø§Ù„Ù…Ø³ØªØ´Ø§Ø±</p>
              <p className="text-slate-800 font-black leading-relaxed">{quickAdvisorTip}</p>
            </div>
            <div>
              <p className="text-[11px] font-black text-indigo-500 uppercase tracking-widest mb-3">Ø¥Ø¬Ø±Ø§Ø¡Ø§Øª Ø§Ù„ÙˆÙ‚Ø§ÙŠØ©</p>
              <ul className="space-y-2">
                {activeScenario.prevention.map((item, idx) => (
                  <li key={idx} className="text-xs font-bold text-slate-700 leading-relaxed">â€¢ {item}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-100 rounded-[2.5rem] p-6 space-y-4">
          <h4 className="text-xl font-black text-slate-900">Ø¨Ø±Ù†Ø§Ù…Ø¬ ØªØ¯Ø®Ù„ Ø¹Ù„Ø§Ø¬ÙŠ (4 Ø£Ø³Ø§Ø¨ÙŠØ¹)</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeScenario.interventionProgram.map((step) => (
              <article key={step.week} className="bg-white border border-slate-100 rounded-2xl p-4 space-y-2">
                <p className="text-[11px] font-black text-indigo-500">{step.week}</p>
                <p className="text-sm font-black text-slate-800">{step.goal}</p>
                <p className="text-xs font-bold text-slate-600 leading-relaxed">{step.action}</p>
              </article>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-xl font-black text-slate-900">Ø­ÙˆØ§Ø±Ø§Øª Ø¹Ù…Ù„ÙŠØ© Ø¬Ø§Ù‡Ø²Ø©</h4>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {activeScenario.dialogues.map((dialogue, idx) => (
              <article key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
                <p className="text-[11px] font-black text-indigo-500">{dialogue.situation}</p>
                <p className="text-sm font-bold text-slate-800 leading-relaxed">{dialogue.opener}</p>
                <div className="bg-white rounded-xl p-3 border border-slate-100">
                  <p className="text-[11px] font-black text-slate-500 mb-1">ØªÙˆØ¬ÙŠÙ‡ Ø§Ù„Ø®Ø¨ÙŠØ±</p>
                  <p className="text-xs font-bold text-slate-700">{dialogue.advice}</p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-100 rounded-[2.5rem] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-black text-slate-900">Ø®Ø·Ø© 10 Ø¯Ù‚Ø§Ø¦Ù‚ Ù„Ù„Ø­Ø§Ø¯Ø«</h4>
              <button
                onClick={copyIncidentPlan}
                className="px-4 py-2 text-[11px] font-black rounded-xl bg-slate-900 text-white"
              >
                {copiedPlan ? 'ØªÙ… Ø§Ù„Ù†Ø³Ø®' : 'Ù†Ø³Ø® Ø§Ù„Ø®Ø·Ø©'}
              </button>
            </div>
            <ol className="space-y-2">
              {resolvedIncidentPlan.map((step, idx) => (
                <li key={idx} className="text-xs font-bold text-slate-700 leading-relaxed">
                  {idx + 1}. {step}
                </li>
              ))}
            </ol>
          </div>

          <div className="bg-white border border-slate-100 rounded-[2.5rem] p-6 space-y-4">
            <h4 className="text-lg font-black text-slate-900">Ø±Ø³Ø§Ø¦Ù„ ØªÙ†Ø¨ÙŠÙ‡ Ø¬Ø§Ù‡Ø²Ø© Ø¯Ø§Ø®Ù„ Ø§Ù„ØªØ·Ø¨ÙŠÙ‚</h4>
            <ul className="space-y-2">
              {resolvedAlertTemplates.map((template, idx) => (
                <li key={idx} className="text-xs font-bold text-slate-700 leading-relaxed">
                  â€¢ {template}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

    </div>
  );
};

export default PsychologicalInsightView;

