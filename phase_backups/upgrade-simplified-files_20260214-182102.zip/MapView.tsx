﻿export { default } from '../components/MapView';
