import { AlertSeverity, Category, MonitoringAlert } from '../types';

export type PsychScenarioId =
  | 'bullying'
  | 'threat_exposure'
  | 'gaming'
  | 'inappropriate_content'
  | 'cyber_crime'
  | 'crypto_scams';

export interface AlertPsychDiagnosis {
  scenarioId: PsychScenarioId;
  confidence: number;
  analyzedAlertCount: number;
  reasons: string[];
  scoreByScenario: Record<PsychScenarioId, number>;
  topSignals: Array<{
    id: string;
    title: string;
    severity: AlertSeverity;
    reason: string;
    suggestedAction: string;
  }>;
}

const SCENARIOS: PsychScenarioId[] = [
  'bullying',
  'threat_exposure',
  'gaming',
  'inappropriate_content',
  'cyber_crime',
  'crypto_scams',
];

const SEVERITY_WEIGHT: Record<AlertSeverity, number> = {
  [AlertSeverity.CRITICAL]: 5,
  [AlertSeverity.HIGH]: 3,
  [AlertSeverity.MEDIUM]: 2,
  [AlertSeverity.LOW]: 1,
};

const SEVERITY_TEXT: Record<AlertSeverity, string> = {
  [AlertSeverity.CRITICAL]: 'حرج',
  [AlertSeverity.HIGH]: 'مرتفع',
  [AlertSeverity.MEDIUM]: 'متوسط',
  [AlertSeverity.LOW]: 'منخفض',
};

const CATEGORY_BOOSTS: Record<Category, Partial<Record<PsychScenarioId, number>>> = {
  [Category.BULLYING]: { bullying: 1.8, threat_exposure: 0.4 },
  [Category.SELF_HARM]: { threat_exposure: 1.9, bullying: 0.5 },
  [Category.ADULT_CONTENT]: { inappropriate_content: 1.9, threat_exposure: 0.3 },
  [Category.SCAM]: { crypto_scams: 1.8, threat_exposure: 0.2 },
  [Category.PREDATOR]: { threat_exposure: 2.0, inappropriate_content: 0.4 },
  [Category.VIOLENCE]: { threat_exposure: 1.5, cyber_crime: 0.4 },
  [Category.BLACKMAIL]: { threat_exposure: 2.1, bullying: 0.3 },
  [Category.SEXUAL_EXPLOITATION]: { threat_exposure: 2.1, inappropriate_content: 0.4 },
  [Category.PHISHING_LINK]: { crypto_scams: 1.9, cyber_crime: 0.4 },
  [Category.SAFE]: {},
};

const KEYWORD_MAP: Record<PsychScenarioId, string[]> = {
  bullying: ['تنمر', 'bully', 'harass', 'insult', 'سخرية', 'إهانة', 'مضايقة', 'نبذ'],
  threat_exposure: [
    'تهديد',
    'ابتزاز',
    'sextortion',
    'blackmail',
    'predator',
    'grooming',
    'extort',
    'خوف',
    'عنف',
  ],
  gaming: ['لعب', 'game', 'gaming', 'rank', 'loot', 'سهر', 'screen time', 'tik tok', 'reels'],
  inappropriate_content: ['إباحية', 'porn', 'adult', 'gore', 'صادم', 'محتوى حساس', 'unsafe content'],
  cyber_crime: ['اختراق', 'hack', 'script', 'malware', 'ddos', 'exploit', 'تهكير', 'قرصنة'],
  crypto_scams: ['احتيال', 'scam', 'phishing', 'bitcoin', 'crypto', 'airdrop', 'ربح سريع', 'تحويل'],
};

const SUGGESTED_ACTION_MAP: Record<PsychScenarioId, string> = {
  bullying: 'توثيق الأدلة + حظر + تعديل الخصوصية + متابعة تربوية.',
  threat_exposure: 'خطة 10 دقائق: لا تفاوض، لا دفع، حفظ الأدلة، تأمين الحساب، ثم الإبلاغ.',
  gaming: 'خفض تدريجي + ضبط نوم + خطة بدائل ومراجعة أسبوعية.',
  inappropriate_content: 'تقوية الفلترة + SafeSearch + حوار آمن بلا عقوبة.',
  cyber_crime: 'إيقاف الأدوات الخطرة وتوجيه قانوني لمسار تعلم أخلاقي.',
  crypto_scams: 'إيقاف المدفوعات غير المعتمدة + مراجعة مالية أسرية فورية.',
};

const normalize = (value?: string) => (value || '').toLowerCase().replace(/\s+/g, ' ').trim();

const calculateRecencyFactor = (timestamp: Date | string | number | undefined): number => {
  if (!timestamp) return 0.8;
  const ts = new Date(timestamp).getTime();
  if (Number.isNaN(ts)) return 0.8;
  const ageHours = (Date.now() - ts) / (1000 * 60 * 60);
  if (ageHours <= 24) return 1.25;
  if (ageHours <= 72) return 1.1;
  if (ageHours <= 7 * 24) return 1.0;
  if (ageHours <= 30 * 24) return 0.85;
  return 0.7;
};

const isAlertForChild = (alertChildName: string, childName: string) => {
  const a = normalize(alertChildName);
  const c = normalize(childName);
  if (!a || !c) return false;
  return a === c || a.includes(c) || c.includes(a);
};

export const diagnosePsychScenarioFromAlerts = (
  childName: string,
  alerts: MonitoringAlert[]
): AlertPsychDiagnosis | null => {
  if (!childName || !alerts?.length) return null;

  const childAlerts = alerts.filter((alert) => isAlertForChild(alert.childName, childName));
  if (!childAlerts.length) return null;

  const scoreByScenario: Record<PsychScenarioId, number> = {
    bullying: 0,
    threat_exposure: 0,
    gaming: 0,
    inappropriate_content: 0,
    cyber_crime: 0,
    crypto_scams: 0,
  };

  const evidence: Record<PsychScenarioId, Array<{ alert: MonitoringAlert; score: number }>> = {
    bullying: [],
    threat_exposure: [],
    gaming: [],
    inappropriate_content: [],
    cyber_crime: [],
    crypto_scams: [],
  };

  for (const alert of childAlerts) {
    const severityWeight = SEVERITY_WEIGHT[alert.severity] || 1;
    const recencyFactor = calculateRecencyFactor(alert.timestamp);
    const baseWeight = severityWeight * recencyFactor;

    const categoryMap = CATEGORY_BOOSTS[alert.category] || {};
    const textCorpus = normalize(
      `${alert.content || ''} ${alert.aiAnalysis || ''} ${alert.platform || ''} ${alert.category || ''}`
    );

    for (const scenario of SCENARIOS) {
      let alertScenarioScore = 0;

      const categoryBoost = categoryMap[scenario];
      if (categoryBoost) {
        alertScenarioScore += baseWeight * categoryBoost;
      }

      const keywordHits = KEYWORD_MAP[scenario].filter((kw) => textCorpus.includes(kw)).length;
      if (keywordHits > 0) {
        alertScenarioScore += baseWeight * 0.35 * keywordHits;
      }

      if (alertScenarioScore > 0) {
        scoreByScenario[scenario] += alertScenarioScore;
        evidence[scenario].push({ alert, score: alertScenarioScore });
      }
    }
  }

  const ranked = [...SCENARIOS]
    .map((scenarioId) => ({ scenarioId, score: scoreByScenario[scenarioId] }))
    .sort((a, b) => b.score - a.score);

  const top = ranked[0];
  if (!top || top.score <= 0) return null;

  const second = ranked[1]?.score || 0;
  const scoreSum = ranked.reduce((sum, item) => sum + item.score, 0) || top.score;
  const spread = (top.score - second) / (top.score || 1);
  const dominance = top.score / scoreSum;
  const confidence = Math.round(Math.min(99, Math.max(42, dominance * 65 + spread * 35)));

  const scenarioEvidence = [...evidence[top.scenarioId as PsychScenarioId]]
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  const reasons = scenarioEvidence.map(
    ({ alert }) =>
      `[${SEVERITY_TEXT[alert.severity]}] ${alert.category}: ${alert.aiAnalysis || alert.content || 'مؤشر سلوكي ملحوظ'}`
  );

  const topSignals = scenarioEvidence.map(({ alert }, idx) => ({
    id: `diag-${top.scenarioId}-${alert.id || idx}`,
    title: `إشارة تحليل من ${alert.category}`,
    severity: alert.severity,
    reason: alert.aiAnalysis || alert.content || 'تم رصد نمط سلوكي يحتاج متابعة.',
    suggestedAction: SUGGESTED_ACTION_MAP[top.scenarioId as PsychScenarioId],
  }));

  return {
    scenarioId: top.scenarioId as PsychScenarioId,
    confidence,
    analyzedAlertCount: childAlerts.length,
    reasons,
    scoreByScenario,
    topSignals,
  };
};

