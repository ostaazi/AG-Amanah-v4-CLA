import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AlertSeverity, Category, Child, CustomMode, MonitoringAlert, SafetyPlaybook } from '../types';
import {
  Bar,
  BarChart,
  CartesianGrid,
  PolarAngleAxis,
  PolarGrid,
  Radar as RadarComponent,
  RadarChart,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useNavigate } from 'react-router-dom';
import {
  diagnosePsychScenarioFromAlerts,
  PsychScenarioId,
} from '../services/psychDiagnosticService';
import { fetchPlaybooks, sendRemoteCommand } from '../services/firestoreService';
import { getDefenseActionsWithPlaybooks } from '../services/ruleEngineService';

interface PsychologicalInsightViewProps {
  theme: 'light' | 'dark';
  child?: Child;
  alerts?: MonitoringAlert[];
  lang?: 'ar' | 'en';
  onAcceptPlan: (plan: Partial<CustomMode>) => string | void;
  onApplyModeToChild?: (childId: string, modeId?: string) => Promise<void> | void;
  onPlanExecutionResult?: (summary: { done: number; failed: number; skipped: number }) => void;
  onSaveExecutionEvidence?: (payload: PlanExecutionEvidencePayload) => Promise<string | void> | string | void;
}

interface InterventionStep {
  week: string;
  goal: string;
  action: string;
}

interface GuidanceScenario {
  id: PsychScenarioId;
  title: string;
  icon: string;
  severity: AlertSeverity;
  severityColor: string;
  symptoms: string[];
  lurePatterns: string[];
  prevention: string[];
  interventionProgram: InterventionStep[];
  dialogues: {
    situation: string;
    opener: string;
    advice: string;
  }[];
  alertTemplates: string[];
  incidentPlan: string[];
}

interface AutoExecutionStep {
  id: string;
  title: string;
  description: string;
  command:
    | 'takeScreenshot'
    | 'blockApp'
    | 'setVideoSource'
    | 'setAudioSource'
    | 'startLiveStream'
    | 'lockDevice'
    | 'playSiren'
    | 'lockscreenBlackout'
    | 'walkieTalkieEnable'
    | 'cutInternet'
    | 'blockCameraAndMic'
    | 'notifyParent';
  value: any;
  minSeverity: AlertSeverity;
  enabledByDefault: boolean;
}

type AutoStepStatus = 'idle' | 'pending' | 'done' | 'error' | 'skipped';
type PlanVideoSource = 'camera_front' | 'camera_back' | 'screen';
type PlanAudioSource = 'mic' | 'system';
type PlanTimelineStatus = 'done' | 'error' | 'skipped' | 'info';

interface PlanTimelineEntry {
  id: string;
  title: string;
  detail: string;
  status: PlanTimelineStatus;
  at: Date;
}

interface PlanExecutionEvidencePayload {
  childId: string;
  childName: string;
  scenarioId: PsychScenarioId;
  scenarioTitle: string;
  severity: AlertSeverity;
  dominantPlatform: string;
  summary: { done: number; failed: number; skipped: number };
  timeline: Array<{
    title: string;
    detail: string;
    status: PlanTimelineStatus;
    at: string;
  }>;
}

const severityRank: Record<AlertSeverity, number> = {
  [AlertSeverity.LOW]: 1,
  [AlertSeverity.MEDIUM]: 2,
  [AlertSeverity.HIGH]: 3,
  [AlertSeverity.CRITICAL]: 4,
};

const scenarioBlockedDomains: Record<PsychScenarioId, string[]> = {
  bullying: ['discord.com', 'telegram.org'],
  threat_exposure: ['discord.com', 'telegram.org', 'snapchat.com'],
  gaming: ['roblox.com', 'epicgames.com', 'discord.com'],
  inappropriate_content: ['reddit.com', 'xvideos.com', 'pornhub.com'],
  cyber_crime: ['pastebin.com', 'discord.com', 'telegram.org'],
  crypto_scams: ['binance.com', 'okx.com', 'telegram.org'],
};

const guidanceScenarios: GuidanceScenario[] = [
  {
    id: 'bullying',
    title: 'التنمر الإلكتروني',
    icon: '🧩',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-rose-600',
    symptoms: [
      'تجنب الطفل تطبيقات محددة أو حذف الرسائل بسرعة.',
      'تغير المزاج بعد فترات استخدام قصيرة.',
      'انسحاب اجتماعي أو رفض الذهاب للمدرسة دون مبرر واضح.',
    ],
    lurePatterns: [
      'مجموعات تستفز الطفل ثم تنشر لقطات محرجة.',
      'حسابات وهمية لإهانة متكررة وإقصاء اجتماعي.',
      'تعليقات تحريضية تدفع الطفل للرد الانفعالي.',
    ],
    prevention: [
      'تشديد الخصوصية: من يراسل/يشاهد المنشورات.',
      'منع الرسائل من الغرباء داخل الألعاب والمنصات.',
      'تدريب الطفل على قاعدة: وثّق، احظر، بلّغ، لا ترد.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'احتواء فوري', action: 'جلسة دعم + توثيق الأدلة + حظر الحسابات المؤذية.' },
      { week: 'الأسبوع 2', goal: 'إيقاف الاستنزاف', action: 'تحديث إعدادات الخصوصية ومراقبة نقاط التماس عالية الخطر.' },
      { week: 'الأسبوع 3', goal: 'استعادة الثقة', action: 'حوار تدريجي وإشراك المدرسة إذا كانت البيئة مشتركة.' },
      { week: 'الأسبوع 4', goal: 'تثبيت التعافي', action: 'خطة متابعة أسبوعية قصيرة مع قياس تحسن السلوك.' },
    ],
    dialogues: [
      {
        situation: 'افتتاح بلا لوم',
        opener: 'أنا معك، وأي إساءة وصلت لك ليست خطأك. احكي لي بهدوء.',
        advice: 'لا تبدأ بالأسئلة الاتهامية، ابدأ بالأمان النفسي.',
      },
      {
        situation: 'تعطيل الضرر',
        opener: 'سنوقف الحسابات المسيئة الآن، ونحفظ الأدلة قبل أي حذف.',
        advice: 'التوثيق يسبق الحذف دائمًا.',
      },
      {
        situation: 'تثبيت الثقة',
        opener: 'إبلاغك لنا قوة، وليس ضعفًا. نحن فريق واحد.',
        advice: 'أعد تعريف الشجاعة بأنها طلب مساعدة مبكر.',
      },
    ],
    alertTemplates: [
      'تنبيه متوسط: مؤشرات ضغط اجتماعي رقمية، يُنصح بحوار هادئ اليوم.',
      'تنبيه مرتفع: نمط تنمر متكرر، ابدأ مسار التوثيق والحظر.',
    ],
    incidentPlan: [
      'طمأنة الطفل فورًا: لا لوم ولا عقوبة لحظة الإبلاغ.',
      'حفظ الأدلة: لقطات شاشة، أسماء الحسابات، التوقيت.',
      'حظر وإبلاغ داخل المنصة.',
      'ضبط الخصوصية وتقييد الرسائل من الغرباء.',
      'متابعة نفسية خلال 72 ساعة.',
    ],
  },
  {
    id: 'threat_exposure',
    title: 'التهديد والابتزاز',
    icon: '🚨',
    severity: AlertSeverity.CRITICAL,
    severityColor: 'bg-red-700',
    symptoms: [
      'خوف واضح عند وصول إشعارات من جهة بعينها.',
      'إخفاء الهاتف أو حذف محادثات بشكل متسارع.',
      'طلب مال/بطاقات بشكل غير مبرر أو توتر حاد.',
    ],
    lurePatterns: [
      'بناء ثقة زائفة ثم طلب صور أو معلومات خاصة.',
      'تهديد بالنشر أو التشهير بعد الحصول على محتوى حساس.',
      'ابتزاز مالي عبر بطاقات الهدايا أو التحويلات الرقمية.',
    ],
    prevention: [
      'قاعدة ذهبية: لا صور خاصة، لا رموز تحقق، لا تفاوض.',
      'تفعيل 2FA للحسابات الرئيسية.',
      'تعليم الطفل استخدام زر المساعدة الفوري داخل التطبيق.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'إيقاف النزف', action: 'تطبيق خطة 10 دقائق بالكامل وتصعيد الحماية.' },
      { week: 'الأسبوع 2', goal: 'تحصين الحسابات', action: 'تغيير كلمات المرور، مراجعة الجلسات، إغلاق المسارات المكشوفة.' },
      { week: 'الأسبوع 3', goal: 'دعم نفسي', action: 'جلسات تفريغ قلق، وتأكيد عدم الذنب على الطفل.' },
      { week: 'الأسبوع 4', goal: 'منع التكرار', action: 'تحديث سياسات الأسرة الرقمية ورفع وعي الطفل.' },
    ],
    dialogues: [
      {
        situation: 'إيقاف التصعيد',
        opener: 'سلامتك أولًا. لن نرد على أي تهديد، وسنتعامل رسميًا.',
        advice: 'لا دفع، لا تفاوض، لا حذف قبل التوثيق.',
      },
      {
        situation: 'تثبيت الأمان',
        opener: 'لن تواجه هذا وحدك، سنحل الموضوع خطوة بخطوة.',
        advice: 'أبرز أن الطفل ضحية وليس مذنبًا.',
      },
      {
        situation: 'التحرك القانوني',
        opener: 'سنجمع الدليل ثم نبلّغ القنوات المعتمدة لحمايتك.',
        advice: 'حفظ الهوية الرقمية للجهة المهددة مهم قبل الإبلاغ.',
      },
    ],
    alertTemplates: [
      'تنبيه حرج: احتمال تهديد/ابتزاز مباشر. ابدأ خطة 10 دقائق الآن.',
      'تنبيه حرج: سلوك حذف محادثات + خوف + طلب مالي، يلزم تدخل فوري.',
    ],
    incidentPlan: [
      'لا تفاوض ولا دفع تحت أي ضغط.',
      'حفظ الأدلة الرقمية فورًا.',
      'إيقاف التواصل مع المبتز وحظره.',
      'تأمين الحسابات (تغيير كلمة المرور + 2FA).',
      'إبلاغ المنصة والجهة المختصة حسب الإجراءات المحلية.',
    ],
  },
  {
    id: 'gaming',
    title: 'إدمان الألعاب',
    icon: '🎮',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-indigo-600',
    symptoms: [
      'سهر مفرط واضطراب نوم متكرر.',
      'عصبية عالية عند سحب الجهاز أو انتهاء الوقت.',
      'تراجع دراسي وانسحاب من أنشطة واقعية.',
    ],
    lurePatterns: [
      'مكافآت يومية تبني تعلقًا قهريًا.',
      'ضغط الأصدقاء في الفرق التنافسية.',
      'مشتريات داخل اللعبة تعزز مطاردة الخسارة.',
    ],
    prevention: [
      'تفعيل Bedtime تلقائي.',
      'جدولة وقت اللعب وربطه بالمهام اليومية.',
      'قفل المشتريات بكلمة مرور ولي الأمر.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'استقرار النوم', action: 'تثبيت وقت نوم ومنع الاستخدام الليلي.' },
      { week: 'الأسبوع 2', goal: 'خفض تدريجي', action: 'تقليل 10%-15% من الاستخدام اليومي.' },
      { week: 'الأسبوع 3', goal: 'بدائل واقعية', action: 'إدخال نشاط بديل ثابت (رياضة/هواية).' },
      { week: 'الأسبوع 4', goal: 'تثبيت السلوك', action: 'نظام مكافآت مرتبط بالالتزام الدراسي والسلوكي.' },
    ],
    dialogues: [
      {
        situation: 'اتفاق منصف',
        opener: 'أنا لا أريد المنع الكامل، فقط نحتاج توازنًا يحميك.',
        advice: 'اختر صيغة شراكة لا صيغة عقاب.',
      },
      {
        situation: 'تنظيم تدريجي',
        opener: 'خلّنا نبدأ بخطة أسبوع، ثم نراجع سوا النتائج.',
        advice: 'التغيير التدريجي ينجح أكثر من القطع المفاجئ.',
      },
      {
        situation: 'دعم المهارة',
        opener: 'مهارتك ممتازة، ونريدها تستمر بدون أن تضر نومك ودراستك.',
        advice: 'اربط الثناء بضوابط الاستخدام.',
      },
    ],
    alertTemplates: [
      'تنبيه نوم: استخدام متأخر متكرر، يُنصح بتفعيل وضع النوم.',
      'تنبيه سلوكي: تجاوزات وقت الشاشة مع انفعال عند الإيقاف.',
    ],
    incidentPlan: [
      'تهدئة الموقف وعدم الدخول في صدام لحظي.',
      'تفعيل وضع النوم وإغلاق التطبيقات عالية الاستهلاك.',
      'تحديد خطة أسبوع خفض تدريجي.',
      'إدخال نشاط بديل يومي.',
      'مراجعة أسبوعية بالأرقام لا بالانطباعات.',
    ],
  },
  {
    id: 'inappropriate_content',
    title: 'المحتوى غير المناسب',
    icon: '🛡️',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-violet-700',
    symptoms: [
      'إغلاق مفاجئ للشاشة عند الاقتراب.',
      'تصفح خفي متكرر أو تاريخ محذوف باستمرار.',
      'توتر أو خجل زائد بعد التواجد على الإنترنت.',
    ],
    lurePatterns: [
      'روابط مضللة داخل فيديوهات أو ألعاب.',
      'حسابات فضولية تنشر مواد صادمة بعناوين بريئة.',
      'نوافذ منبثقة تستدرج الطفل خارج بيئة آمنة.',
    ],
    prevention: [
      'SafeSearch + DNS فلترة حسب العمر.',
      'قائمة مواقع/تطبيقات موثوقة فقط.',
      'رسالة أسرية ثابتة: أغلق وبلّغ بلا عقوبة.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'حماية فورية', action: 'تقوية الفلاتر وإزالة المصادر المكشوفة.' },
      { week: 'الأسبوع 2', goal: 'حوار تربوي', action: 'نقاش آمن عن المحتوى الصادم وطرق التبليغ.' },
      { week: 'الأسبوع 3', goal: 'بدائل صحية', action: 'إحلال محتوى مناسب للعمر ومراقب.' },
      { week: 'الأسبوع 4', goal: 'تثبيت العادة', action: 'مراجعة أسبوعية للتعرضات وتعديل الضبط.' },
    ],
    dialogues: [
      {
        situation: 'إزالة الخوف',
        opener: 'لو ظهر شيء مزعج، أغلقه وتعال مباشرة، ما فيه عقاب.',
        advice: 'أزل وصمة الاعتراف من البداية.',
      },
      {
        situation: 'توجيه عملي',
        opener: 'نعدل الإعدادات سوا حتى ما يتكرر الوصول لهذا المحتوى.',
        advice: 'الحوار يجب أن ينتهي بخطوة تقنية واضحة.',
      },
      {
        situation: 'تثبيت القاعدة',
        opener: 'أي رابط غريب أو محتوى صادم: لا فتح، فقط بلّغ.',
        advice: 'التكرار اليومي يبني سلوك الأمان.',
      },
    ],
    alertTemplates: [
      'تنبيه محتوى: محاولات وصول لتصنيفات محجوبة أعلى من المعتاد.',
      'تنبيه وقائي: يُنصح بتحديث مرشحات المحتوى لهذا العمر.',
    ],
    incidentPlan: [
      'إيقاف المصدر المسبب (رابط/حساب/تطبيق).',
      'مراجعة الفلاتر وإعدادات البحث الآمن.',
      'حوار احتواء قصير مع الطفل دون لوم.',
      'تفعيل قائمة بدائل آمنة للمحتوى.',
      'متابعة 7 أيام لقياس التكرار.',
    ],
  },
  {
    id: 'cyber_crime',
    title: 'الانحراف السيبراني',
    icon: '👨‍💻',
    severity: AlertSeverity.HIGH,
    severityColor: 'bg-slate-800',
    symptoms: [
      'استخدام أدوات غير موثوقة بصيغة هجومية.',
      'الحديث عن اختراق حسابات باعتباره إنجازًا.',
      'إخفاء الهوية بشكل مبالغ دون مبرر واقعي.',
    ],
    lurePatterns: [
      'قنوات تقدم سكربتات جاهزة بدافع الفضول.',
      'مجموعات تعطي مهام تخريبية كمنافسة.',
      'تحفيز اجتماعي حول القوة التقنية مقابل كسر القوانين.',
    ],
    prevention: [
      'حظر مصادر الأدوات المجهولة.',
      'شرح الفرق بين التعلم الأمني القانوني والتعدي.',
      'توجيه الموهبة إلى منصات CTF تعليمية بإشراف.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'احتواء السلوك', action: 'إيقاف الأدوات الخطرة ومراجعة الجهاز.' },
      { week: 'الأسبوع 2', goal: 'بديل قانوني', action: 'بدء مسار تعلم أخلاقي للأمن السيبراني.' },
      { week: 'الأسبوع 3', goal: 'وعي قانوني', action: 'جلسة عواقب جنائية مبسطة ومباشرة.' },
      { week: 'الأسبوع 4', goal: 'التزام مستمر', action: 'خطة استخدام تقنية خاضعة لمراجعة أسبوعية.' },
    ],
    dialogues: [
      {
        situation: 'إعادة توجيه المهارة',
        opener: 'ذكاؤك التقني مهم، والأفضل تحويله لمسار احترافي قانوني.',
        advice: 'اعترف بالموهبة أولًا ثم أعد توجيهها.',
      },
      {
        situation: 'حدود واضحة',
        opener: 'أي هجوم رقمي قد يصبح قضية جنائية تؤثر على مستقبلك.',
        advice: 'وضح العواقب بدون تهويل عاطفي.',
      },
      {
        situation: 'مسار بديل',
        opener: 'نختار معًا منصة تدريب قانونية ونبني مهاراتك بشكل آمن.',
        advice: 'البديل العملي يقلل العودة للسلوك الخطر.',
      },
    ],
    alertTemplates: [
      'تنبيه سلوكي: نشاط تقني هجومي متكرر يحتاج إعادة توجيه فوري.',
      'تنبيه تقني: تثبيت أدوات مجهولة المصدر على جهاز الطفل.',
    ],
    incidentPlan: [
      'إيقاف الأدوات المجهولة فورًا.',
      'فحص الجهاز وإزالة المصادر غير الموثوقة.',
      'جلسة توضيح قانوني قصيرة.',
      'إدراج مسار تعلم أخلاقي بديل.',
      'متابعة التزام أسبوعية.',
    ],
  },
  {
    id: 'crypto_scams',
    title: 'الاحتيال المالي الرقمي',
    icon: '💸',
    severity: AlertSeverity.MEDIUM,
    severityColor: 'bg-amber-600',
    symptoms: [
      'اندفاع تجاه أرباح سريعة غير مفهومة.',
      'طلب مفاجئ لبطاقات أو تحويلات رقمية.',
      'الترويج لقنوات استثمار غير موثوقة بين الأصدقاء.',
    ],
    lurePatterns: [
      'وعود بعوائد مضمونة خلال وقت قصير.',
      'روابط Airdrop/محافظ مزيفة.',
      'ضغط من مؤثرين أو مجموعات توصيات مجهولة.',
    ],
    prevention: [
      'إيقاف أي تحويل بلا موافقة ولي الأمر.',
      'حظر الكلمات والقنوات الاحتيالية المتكررة.',
      'تعليم قواعد التحقق المالي الأساسي.',
    ],
    interventionProgram: [
      { week: 'الأسبوع 1', goal: 'تجميد المخاطر', action: 'وقف المدفوعات غير المعتمدة ومراجعة الحركة المالية.' },
      { week: 'الأسبوع 2', goal: 'تنظيف المصادر', action: 'حظر القنوات المشبوهة وتدقيق الروابط.' },
      { week: 'الأسبوع 3', goal: 'رفع الوعي', action: 'جلسة وعي مالي للأسرة مع أمثلة احتيال شائعة.' },
      { week: 'الأسبوع 4', goal: 'ضبط دائم', action: 'حدود مالية شهرية وإشعارات فورية.' },
    ],
    dialogues: [
      {
        situation: 'تصحيح المفهوم',
        opener: 'أي ربح سريع مضمون غالبًا خطر، خلنا نتحقق قبل أي خطوة.',
        advice: 'التوعية المالية المبكرة تقلل التورط.',
      },
      {
        situation: 'حدود الأسرة',
        opener: 'أي معاملة رقمية لازم تمر بمراجعة ولي الأمر.',
        advice: 'تحويل القاعدة إلى إجراء واضح داخل التطبيق.',
      },
      {
        situation: 'بدائل آمنة',
        opener: 'نتعلم الاستثمار الصحيح من مصادر موثوقة بدل القنوات العشوائية.',
        advice: 'استبدل المنع المجرد بمسار تعلم بديل.',
      },
    ],
    alertTemplates: [
      'تنبيه مالي: نشاط تحويل غير اعتيادي يحتاج مراجعة فورية.',
      'تنبيه احتيال: رصد تفاعل مع قنوات ربح سريع مجهولة.',
    ],
    incidentPlan: [
      'إيقاف أي عملية دفع قيد التنفيذ.',
      'حصر الحسابات والقنوات المتورطة.',
      'تأمين وسيلة الدفع المرتبطة.',
      'إبلاغ المنصة/البنك حسب الحالة.',
      'جلسة توعية مالية مباشرة للطفل.',
    ],
  },
];

const severityClassMap: Record<AlertSeverity, string> = {
  [AlertSeverity.CRITICAL]: 'bg-red-100 text-red-700 border-red-200',
  [AlertSeverity.HIGH]: 'bg-orange-100 text-orange-700 border-orange-200',
  [AlertSeverity.MEDIUM]: 'bg-amber-100 text-amber-700 border-amber-200',
  [AlertSeverity.LOW]: 'bg-emerald-100 text-emerald-700 border-emerald-200',
};

const severityTextMap: Record<AlertSeverity, string> = {
  [AlertSeverity.CRITICAL]: 'حرج',
  [AlertSeverity.HIGH]: 'مرتفع',
  [AlertSeverity.MEDIUM]: 'متوسط',
  [AlertSeverity.LOW]: 'منخفض',
};

const inferScenarioId = (child?: Child): GuidanceScenario['id'] => {
  const profile = child?.psychProfile;
  if (profile?.priorityScenario) {
    return profile.priorityScenario;
  }

  const hay = (profile?.recentKeywords || []).join(' ');
  if (hay.includes('تهديد') || hay.includes('ابتزاز')) return 'threat_exposure';
  if (hay.includes('تنمر')) return 'bullying';
  if (hay.includes('سهر') || hay.includes('إدمان') || hay.includes('لعب')) return 'gaming';
  if (hay.includes('اختراق') || hay.includes('سكربت')) return 'cyber_crime';
  if (hay.includes('استثمار') || hay.includes('تحويل')) return 'crypto_scams';
  if (hay.includes('إباحية') || hay.includes('محتوى')) return 'inappropriate_content';
  return 'bullying';
};

const scenarioToCategory = (scenarioId: PsychScenarioId): Category => {
  switch (scenarioId) {
    case 'bullying':
      return Category.BULLYING;
    case 'threat_exposure':
      return Category.BLACKMAIL;
    case 'gaming':
      return Category.SAFE;
    case 'inappropriate_content':
      return Category.ADULT_CONTENT;
    case 'cyber_crime':
      return Category.PREDATOR;
    case 'crypto_scams':
      return Category.SCAM;
    default:
      return Category.BULLYING;
  }
};

const PsychologicalInsightView: React.FC<PsychologicalInsightViewProps> = ({
  theme,
  child,
  alerts = [],
  lang = 'ar',
  onAcceptPlan,
  onApplyModeToChild,
  onPlanExecutionResult,
  onSaveExecutionEvidence,
}) => {
  const profile = child?.psychProfile;
  const navigate = useNavigate();
  const primaryCardRef = useRef<HTMLDivElement | null>(null);
  const radarContainerRef = useRef<HTMLDivElement | null>(null);
  const trendContainerRef = useRef<HTMLDivElement | null>(null);
  const [radarSize, setRadarSize] = useState({ width: 0, height: 0 });
  const [trendSize, setTrendSize] = useState({ width: 0, height: 0 });
  const diagnosis = useMemo(
    () => diagnosePsychScenarioFromAlerts(child?.name || '', alerts),
    [child?.name, alerts]
  );

  const [activeScenarioId, setActiveScenarioId] = useState<GuidanceScenario['id']>(
    diagnosis?.scenarioId || inferScenarioId(child)
  );
  const [copiedPlan, setCopiedPlan] = useState(false);
  const [autoSelection, setAutoSelection] = useState<Record<string, boolean>>({});
  const [autoStatus, setAutoStatus] = useState<Record<string, AutoStepStatus>>({});
  const [isAutoRunning, setIsAutoRunning] = useState(false);
  const [autoRunSummary, setAutoRunSummary] = useState('');
  const [executionTimeline, setExecutionTimeline] = useState<PlanTimelineEntry[]>([]);
  const [timelineFilter, setTimelineFilter] = useState<'all' | PlanTimelineStatus>('all');
  const [isSavingExecutionEvidence, setIsSavingExecutionEvidence] = useState(false);
  const [planVideoSource, setPlanVideoSource] = useState<PlanVideoSource>('screen');
  const [planAudioSource, setPlanAudioSource] = useState<PlanAudioSource>('mic');
  const [playbooks, setPlaybooks] = useState<SafetyPlaybook[]>([]);
  const [blackoutMessage, setBlackoutMessage] = useState(
    lang === 'ar'
      ? 'تم قفل الجهاز لدواعي الأمان. يرجى التواصل مع الوالدين.'
      : 'Device locked for safety. Please contact a parent.'
  );

  const activeScenario = useMemo(
    () => guidanceScenarios.find((s) => s.id === activeScenarioId) || guidanceScenarios[0],
    [activeScenarioId]
  );

  const fallbackBlackoutMessage = useMemo(
    () =>
      lang === 'ar'
        ? 'تم قفل الجهاز لدواعي الأمان. يرجى التواصل مع الوالدين.'
        : 'Device locked for safety. Please contact a parent.',
    [lang]
  );

  useEffect(() => {
    setActiveScenarioId(diagnosis?.scenarioId || inferScenarioId(child));
  }, [
    child?.id,
    child?.psychProfile?.priorityScenario,
    child?.psychProfile?.recentKeywords,
    diagnosis?.scenarioId,
  ]);

  useEffect(() => {
    let mounted = true;
    const loadPlaybooks = async () => {
      if (!child?.parentId) {
        if (mounted) setPlaybooks([]);
        return;
      }
      try {
        const stored = await fetchPlaybooks(child.parentId);
        if (!mounted) return;
        setPlaybooks(stored);
      } catch (error) {
        if (!mounted) return;
        console.warn('Failed to load psychological playbooks:', error);
        setPlaybooks([]);
      }
    };
    void loadPlaybooks();
    return () => {
      mounted = false;
    };
  }, [child?.parentId]);

  useEffect(() => {
    if (!blackoutMessage.trim()) {
      setBlackoutMessage(fallbackBlackoutMessage);
    }
  }, [blackoutMessage, fallbackBlackoutMessage]);

  useEffect(() => {
    const el = primaryCardRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollIntoView({ behavior: 'auto', block: 'start' });
      el.focus({ preventScroll: true });
    });
  }, [child?.id]);

  useEffect(() => {
    const node = radarContainerRef.current;
    if (!node) return;

    let raf = 0;
    const checkReady = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const rect = node.getBoundingClientRect();
        setRadarSize({
          width: Math.max(0, Math.floor(rect.width)),
          height: Math.max(0, Math.floor(rect.height)),
        });
      });
    };

    checkReady();
    const observer = new ResizeObserver(checkReady);
    observer.observe(node);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [child?.id]);

  useEffect(() => {
    const node = trendContainerRef.current;
    if (!node) return;

    let raf = 0;
    const checkReady = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const rect = node.getBoundingClientRect();
        setTrendSize({
          width: Math.max(0, Math.floor(rect.width)),
          height: Math.max(0, Math.floor(rect.height)),
        });
      });
    };

    checkReady();
    const observer = new ResizeObserver(checkReady);
    observer.observe(node);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [child?.id]);

  if (!child || !profile) {
    return <div className="p-20 text-center font-black">جاري تحليل النبض النفسي...</div>;
  }

  const stabilityScore = Math.round((profile.moodScore + (100 - profile.anxietyLevel)) / 2);
  const readinessScore = profile.incidentReadinessScore ?? Math.max(35, 95 - profile.anxietyLevel);
  const frustrationScore = Math.max(0, Math.min(100, Math.round(100 - profile.moodScore)));
  const aggressionScore = Math.max(
    0,
    Math.min(
      100,
      Math.round(
        profile.anxietyLevel * 0.4 +
          profile.isolationRisk * 0.35 +
          frustrationScore * 0.25
      )
    )
  );
  const quickAdvisorTip =
    diagnosis?.topSignals?.[0]?.suggestedAction ||
    activeScenario.dialogues[0]?.advice ||
    profile.recommendation;

  const radarData = [
    { subject: 'قلق', A: profile.anxietyLevel, fullMark: 100 },
    { subject: 'إحباط', A: frustrationScore, fullMark: 100 },
    { subject: 'عزلة', A: profile.isolationRisk, fullMark: 100 },
    { subject: 'عدوانية', A: aggressionScore, fullMark: 100 },
    { subject: 'هدوء', A: profile.moodScore, fullMark: 100 },
  ];

  const weeklyTrend =
    profile.weeklyTrend && profile.weeklyTrend.length > 0
      ? profile.weeklyTrend
      : [
          { label: 'الاثنين', value: 58 },
          { label: 'الثلاثاء', value: 62 },
          { label: 'الأربعاء', value: 55 },
          { label: 'الخميس', value: 64 },
          { label: 'الجمعة', value: 60 },
        ];

  const riskSignals = useMemo(() => {
    const diagnosticSignals = diagnosis?.topSignals || [];
    const profileSignals = profile.riskSignals || [];
    const merged = [...diagnosticSignals, ...profileSignals];
    if (merged.length > 0) {
      const unique = new Map<string, (typeof merged)[number]>();
      for (const signal of merged) {
        const key = `${signal.title}-${signal.severity}`;
        if (!unique.has(key)) {
          unique.set(key, signal);
        }
      }
      return Array.from(unique.values()).slice(0, 4);
    }
    return [
      {
        id: `fallback-${activeScenario.id}`,
        title: activeScenario.title,
        severity: activeScenario.severity,
        reason: activeScenario.symptoms[0],
        suggestedAction: activeScenario.incidentPlan[0],
      },
    ];
  }, [diagnosis?.topSignals, profile.riskSignals, activeScenario]);

  const childAlerts = useMemo(() => {
    const norm = (value?: string) => (value || '').toLowerCase().replace(/\s+/g, ' ').trim();
    const childNameNorm = norm(child.name);
    return alerts
      .filter((alert) => {
        const alertNameNorm = norm(alert.childName);
        return (
          !!alertNameNorm &&
          !!childNameNorm &&
          (alertNameNorm === childNameNorm ||
            alertNameNorm.includes(childNameNorm) ||
            childNameNorm.includes(alertNameNorm))
        );
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [alerts, child.name]);

  const dominantPlatform = useMemo(() => {
    const count = new Map<string, number>();
    for (const alert of childAlerts) {
      const key = (alert.platform || 'Unknown').trim();
      count.set(key, (count.get(key) || 0) + 1);
    }
    const sorted = Array.from(count.entries()).sort((a, b) => b[1] - a[1]);
    return sorted[0]?.[0] || childAlerts[0]?.platform || 'Discord';
  }, [childAlerts]);

  const dominantSeverity = useMemo<AlertSeverity>(() => {
    if (diagnosis?.topSignals?.[0]?.severity) {
      return diagnosis.topSignals[0].severity;
    }
    const fromAlerts = childAlerts[0]?.severity;
    return fromAlerts || activeScenario.severity;
  }, [diagnosis?.topSignals, childAlerts, activeScenario.severity]);

  const highRiskApp = useMemo(() => {
    const apps = child.appUsage || [];
    if (apps.length === 0) return null;
    const platformNorm = dominantPlatform.toLowerCase();
    const direct = apps.find((app) => app.appName.toLowerCase().includes(platformNorm));
    if (direct) return direct;
    const fallback = apps.find((app) =>
      ['discord', 'telegram', 'roblox', 'tiktok', 'snapchat', 'youtube'].some((name) =>
        app.appName.toLowerCase().includes(name)
      )
    );
    return fallback || apps[0];
  }, [child.appUsage, dominantPlatform]);

  const blockedDomains = useMemo(
    () => scenarioBlockedDomains[activeScenario.id] || [],
    [activeScenario.id]
  );

  const playbookDrivenSteps = useMemo<AutoExecutionStep[]>(() => {
    const category = scenarioToCategory(activeScenario.id);
    const actions = getDefenseActionsWithPlaybooks(category, dominantSeverity, playbooks);

    const priorityToSeverity = (priority: string): AlertSeverity => {
      if (priority === 'critical') return AlertSeverity.CRITICAL;
      if (priority === 'high') return AlertSeverity.HIGH;
      if (priority === 'medium') return AlertSeverity.MEDIUM;
      return AlertSeverity.LOW;
    };

    return actions
      .map((action) => ({
        id: `pb-${action.id}`,
        title: lang === 'ar' ? `إجراء بروتوكول: ${action.label}` : `Playbook Action: ${action.label}`,
        description:
          lang === 'ar'
            ? 'خطوة مسترجعة من بروتوكولات الحماية المخصصة للعائلة.'
            : 'A family-configured action restored from safety playbooks.',
        command: action.command as AutoExecutionStep['command'],
        value: action.payload ?? true,
        minSeverity: priorityToSeverity(action.priority),
        enabledByDefault: true,
      }));
  }, [activeScenario.id, dominantSeverity, lang, playbooks]);

  useEffect(() => {
    if (activeScenario.id === 'gaming') {
      setPlanVideoSource('screen');
      setPlanAudioSource('system');
      return;
    }
    if (activeScenario.id === 'bullying') {
      setPlanVideoSource('camera_front');
      setPlanAudioSource('mic');
      return;
    }
    setPlanVideoSource('screen');
    setPlanAudioSource('mic');
  }, [activeScenario.id, child.id]);

  const digitalBalanceNarrative = useMemo(() => {
    const appLabel = highRiskApp?.appName || dominantPlatform;
    if (activeScenario.id === 'threat_exposure') {
      return `بناءً على معطيات المرصودة، نوصي بتطبيق فلتر الغرف في ${appLabel} وحظر المستخدمين مجهولي الهوية فورًا مع تفعيل التوثيق اللحظي.`;
    }
    if (activeScenario.id === 'bullying') {
      return `نوصي بتشديد الخصوصية داخل ${appLabel}، تقييد المراسلة من الغرباء، وتفعيل بروتوكول "وثّق/احظر/بلّغ" تلقائيًا.`;
    }
    if (activeScenario.id === 'gaming') {
      return `نوصي بضبط ${appLabel} عبر وضع متوازن: جلسات لعب مجدولة + إيقاف الإشعارات المشتتة + منع الانضمام لغرف عامة مرتفعة المخاطر.`;
    }
    return `نوصي بخطة توازن رقمي مخصصة لـ ${appLabel}: تقليل سطح التعرض، رفع الرقابة اللحظية، وتفعيل استجابة تلقائية عند ارتفاع المخاطر.`;
  }, [activeScenario.id, dominantPlatform, highRiskApp?.appName]);

  const autoExecutionSteps = useMemo<AutoExecutionStep[]>(
    () => {
      const baseSteps: AutoExecutionStep[] = [
      {
        id: 'snapshot',
        title: 'توثيق فوري',
        description: 'أخذ لقطة شاشة فورية لإثبات الحالة الحالية.',
        command: 'takeScreenshot',
        value: true,
        minSeverity: AlertSeverity.LOW,
        enabledByDefault: true,
      },
      {
        id: 'block-app',
        title: 'حظر التطبيق الأعلى خطورة',
        description: highRiskApp
          ? `تفعيل حظر ${highRiskApp.appName} مؤقتًا لحين مراجعة المشرف.`
          : 'لا يوجد تطبيق مرصود ليتم حظره تلقائيًا.',
        command: 'blockApp',
        value: highRiskApp
          ? { appId: highRiskApp.id, isBlocked: true, reason: 'digital_balance_auto' }
          : null,
        minSeverity: AlertSeverity.MEDIUM,
        enabledByDefault: !!highRiskApp,
      },
      {
        id: 'video-source',
        title: 'ضبط مصدر الصورة',
        description: 'تحديد مصدر البث: شاشة الجهاز.',
        command: 'setVideoSource',
        value: planVideoSource,
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: true,
      },
      {
        id: 'audio-source',
        title: 'ضبط مصدر الصوت',
        description: 'تحديد مصدر الصوت: ميكروفون الجهاز.',
        command: 'setAudioSource',
        value: planAudioSource,
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: true,
      },
      {
        id: 'start-stream',
        title: 'بدء بث رقابي مباشر',
        description: 'تشغيل بث مباشر للمراجعة السريعة من ولي الأمر.',
        command: 'startLiveStream',
        value: {
          videoSource: planVideoSource,
          audioSource: planAudioSource,
          source: 'digital_balance_auto',
        },
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: true,
      },
      {
        id: 'lock-device',
        title: 'قفل وقائي مؤقت',
        description: 'قفل مؤقت للجهاز حتى اكتمال التقييم.',
        command: 'lockDevice',
        value: true,
        minSeverity: AlertSeverity.CRITICAL,
        enabledByDefault: true,
      },
      {
        id: 'blackout-screen',
        title: 'شاشة سوداء برسالة حماية',
        description: 'تفعيل حجب الجهاز مع رسالة إرشادية للطفل حتى مراجعة الوالدين.',
        command: 'lockscreenBlackout',
        value: { enabled: true, source: 'digital_balance_auto' },
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: activeScenario.id === 'threat_exposure' || activeScenario.id === 'bullying',
      },
      {
        id: 'walkie-enable',
        title: 'تفعيل قناة Walkie-Talkie',
        description: 'تفعيل قناة التواصل الصوتي الفوري بين الوالد والطفل.',
        command: 'walkieTalkieEnable',
        value: { enabled: true, source: 'mic' },
        minSeverity: AlertSeverity.HIGH,
        enabledByDefault: activeScenario.id === 'threat_exposure',
      },
      {
        id: 'siren',
        title: 'صافرة ردع',
        description: 'تشغيل صافرة في الحالات الحرجة جدًا.',
        command: 'playSiren',
        value: true,
        minSeverity: AlertSeverity.CRITICAL,
        enabledByDefault: false,
      },
      ];

      const merged = [...baseSteps];
      for (const step of playbookDrivenSteps) {
        if (!merged.some((existing) => existing.command === step.command)) {
          merged.push(step);
        }
      }
      return merged;
    },
    [activeScenario.id, highRiskApp, planAudioSource, planVideoSource, playbookDrivenSteps]
  );

  useEffect(() => {
    const initSelection: Record<string, boolean> = {};
    const initStatus: Record<string, AutoStepStatus> = {};
    for (const step of autoExecutionSteps) {
      initSelection[step.id] = step.enabledByDefault;
      initStatus[step.id] = 'idle';
    }
    setAutoSelection(initSelection);
    setAutoStatus(initStatus);
    setAutoRunSummary('');
    setExecutionTimeline([]);
    setTimelineFilter('all');
  }, [child.id, activeScenario.id, dominantSeverity, highRiskApp?.id, autoExecutionSteps]);

  const pushTimeline = (entry: Omit<PlanTimelineEntry, 'id' | 'at'>) => {
    setExecutionTimeline((prev) =>
      [
        {
          id: `timeline-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          at: new Date(),
          ...entry,
        },
        ...prev,
      ].slice(0, 40)
    );
  };

  const buildSuggestedPlan = (): Partial<CustomMode> => {
    const frequentApps = [...(child.appUsage || [])]
      .sort((a, b) => b.minutesUsed - a.minutesUsed)
      .slice(0, 3)
      .map((app) => app.appName);

    return {
      name: `Digital Balance Mode - ${child.name}`,
      icon: 'DB',
      color: 'bg-indigo-900',
      allowedApps: frequentApps.length > 0 ? frequentApps : ['School App', 'WhatsApp'],
      allowedUrls: [],
      blacklistedUrls: blockedDomains,
      isInternetCut: dominantSeverity === AlertSeverity.CRITICAL,
      isDeviceLocked: false,
      isScreenDimmed: true,
      cameraEnabled: dominantSeverity !== AlertSeverity.CRITICAL,
      micEnabled: true,
      internetStartTime: '06:00',
      internetEndTime: '22:00',
      activeDays: [0, 1, 2, 3, 4, 5, 6],
      preferredVideoSource: planVideoSource,
      preferredAudioSource: planAudioSource,
      autoStartLiveStream: severityRank[dominantSeverity] >= severityRank[AlertSeverity.HIGH],
      autoTakeScreenshot: true,
      blackoutOnApply: severityRank[dominantSeverity] >= severityRank[AlertSeverity.HIGH],
      blackoutMessage: blackoutMessage.trim() || fallbackBlackoutMessage,
      enableWalkieTalkieOnApply: activeScenario.id === 'threat_exposure' || activeScenario.id === 'bullying',
    };
  };

  const handleApplyEmergencyPlan = () => {
    const suggested = buildSuggestedPlan();
    onAcceptPlan(suggested);
    navigate('/modes', { state: { suggestedMode: suggested } });
  };

  const toggleAutoStep = (stepId: string) => {
    if (isAutoRunning) return;
    setAutoSelection((prev) => ({ ...prev, [stepId]: !prev[stepId] }));
  };

  const runAutoExecutionPlan = async () => {
    if (isAutoRunning) return;
    setIsAutoRunning(true);
    setAutoRunSummary('');
    pushTimeline({
      title: lang === 'ar' ? 'بدء التنفيذ' : 'Execution started',
      detail:
        lang === 'ar'
          ? `بدء تشغيل الخطة على ${child.name}.`
          : `Started running the plan for ${child.name}.`,
      status: 'info',
    });

    let done = 0;
    let failed = 0;
    let skipped = 0;
    const currentSeverityRank = severityRank[dominantSeverity];

    for (const step of autoExecutionSteps) {
      if (!autoSelection[step.id]) {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'skipped' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'تم التخطي (غير محدد).' : 'Skipped (not selected).',
          status: 'skipped',
        });
        skipped += 1;
        continue;
      }

      if (currentSeverityRank < severityRank[step.minSeverity]) {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'skipped' }));
        pushTimeline({
          title: step.title,
          detail:
            lang === 'ar'
              ? `تم التخطي لأن مستوى الخطر الحالي أقل من الحد الأدنى (${step.minSeverity}).`
              : `Skipped because current severity is below minimum (${step.minSeverity}).`,
          status: 'skipped',
        });
        skipped += 1;
        continue;
      }

      if (step.command === 'blockApp' && !highRiskApp) {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'skipped' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'تم التخطي لعدم وجود تطبيق عالي الخطورة.' : 'Skipped (no high-risk app).',
          status: 'skipped',
        });
        skipped += 1;
        continue;
      }

      try {
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'pending' }));
        let commandValue = step.value;
        if (step.command === 'lockscreenBlackout') {
          commandValue = {
            enabled: true,
            message: blackoutMessage.trim() || fallbackBlackoutMessage,
            source: 'digital_balance_auto',
          };
        }
        if (step.command === 'walkieTalkieEnable') {
          commandValue = {
            enabled: true,
            source: planAudioSource,
            sourceTag: 'digital_balance_auto',
          };
        }
        await sendRemoteCommand(child.id, step.command, commandValue);
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'done' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'تم التنفيذ بنجاح.' : 'Executed successfully.',
          status: 'done',
        });
        done += 1;
      } catch (error) {
        console.error(`Auto step failed: ${step.id}`, error);
        setAutoStatus((prev) => ({ ...prev, [step.id]: 'error' }));
        pushTimeline({
          title: step.title,
          detail: lang === 'ar' ? 'فشل التنفيذ.' : 'Execution failed.',
          status: 'error',
        });
        failed += 1;
      }
    }

    const summary = { done, skipped, failed };
    setIsAutoRunning(false);
    setAutoRunSummary(
      lang === 'ar'
        ? `تم تنفيذ ${done} خطوة، تخطي ${skipped}، وفشل ${failed}.`
        : `Executed ${done} steps, skipped ${skipped}, failed ${failed}.`
    );
    pushTimeline({
      title: lang === 'ar' ? 'ملخص التنفيذ' : 'Execution summary',
      detail:
        lang === 'ar'
          ? `${done} تم، ${skipped} تخطي، ${failed} فشل.`
          : `${done} done, ${skipped} skipped, ${failed} failed.`,
      status: failed > 0 ? 'error' : 'done',
    });
    onPlanExecutionResult?.(summary);
    return summary;
  };

  const runPlanAndCreateMode = async () => {
    await runAutoExecutionPlan();
    const suggested = buildSuggestedPlan();
    const modeId = onAcceptPlan(suggested);
    pushTimeline({
      title: lang === 'ar' ? 'حفظ الوضع الذكي' : 'Smart mode saved',
      detail:
        lang === 'ar'
          ? `تم حفظ الوضع ${suggested.name || ''}.`
          : `Saved mode ${suggested.name || ''}.`,
      status: 'done',
    });
    if (!modeId) {
      pushTimeline({
        title: lang === 'ar' ? 'معرف الوضع' : 'Mode ID',
        detail:
          lang === 'ar'
            ? 'تم حفظ الوضع بدون معرف فوري، يمكن تطبيقه من صفحة الأوضاع.'
            : 'Mode saved without immediate id. You can apply it from Modes page.',
        status: 'info',
      });
      navigate('/modes', { state: { suggestedMode: suggested } });
      return;
    }
    if (onApplyModeToChild) {
      try {
        await onApplyModeToChild(child.id, modeId);
        pushTimeline({
          title: lang === 'ar' ? 'تطبيق الوضع' : 'Mode applied',
          detail:
            lang === 'ar'
              ? `تم تطبيق الوضع على ${child.name}.`
              : `Applied mode to ${child.name}.`,
          status: 'done',
        });
      } catch (error) {
        pushTimeline({
          title: lang === 'ar' ? 'تطبيق الوضع' : 'Mode apply',
          detail: lang === 'ar' ? 'فشل تطبيق الوضع.' : 'Failed to apply mode.',
          status: 'error',
        });
        console.error('Apply mode from pulse failed', error);
      }
    }
  };

  const stepStateClass = (status: AutoStepStatus) => {
    if (status === 'done') return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (status === 'pending') return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    if (status === 'error') return 'bg-rose-100 text-rose-700 border-rose-200';
    if (status === 'skipped') return 'bg-slate-100 text-slate-500 border-slate-200';
    return 'bg-slate-50 text-slate-500 border-slate-100';
  };

  const stepStateLabel = (status: AutoStepStatus) => {
    if (lang === 'ar') {
      if (status === 'done') return 'تم';
      if (status === 'pending') return 'قيد التنفيذ';
      if (status === 'error') return 'فشل';
      if (status === 'skipped') return 'تخطي';
      return 'جاهز';
    }
    if (status === 'done') return 'Done';
    if (status === 'pending') return 'Running';
    if (status === 'error') return 'Failed';
    if (status === 'skipped') return 'Skipped';
    return 'Idle';
  };

  const timelineBadgeClass = (status: PlanTimelineStatus) => {
    if (status === 'done') return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (status === 'error') return 'bg-rose-100 text-rose-700 border-rose-200';
    if (status === 'skipped') return 'bg-slate-100 text-slate-600 border-slate-200';
    return 'bg-indigo-100 text-indigo-700 border-indigo-200';
  };

  const timelineStatusLabel = (status: PlanTimelineStatus) => {
    if (lang !== 'ar') return status;
    if (status === 'done') return 'تم';
    if (status === 'error') return 'فشل';
    if (status === 'skipped') return 'تخطي';
    return 'معلومة';
  };

  const filteredExecutionTimeline = useMemo(() => {
    if (timelineFilter === 'all') return executionTimeline;
    return executionTimeline.filter((entry) => entry.status === timelineFilter);
  }, [executionTimeline, timelineFilter]);

  const executionSummary = useMemo(() => {
    return executionTimeline.reduce(
      (acc, entry) => {
        if (entry.status === 'done') acc.done += 1;
        if (entry.status === 'error') acc.failed += 1;
        if (entry.status === 'skipped') acc.skipped += 1;
        return acc;
      },
      { done: 0, failed: 0, skipped: 0 }
    );
  }, [executionTimeline]);

  const saveExecutionTimelineToVault = async () => {
    if (!onSaveExecutionEvidence || executionTimeline.length === 0 || isSavingExecutionEvidence) return;

    setIsSavingExecutionEvidence(true);
    try {
      const recordId = await onSaveExecutionEvidence({
        childId: child.id,
        childName: child.name,
        scenarioId: activeScenario.id,
        scenarioTitle: activeScenario.title,
        severity: dominantSeverity,
        dominantPlatform,
        summary: executionSummary,
        timeline: executionTimeline.map((entry) => ({
          title: entry.title,
          detail: entry.detail,
          status: entry.status,
          at: entry.at.toISOString(),
        })),
      });

      pushTimeline({
        title: lang === 'ar' ? 'حفظ في الخزنة' : 'Saved to vault',
        detail:
          lang === 'ar'
            ? 'تم حفظ سجل التنفيذ كدليل في الأرشيف الجنائي.'
            : 'Execution timeline was saved as forensic evidence.',
        status: 'done',
      });

      if (recordId) {
        navigate('/vault', { state: { openAlertId: recordId, presetFilter: 'pulse' } });
      }
    } catch (error) {
      console.error('Save execution evidence failed', error);
      pushTimeline({
        title: lang === 'ar' ? 'حفظ في الخزنة' : 'Save to vault',
        detail:
          lang === 'ar'
            ? 'فشل حفظ سجل التنفيذ في الخزنة.'
            : 'Failed to save execution timeline to vault.',
        status: 'error',
      });
    } finally {
      setIsSavingExecutionEvidence(false);
    }
  };

  const exportExecutionTimeline = () => {
    if (filteredExecutionTimeline.length === 0) return;

    const exportPayload = filteredExecutionTimeline.map((entry) => ({
      title: entry.title,
      detail: entry.detail,
      status: entry.status,
      timestamp: entry.at.toISOString(),
      childName: child.name,
      scenarioId: activeScenario.id,
      severity: dominantSeverity,
    }));

    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = `amanah-execution-timeline-${child.id}-${Date.now()}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(objectUrl);
  };

  const copyIncidentPlan = async () => {
    const payload = [
      `خطة 10 دقائق: ${activeScenario.title}`,
      ...activeScenario.incidentPlan.map((step, idx) => `${idx + 1}. ${step}`),
    ].join('\n');

    try {
      await navigator.clipboard.writeText(payload);
      setCopiedPlan(true);
      setTimeout(() => setCopiedPlan(false), 1500);
    } catch {
      setCopiedPlan(false);
    }
  };

  const renderRadarAxisTick = (tickProps: any) => {
    const { x, y, cx, cy, payload } = tickProps;
    const dx = x - cx;
    const dy = y - cy;
    const length = Math.sqrt(dx * dx + dy * dy) || 1;

    // Keep Arabic labels away from polygon edges, especially left/right axes.
    const radialOffset = Math.abs(dx) > Math.abs(dy) ? 34 : dy > 0 ? 28 : 24;
    const tx = x + (dx / length) * radialOffset;
    const ty = y + (dy / length) * radialOffset + (dy > 0 ? 5 : -3);

    let textAnchor: 'middle' | 'start' | 'end' = 'middle';
    if (Math.abs(dx) > 8) {
      textAnchor = dx > 0 ? 'start' : 'end';
    }

    return (
      <text
        x={tx}
        y={ty}
        textAnchor={textAnchor}
        dominantBaseline="central"
        direction="rtl"
        unicodeBidi="plaintext"
        fill="#64748b"
        fontSize={14}
        fontWeight={800}
        fontFamily="Cairo"
      >
        {payload?.value}
      </text>
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-72 animate-in fade-in" dir="rtl">
      <div className="bg-slate-900 rounded-[4rem] p-12 text-white shadow-2xl border-b-8 border-indigo-600">
        <h2 className="text-5xl font-black tracking-tighter mb-2">Amanah Pulse Pro</h2>
        <p className="text-indigo-300 font-bold text-lg opacity-90">
          تحليل الاستقرار الرقمي والنبض العاطفي لـ {child.name}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div
          ref={primaryCardRef}
          tabIndex={-1}
          className="bg-[#f4f6fa] rounded-[3.5rem] p-8 md:p-10 shadow-xl border border-[#e8ecf3] h-full flex flex-col items-center focus:outline-none focus-visible:ring-4 focus-visible:ring-indigo-200"
        >
          <div className="w-full flex justify-center mb-9">
            <div className="px-8 py-4 bg-[#eef1f6] rounded-full">
              <h3 className="text-[2rem] md:text-[2.2rem] leading-none font-black text-slate-800 text-center">
                مؤشرات التوازن النفسي
              </h3>
            </div>
          </div>
          <div ref={radarContainerRef} className="w-full h-[26rem] relative flex items-center justify-center min-w-0">
            {radarSize.width > 40 && radarSize.height > 40 ? (
              <RadarChart width={radarSize.width} height={radarSize.height} cx="50%" cy="50%" outerRadius="64%" data={radarData}>
                <PolarGrid stroke="#d3dae5" strokeWidth={1.5} />
                <PolarAngleAxis dataKey="subject" tick={renderRadarAxisTick} />
                <RadarComponent
                  name="Amanah Pulse"
                  dataKey="A"
                  stroke="#5f63df"
                  strokeWidth={6}
                  fill="#7b80e7"
                  fillOpacity={0.38}
                />
              </RadarChart>
            ) : (
              <div className="h-full w-full rounded-3xl bg-[#eef2f9]" />
            )}
          </div>
          <div className="w-full mt-3 pt-2">
            <div className="max-w-md mx-auto grid grid-cols-[1fr_auto_1fr] items-center gap-6 text-center">
              <div>
                <p className="text-6xl md:text-7xl leading-none font-black text-rose-500">{profile.anxietyLevel}</p>
                <p className="mt-2 text-xl md:text-2xl font-black text-slate-400">القلق</p>
              </div>
              <div className="h-32 md:h-36 w-px bg-slate-300"></div>
              <div>
                <p className="text-6xl md:text-7xl leading-none font-black text-indigo-600">{stabilityScore}</p>
                <p className="mt-2 text-xl md:text-2xl font-black text-slate-400">الاستقرار</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-indigo-50 rounded-[4rem] p-10 shadow-2xl border border-indigo-100 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <h3 className="text-2xl font-black text-slate-800">بروتوكول الرد المقترح</h3>
            <div className="bg-white p-7 rounded-[2.5rem] border border-indigo-100 italic font-bold text-indigo-900 leading-relaxed">
              {profile.recommendation}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white border border-indigo-100 rounded-2xl p-4 text-center">
                <p className="text-[11px] font-black text-slate-500 mb-1">جاهزية إدارة الحادث</p>
                <p className="text-3xl font-black text-indigo-700">{readinessScore}</p>
              </div>
              <div className="bg-white border border-indigo-100 rounded-2xl p-4 text-center">
                <p className="text-[11px] font-black text-slate-500 mb-1">العاطفة الغالبة</p>
                <p className="text-xl font-black text-slate-800">{profile.dominantEmotion}</p>
              </div>
            </div>
          </div>
          <button
            onClick={handleApplyEmergencyPlan}
            className="py-5 bg-slate-900 text-white rounded-[2rem] font-black text-lg shadow-2xl active:scale-95 transition-all"
          >
            تفعيل وضع الحماية المتوازن
          </button>
        </div>
      </div>

      <section className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h3 className="text-xl font-black text-slate-900">نتيجة التحليل التشخيصي للتنبيهات</h3>
          {diagnosis ? (
            <span className="px-4 py-2 rounded-full bg-indigo-100 text-indigo-700 text-xs font-black">
              دقة التشخيص: {diagnosis.confidence}%
            </span>
          ) : (
            <span className="px-4 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-black">
              لا توجد تنبيهات كافية للتحليل
            </span>
          )}
        </div>

        {diagnosis ? (
          <>
            <p className="text-xs font-bold text-slate-600">
              تم تحليل {diagnosis.analyzedAlertCount} تنبيه خاص بالطفل، وتم ترجيح سيناريو{' '}
              <span className="text-indigo-700 font-black">{activeScenario.title}</span> اعتمادًا على الشدة + الفئة +
              السياق النصي + حداثة الحدث.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {diagnosis.reasons.map((reason, idx) => (
                <div key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-4">
                  <p className="text-xs font-bold text-slate-700 leading-relaxed">{reason}</p>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-xs font-bold text-slate-500">
            سيتم تفعيل الربط التلقائي فور توفر تنبيهات مرتبطة بهذا الطفل.
          </p>
        )}
      </section>

      <section className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-xl space-y-6">
        <h3 className="text-2xl font-black text-slate-900">مؤشرات الخطر الحالية</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {riskSignals.map((signal) => (
            <article key={signal.id} className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-black text-sm text-slate-900">{signal.title}</h4>
                <span
                  className={`px-3 py-1 rounded-full border text-[10px] font-black ${severityClassMap[signal.severity]}`}
                >
                  {severityTextMap[signal.severity]}
                </span>
              </div>
              <p className="text-xs font-bold text-slate-700 leading-relaxed">{signal.reason}</p>
              <p className="text-xs font-black text-indigo-700">إجراء مقترح: {signal.suggestedAction}</p>
            </article>
          ))}
        </div>

        <div className="bg-slate-50 border border-slate-100 rounded-[2rem] p-5">
          <p className="text-[11px] font-black text-slate-500 mb-3">اتجاه النبض خلال الأسبوع</p>
          <div ref={trendContainerRef} className="w-full h-56 min-w-0">
            {trendSize.width > 40 && trendSize.height > 40 ? (
              <BarChart width={trendSize.width} height={trendSize.height} data={weeklyTrend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="label" tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }} />
                <Tooltip cursor={{ fill: '#eef2ff' }} />
                <Bar dataKey="value" fill="#6366f1" radius={[10, 10, 0, 0]} />
              </BarChart>
            ) : (
              <div className="h-full w-full rounded-2xl bg-slate-100" />
            )}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-indigo-700 to-indigo-500 rounded-[3rem] p-8 text-white shadow-2xl border border-indigo-300/30 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-2 max-w-3xl">
            <h3 className="text-2xl md:text-3xl font-black tracking-tight">
              {lang === 'ar' ? 'خطة التوازن الرقمي' : 'Digital Balance Plan'}
            </h3>
            <p className="text-indigo-100 font-bold leading-relaxed">{digitalBalanceNarrative}</p>
          </div>
          <div className="flex flex-col gap-2 text-xs font-black">
            <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20">
              {lang === 'ar' ? 'السيناريو' : 'Scenario'}: {activeScenario.title}
            </span>
            <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20">
              {lang === 'ar' ? 'المنصة' : 'Platform'}: {highRiskApp?.appName || dominantPlatform}
            </span>
            <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20">
              {lang === 'ar' ? 'الحدة' : 'Severity'}: {dominantSeverity}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {blockedDomains.map((domain) => (
            <span key={domain} className="px-3 py-1 rounded-lg text-[11px] font-black bg-white/15 border border-white/20">
              {domain}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <label className="text-xs font-black text-indigo-100 flex flex-col gap-2">
            {lang === 'ar' ? 'مصدر الصورة' : 'Video Source'}
            <select
              value={planVideoSource}
              onChange={(event) => setPlanVideoSource(event.target.value as PlanVideoSource)}
              className="bg-white/15 border border-white/30 rounded-xl px-3 py-2 text-white font-black outline-none"
            >
              <option className="text-slate-900" value="camera_front">
                {lang === 'ar' ? 'الكاميرا الأمامية' : 'Front Camera'}
              </option>
              <option className="text-slate-900" value="camera_back">
                {lang === 'ar' ? 'الكاميرا الخلفية' : 'Back Camera'}
              </option>
              <option className="text-slate-900" value="screen">
                {lang === 'ar' ? 'الشاشة' : 'Screen'}
              </option>
            </select>
          </label>
          <label className="text-xs font-black text-indigo-100 flex flex-col gap-2">
            {lang === 'ar' ? 'مصدر الصوت' : 'Audio Source'}
            <select
              value={planAudioSource}
              onChange={(event) => setPlanAudioSource(event.target.value as PlanAudioSource)}
              className="bg-white/15 border border-white/30 rounded-xl px-3 py-2 text-white font-black outline-none"
            >
              <option className="text-slate-900" value="mic">
                {lang === 'ar' ? 'الميكروفون' : 'Microphone'}
              </option>
              <option className="text-slate-900" value="system">
                {lang === 'ar' ? 'صوت النظام' : 'System Audio'}
              </option>
            </select>
          </label>
        </div>

        <label className="text-xs font-black text-indigo-100 flex flex-col gap-2">
          {lang === 'ar' ? 'رسالة شاشة الحجب الوقائي' : 'Blackout Screen Message'}
          <input
            value={blackoutMessage}
            onChange={(event) => setBlackoutMessage(event.target.value)}
            className="bg-white/15 border border-white/30 rounded-xl px-3 py-2 text-white font-bold outline-none placeholder:text-indigo-200/70"
            placeholder={
              lang === 'ar'
                ? 'مثال: تم قفل الجهاز لدواعي الأمان. يرجى التواصل مع الوالدين.'
                : 'Example: Device locked for safety. Please contact a parent.'
            }
          />
        </label>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleApplyEmergencyPlan}
            className="px-5 py-3 rounded-xl bg-white text-indigo-700 font-black text-sm shadow active:scale-95"
          >
            {lang === 'ar' ? 'إنشاء وضع ذكي مقترح' : 'Create Suggested Smart Mode'}
          </button>
          <button
            onClick={runAutoExecutionPlan}
            disabled={isAutoRunning}
            className="px-5 py-3 rounded-xl bg-slate-900 text-white font-black text-sm shadow disabled:opacity-50 active:scale-95"
          >
            {isAutoRunning
              ? lang === 'ar'
                ? 'جارٍ التنفيذ...'
                : 'Running...'
              : lang === 'ar'
                ? 'تنفيذ الخطة تلقائياً'
                : 'Execute Plan Automatically'}
          </button>
          <button
            onClick={runPlanAndCreateMode}
            disabled={isAutoRunning}
            className="px-5 py-3 rounded-xl bg-emerald-500 text-white font-black text-sm shadow disabled:opacity-50 active:scale-95"
          >
            {isAutoRunning
              ? lang === 'ar'
                ? 'جارٍ التنفيذ...'
                : 'Running...'
              : lang === 'ar'
                ? 'تنفيذ + حفظ + تطبيق'
                : 'Execute + Save as Mode'}
          </button>
        </div>
      </section>

      <section className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-xl space-y-5">
        <div>
          <h3 className="text-xl font-black text-slate-900">
            {lang === 'ar' ? 'خطوات التنفيذ التلقائي' : 'Auto Execution Steps'}
          </h3>
          <p className="text-xs font-bold text-slate-500 mt-1">
            {lang === 'ar'
              ? 'يتم تشغيل الأوامر المختارة مباشرة على جهاز الطفل بناءً على مستوى الخطر الحالي.'
              : 'Selected commands run directly on the child device based on the current risk severity.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {autoExecutionSteps.map((step) => {
            const checked = !!autoSelection[step.id];
            const status = autoStatus[step.id] || 'idle';
            return (
              <article key={step.id} className="rounded-2xl border border-slate-100 bg-slate-50 p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="space-y-1">
                    <h4 className="font-black text-sm text-slate-900">{step.title}</h4>
                    <p className="text-xs font-bold text-slate-600 leading-relaxed">{step.description}</p>
                  </div>
                  <button
                    onClick={() => toggleAutoStep(step.id)}
                    disabled={isAutoRunning}
                    className={`w-12 h-7 rounded-full p-1 transition-all disabled:opacity-50 ${checked ? 'bg-indigo-600' : 'bg-slate-300'}`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${
                        checked ? '-translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="px-3 py-1 rounded-lg text-[10px] font-black bg-slate-200 text-slate-700">
                    {lang === 'ar' ? 'الحد الأدنى' : 'Min'}: {step.minSeverity}
                  </span>
                  <span className={`px-3 py-1 rounded-lg text-[10px] font-black border ${stepStateClass(status)}`}>
                    {stepStateLabel(status)}
                  </span>
                </div>
              </article>
            );
          })}
        </div>

        {autoRunSummary && (
          <div className="rounded-2xl border border-indigo-100 bg-indigo-50 text-indigo-700 px-4 py-3 text-xs font-black">
            {autoRunSummary}
          </div>
        )}

        <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="text-sm font-black text-slate-900">
              {lang === 'ar' ? 'السجل الزمني للتنفيذ' : 'Execution Timeline'}
            </h4>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-slate-500">
                {lang === 'ar'
                  ? `${filteredExecutionTimeline.length} / ${executionTimeline.length} أحداث`
                  : `${filteredExecutionTimeline.length} / ${executionTimeline.length} events`}
              </span>
              <button
                onClick={saveExecutionTimelineToVault}
                disabled={
                  executionTimeline.length === 0 ||
                  isSavingExecutionEvidence ||
                  !onSaveExecutionEvidence
                }
                className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-black disabled:opacity-40"
              >
                {isSavingExecutionEvidence
                  ? lang === 'ar'
                    ? 'جارٍ الحفظ...'
                    : 'Saving...'
                  : lang === 'ar'
                    ? 'حفظ بالخزنة'
                    : 'Save to Vault'}
              </button>
              <button
                onClick={exportExecutionTimeline}
                disabled={filteredExecutionTimeline.length === 0}
                className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-[10px] font-black disabled:opacity-40"
              >
                {lang === 'ar' ? 'تصدير JSON' : 'Export JSON'}
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {(['all', 'done', 'error', 'skipped', 'info'] as const).map((statusKey) => {
              const isActive = timelineFilter === statusKey;
              const label =
                statusKey === 'all'
                  ? lang === 'ar'
                    ? 'الكل'
                    : 'All'
                  : timelineStatusLabel(statusKey);
              return (
                <button
                  key={statusKey}
                  onClick={() => setTimelineFilter(statusKey)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-black border ${
                    isActive
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>

          {filteredExecutionTimeline.length > 0 ? (
            <div className="space-y-2 max-h-56 overflow-y-auto custom-scrollbar pr-1">
              {filteredExecutionTimeline.map((entry) => (
                <article
                  key={entry.id}
                  className="bg-white border border-slate-100 rounded-xl px-3 py-2 flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <p className="text-xs font-black text-slate-900">{entry.title}</p>
                    <p className="text-[11px] font-bold text-slate-600">{entry.detail}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className={`px-2 py-0.5 rounded-md border text-[10px] font-black ${timelineBadgeClass(entry.status)}`}>
                      {timelineStatusLabel(entry.status)}
                    </span>
                    <span className="text-[10px] font-bold text-slate-400">
                      {entry.at.toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                      })}
                    </span>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <p className="text-[11px] font-bold text-slate-500">
              {lang === 'ar'
                ? executionTimeline.length > 0
                  ? 'لا توجد أحداث ضمن الفلتر الحالي.'
                  : 'ابدأ التنفيذ لعرض سجل الخطوات تلقائيًا.'
                : executionTimeline.length > 0
                  ? 'No events for the selected filter.'
                  : 'Run the plan to populate execution timeline.'}
            </p>
          )}
        </div>
      </section>

      <section className="bg-white rounded-[4rem] p-8 md:p-12 shadow-2xl border border-slate-100 space-y-8">
        <div>
          <h3 className="text-3xl font-black text-slate-900 tracking-tighter mb-2">مركز النبض النفسي</h3>
          <p className="text-slate-500 font-bold">اختر المشكلة لعرض الأعراض، الاستدراج، الوقاية، وبرنامج التدخل.</p>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-4 custom-scrollbar">
          {guidanceScenarios.map((scenario) => (
            <button
              key={scenario.id}
              onClick={() => setActiveScenarioId(scenario.id)}
              className={`flex items-center gap-2 px-6 py-4 rounded-2xl whitespace-nowrap transition-all border-2 ${
                activeScenarioId === scenario.id
                  ? `${scenario.severityColor} border-transparent text-white shadow-lg`
                  : 'bg-slate-50 border-slate-100 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <span className="text-xl">{scenario.icon}</span>
              <span className="font-black text-xs">{scenario.title}</span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-7 rounded-[2.5rem] text-white shadow-xl bg-slate-800 space-y-5">
            <div>
              <h4 className="text-2xl font-black mb-2">{activeScenario.title}</h4>
              <p className="text-[11px] font-black text-slate-300">الأعراض والمشكلات</p>
              <ul className="space-y-2 mt-3">
                {activeScenario.symptoms.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs font-bold leading-relaxed">
                    <span className="mt-1 w-1.5 h-1.5 bg-white rounded-full flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="text-[11px] font-black text-slate-300">أساليب الاستدراج الشائعة</p>
              <ul className="space-y-2 mt-3">
                {activeScenario.lurePatterns.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs font-bold leading-relaxed">
                    <span className="mt-1 w-1.5 h-1.5 bg-indigo-300 rounded-full flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-indigo-50 border border-indigo-100 rounded-[2.5rem] p-7 space-y-5">
            <div>
              <p className="text-[11px] font-black text-indigo-500 uppercase tracking-widest mb-3">نصيحة المستشار</p>
              <p className="text-slate-800 font-black leading-relaxed">{quickAdvisorTip}</p>
            </div>
            <div>
              <p className="text-[11px] font-black text-indigo-500 uppercase tracking-widest mb-3">إجراءات الوقاية</p>
              <ul className="space-y-2">
                {activeScenario.prevention.map((item, idx) => (
                  <li key={idx} className="text-xs font-bold text-slate-700 leading-relaxed">• {item}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-100 rounded-[2.5rem] p-6 space-y-4">
          <h4 className="text-xl font-black text-slate-900">برنامج تدخل علاجي (4 أسابيع)</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeScenario.interventionProgram.map((step) => (
              <article key={step.week} className="bg-white border border-slate-100 rounded-2xl p-4 space-y-2">
                <p className="text-[11px] font-black text-indigo-500">{step.week}</p>
                <p className="text-sm font-black text-slate-800">{step.goal}</p>
                <p className="text-xs font-bold text-slate-600 leading-relaxed">{step.action}</p>
              </article>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-xl font-black text-slate-900">حوارات عملية جاهزة</h4>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {activeScenario.dialogues.map((dialogue, idx) => (
              <article key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
                <p className="text-[11px] font-black text-indigo-500">{dialogue.situation}</p>
                <p className="text-sm font-bold text-slate-800 leading-relaxed">{dialogue.opener}</p>
                <div className="bg-white rounded-xl p-3 border border-slate-100">
                  <p className="text-[11px] font-black text-slate-500 mb-1">توجيه الخبير</p>
                  <p className="text-xs font-bold text-slate-700">{dialogue.advice}</p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-100 rounded-[2.5rem] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-lg font-black text-slate-900">خطة 10 دقائق للحادث</h4>
              <button
                onClick={copyIncidentPlan}
                className="px-4 py-2 text-[11px] font-black rounded-xl bg-slate-900 text-white"
              >
                {copiedPlan ? 'تم النسخ' : 'نسخ الخطة'}
              </button>
            </div>
            <ol className="space-y-2">
              {activeScenario.incidentPlan.map((step, idx) => (
                <li key={idx} className="text-xs font-bold text-slate-700 leading-relaxed">
                  {idx + 1}. {step}
                </li>
              ))}
            </ol>
          </div>

          <div className="bg-white border border-slate-100 rounded-[2.5rem] p-6 space-y-4">
            <h4 className="text-lg font-black text-slate-900">رسائل تنبيه جاهزة داخل التطبيق</h4>
            <ul className="space-y-2">
              {activeScenario.alertTemplates.map((template, idx) => (
                <li key={idx} className="text-xs font-bold text-slate-700 leading-relaxed">
                  • {template}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

    </div>
  );
};

export default PsychologicalInsightView;
