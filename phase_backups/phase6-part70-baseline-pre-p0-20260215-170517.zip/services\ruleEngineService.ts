import {
  AlertSeverity,
  Category,
  CommandPriority,
  SafetyPlaybook,
  AutomatedAction,
} from '../types';

export interface DefenseAction {
  id: string;
  label: string;
  command: string;
  payload?: any;
  priority: CommandPriority;
}

const severityWeight = (severity: AlertSeverity): number => {
  switch (severity) {
    case AlertSeverity.CRITICAL:
      return 4;
    case AlertSeverity.HIGH:
      return 3;
    case AlertSeverity.MEDIUM:
      return 2;
    default:
      return 1;
  }
};

export const getDefenseActions = (
  category: Category,
  severity: AlertSeverity
): DefenseAction[] => {
  const weight = severityWeight(severity);
  const common: DefenseAction[] = [
    {
      id: 'notify',
      label: 'Notify Parent',
      command: 'notifyParent',
      priority: CommandPriority.MEDIUM,
    },
  ];

  if (category === Category.PREDATOR || category === Category.SEXUAL_EXPLOITATION) {
    return [
      {
        id: 'lock',
        label: 'Emergency Lock',
        command: 'lockDevice',
        payload: true,
        priority: CommandPriority.CRITICAL,
      },
      {
        id: 'blackout',
        label: 'Blackout Lock Screen',
        command: 'lockscreenBlackout',
        payload: {
          enabled: true,
          message: 'Device locked for safety. Please contact your parent.',
        },
        priority: CommandPriority.CRITICAL,
      },
      {
        id: 'siren',
        label: 'Deterrence Siren',
        command: 'playSiren',
        payload: true,
        priority: CommandPriority.HIGH,
      },
      {
        id: 'screenshot',
        label: 'Capture Evidence',
        command: 'takeScreenshot',
        payload: true,
        priority: CommandPriority.HIGH,
      },
      {
        id: 'walkie',
        label: 'Enable Walkie-Talkie',
        command: 'walkieTalkieEnable',
        payload: { enabled: true, source: 'mic' },
        priority: CommandPriority.HIGH,
      },
      ...common,
    ];
  }

  if (category === Category.BULLYING) {
    return [
      {
        id: 'screenshot',
        label: 'Capture Screen',
        command: 'takeScreenshot',
        payload: true,
        priority: CommandPriority.MEDIUM,
      },
      {
        id: 'lock_soft',
        label: 'Soft Lock',
        command: 'lockDevice',
        payload: weight >= 3,
        priority: weight >= 3 ? CommandPriority.HIGH : CommandPriority.MEDIUM,
      },
      ...common,
    ];
  }

  if (category === Category.SELF_HARM) {
    return [
      {
        id: 'lock',
        label: 'Safety Lock',
        command: 'lockDevice',
        payload: true,
        priority: CommandPriority.CRITICAL,
      },
      {
        id: 'blackout',
        label: 'Blackout Safety Screen',
        command: 'lockscreenBlackout',
        payload: {
          enabled: true,
          message: 'Safety mode is active. Please wait for parent guidance.',
        },
        priority: CommandPriority.CRITICAL,
      },
      {
        id: 'screenshot',
        label: 'Capture Context',
        command: 'takeScreenshot',
        payload: true,
        priority: CommandPriority.HIGH,
      },
      ...common,
    ];
  }

  return common;
};

const severityWeightFromEnum = (severity: AlertSeverity): number => severityWeight(severity);

const mapPlaybookAction = (action: AutomatedAction): DefenseAction | null => {
  if (!action.isEnabled) return null;

  switch (action.type) {
    case 'LOCK_DEVICE':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Lock Device',
        command: 'lockDevice',
        payload: true,
        priority: CommandPriority.CRITICAL,
      };
    case 'LOCKSCREEN_BLACKOUT':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Blackout Screen',
        command: 'lockscreenBlackout',
        payload: {
          enabled: true,
          message: 'Device locked by family protection protocol.',
        },
        priority: CommandPriority.CRITICAL,
      };
    case 'WALKIE_TALKIE_ENABLE':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Walkie-Talkie',
        command: 'walkieTalkieEnable',
        payload: { enabled: true, source: 'mic' },
        priority: CommandPriority.HIGH,
      };
    case 'LIVE_CAMERA_REQUEST':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Live Camera',
        command: 'startLiveStream',
        payload: { videoSource: 'camera_front', audioSource: 'mic', source: 'playbook' },
        priority: CommandPriority.HIGH,
      };
    case 'SCREENSHOT_CAPTURE':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Screenshot Capture',
        command: 'takeScreenshot',
        payload: true,
        priority: CommandPriority.HIGH,
      };
    case 'BLOCK_APP':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Block App',
        command: 'blockApp',
        payload: true,
        priority: CommandPriority.HIGH,
      };
    case 'SIREN':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Siren',
        command: 'playSiren',
        payload: true,
        priority: CommandPriority.HIGH,
      };
    case 'QUARANTINE_NET':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Cut Internet',
        command: 'cutInternet',
        payload: true,
        priority: CommandPriority.HIGH,
      };
    case 'DISABLE_HARDWARE':
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Disable Hardware',
        command: 'blockCameraAndMic',
        payload: true,
        priority: CommandPriority.HIGH,
      };
    case 'NOTIFY_PARENTS':
    default:
      return {
        id: `pb-${action.id}`,
        label: 'Playbook Notify Parent',
        command: 'notifyParent',
        payload: true,
        priority: CommandPriority.MEDIUM,
      };
  }
};

export const getPlaybookActions = (
  playbooks: SafetyPlaybook[],
  category: Category,
  severity: AlertSeverity
): DefenseAction[] => {
  const currentSeverityWeight = severityWeightFromEnum(severity);
  const eligible = playbooks.filter(
    (pb) =>
      pb.enabled &&
      pb.category === category &&
      severityWeightFromEnum(pb.minSeverity) <= currentSeverityWeight
  );

  return eligible.flatMap((pb) => pb.actions.map(mapPlaybookAction).filter(Boolean) as DefenseAction[]);
};

export const getDefenseActionsWithPlaybooks = (
  category: Category,
  severity: AlertSeverity,
  playbooks: SafetyPlaybook[] = []
): DefenseAction[] => {
  const base = getDefenseActions(category, severity);
  const playbookActions = getPlaybookActions(playbooks, category, severity);
  const unique = new Map<string, DefenseAction>();
  [...playbookActions, ...base].forEach((action) => {
    if (!unique.has(action.command)) unique.set(action.command, action);
  });
  return Array.from(unique.values()).sort((a, b) => {
    const rank = {
      [CommandPriority.CRITICAL]: 4,
      [CommandPriority.HIGH]: 3,
      [CommandPriority.MEDIUM]: 2,
      [CommandPriority.LOW]: 1,
    };
    return rank[b.priority] - rank[a.priority];
  });
};
