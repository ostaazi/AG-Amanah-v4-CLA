﻿# Detailed File-by-File Implementation Plan

## Execution Progress Log (Updated 2026-02-14)

- Completed: `step-up-security`
  - Backup: `phase_backups/step-up-security_20260214-181642.zip`
- Completed: `upgrade-simplified-files`
  - Backup: `phase_backups/upgrade-simplified-files_20260214-182102.zip`
- Completed: `hardening-rules-indexes`
  - Backup: `phase_backups/hardening-rules-indexes_20260214-182329.zip`
- Completed: `qa-regression-tests`
  - Backup: `phase_backups/qa-regression-tests_20260214-225316.zip`
- Completed: `workers-backlog-integration`
  - Backup: `phase_backups/workers-backlog-integration_20260214-230828.zip`
- Completed: `parent-ops-worker-binding`
  - Backups:
    - `phase_backups/parent-ops-worker-binding_20260214-232220.zip`
    - `phase_backups/parent-ops-stepup-guard_20260214-232347.zip`
- Completed: `exports-package-download`
  - Backup: `phase_backups/exports-package-download_20260214-232959.zip`
- Completed: `digital-balance-deep-actions`
  - Backup: `phase_backups/digital-balance-deep-actions_20260214-233939.zip`
- Completed: `deep-actions-qa-regression`
  - Backup: `phase_backups/deep-actions-qa-regression_20260214-234058.zip`
- Completed: `playbook-action-control`
  - Backup: `phase_backups/playbook-action-control_20260214-234218.zip`
- Completed: `parent-device-deep-commands`
  - Backup: `phase_backups/parent-device-deep-commands_20260214-234500.zip`
- Completed: `live-monitor-deep-control-hardening`
  - Backup: `phase_backups/live-monitor-deep-control-hardening_20260215-044453.zip`
- Completed: `proactive-defense-playbook-sync`
  - Backup: `phase_backups/proactive-defense-playbook-sync_20260215-044624.zip`
- Completed: `pulse-playbook-auto-step-sync`
  - Backup: `phase_backups/pulse-playbook-auto-step-sync_20260215-045008.zip`

- Completed: `phase5-part51-pulse-evidence-hardening`
  - Backup: `phase_backups/phase5-part51-pulse-evidence-hardening-20260215-060254.zip`
- Completed: `phase5-part52-playbook-permission-fallback`
  - Backup: `phase_backups/phase5-part52-playbook-permission-fallback-20260215-060553.zip`
- Completed: `phase5-part53-playbook-arabic-encoding-cleanup`
  - Backup: `phase_backups/phase5-part53-playbook-arabic-encoding-cleanup-20260215-060916.zip`

- Current focus: continue Phase 5 stabilization, then return to deep-feature recovery flow.

## 1) Ø§Ù„Ù‡Ø¯Ù
Ù‡Ø°Ù‡ Ø§Ù„Ø®Ø·Ø© ØªØªØ±Ø¬Ù… Ø§Ù„Ø±Ø¤ÙŠØ© Ø§Ù„Ø¹Ø§Ù…Ø© Ø¥Ù„Ù‰ ØªØ±ØªÙŠØ¨ ØªÙ†ÙÙŠØ°ÙŠ Ø¹Ù…Ù„ÙŠ ÙŠÙˆØ¶Ø­:
1. Ø§Ù„Ù…Ù„ÙØ§Øª Ø§Ù„ØªÙŠ Ø³Ù†Ø¹Ø¯Ù„Ù‡Ø§ Ø£Ùˆ Ù†Ù†Ø´Ø¦Ù‡Ø§.
2. Ø§Ù„ÙˆØ¸Ø§Ø¦Ù/Ø§Ù„Ù…Ù…ÙŠØ²Ø§Øª Ø§Ù„Ù…ØªØ£Ø«Ø±Ø© Ø¯Ø§Ø®Ù„ ÙƒÙ„ Ù…Ù„Ù.
3. Ù…Ø§ Ù‡Ùˆ Ø§Ù„ØªØ¹Ø¯ÙŠÙ„ Ø¨Ø§Ù„Ø¶Ø¨Ø·.
4. Ø³Ø¨Ø¨ Ø§Ù„ØªØ¹Ø¯ÙŠÙ„.
5. Ø§Ù„ØªØ±ØªÙŠØ¨ Ø§Ù„Ù…Ù†Ø·Ù‚ÙŠ Ø§Ù„ØµØ­ÙŠØ­ Ù„Ù„ØªÙ†ÙÙŠØ°.

---

## 2) Ù‚Ø±Ø§Ø± Ù…Ø¹Ù…Ø§Ø±ÙŠ Ù‚Ø¨Ù„ Ø§Ù„ØªÙ†ÙÙŠØ°
Ø§Ù„Ù†Ø³Ø®Ø© Ø§Ù„Ø­Ø§Ù„ÙŠØ© ØªØ¹Ù…Ù„ Ø¹Ù„Ù‰ `Vite + React SPA` ÙˆÙ„Ø§ ØªØ­ØªÙˆÙŠ Ø¨Ù†ÙŠØ© `Next.js app routes` ÙÙŠ Ø§Ù„Ø¬Ø°Ø± (`app/`, `lib/`, `prisma/` ØºÙŠØ± Ù…ÙˆØ¬ÙˆØ¯Ø©).
Ù„Ø°Ù„Ùƒ:
1. Ù†Ø³ØªØ¹ÙŠØ¯ Ù…Ù…ÙŠØ²Ø§Øª Ø§Ù„ÙˆØ§Ø¬Ù‡Ø© ÙˆØ§Ù„Ø®Ø¯Ù…Ø§Øª Ø§Ù„Ù‚Ø§Ø¨Ù„Ø© Ù„Ù„Ø¯Ù…Ø¬ Ù…Ø¨Ø§Ø´Ø±Ø© Ø¯Ø§Ø®Ù„ SPA.
2. Ø£ÙŠ Ù…Ù„ÙØ§Øª API Ù…Ù† Ø§Ù„Ù†Ø³Ø® Ø§Ù„Ù‚Ø¯ÙŠÙ…Ø© (`app/api/*`) ØªÙØ­ÙˆÙ‘ÙŽÙ„ Ø¥Ù„Ù‰:
- Ø¯ÙˆØ§Ù„ Service ÙÙŠ `services/*` (Ø§Ù„Ù…Ø±Ø­Ù„Ø© Ø§Ù„Ø­Ø§Ù„ÙŠØ©).
- Ø£Ùˆ Backlog Ù„Ø¨Ø§Ùƒ-Ø¥Ù†Ø¯ Ù…Ù†ÙØµÙ„ (Ù…Ø±Ø­Ù„Ø© Ù„Ø§Ø­Ù‚Ø©).
3. Ø§Ù„Ø³Ø¨Ø¨: Ù…Ù†Ø¹ ÙƒØ³Ø± Ø§Ù„Ø¨Ù†ÙŠØ© Ø§Ù„Ø­Ø§Ù„ÙŠØ© ÙˆØ¶Ù…Ø§Ù† ØªØ³Ù„ÙŠÙ… ØªØ¯Ø±ÙŠØ¬ÙŠ Ù‚Ø§Ø¨Ù„ Ù„Ù„Ø§Ø®ØªØ¨Ø§Ø±.

---

## 3) Ø§Ù„ØªØ±ØªÙŠØ¨ Ø§Ù„Ù…Ù†Ø·Ù‚ÙŠ Ø§Ù„Ø³Ù„ÙŠÙ… (Execution Order)

1. **Foundation Contract Layer**
- `types.ts`
- `translations.ts`
- `config/featureFlags.ts`
- `constants.tsx`

2. **Core Orchestration Layer**
- `App.tsx`
- `services/firestoreService.ts`
- `services/mockDataService.ts`
- `services/ruleEngineService.ts`

3. **Stabilization of Existing Critical Views**
- `components/PsychologicalInsightView.tsx`
- `components/LiveMonitorView.tsx`
- `components/ModesView.tsx`
- `components/EvidenceVaultView.tsx`
- `components/SettingsView.tsx`

4. **Recover Missing Security/Forensics Services**
- `services/forensicsService.ts` (new)
- `services/rbacService.ts` (new)
- `services/auditService.ts` (new)
- `services/backupService.ts` (new)

5. **Recover Missing Incident/Forensics UI (Wave UI-1)**
- `components/IncidentWarRoom.tsx` (new)
- `components/ChainOfCustodyView.tsx` (new)
- `components/FamilyIncidentResponseView.tsx` (new)
- `components/ExportBundleModal.tsx` (new)
- `components/SystemSecurityReportView.tsx` (new)
- `components/VisualBenchmarkView.tsx` (new)

6. **Recover Missing Defense/Playbook UI (Wave UI-2)**
- `components/SafetyPlaybookHub.tsx` (new)
- `components/SafetyProtocolStudio.tsx` (new)
- `components/PlatformSOCView.tsx` (new)
- `components/parent/DefenseRulesView.tsx` (new)
- `components/parent/DefensePolicyView.tsx` (new)
- `components/parent/GeoFenceManager.tsx` (new)

7. **Recover Parent Ops UI (Wave UI-3)**
- `components/parent/DeviceCommandsDashboard.tsx` (new)
- `components/parent/DeviceCommandControl.tsx` (new)
- `components/parent/CommandsStatusTable.tsx` (new)
- `components/parent/IncidentsTable.tsx` (new)
- `components/parent/IncidentDetailsTabs.tsx` (new)
- `components/parent/NotificationCenterView.tsx` (new)
- `components/parent/EvidenceVaultTable.tsx` (new)
- `components/parent/EvidenceList.tsx` (new)
- `components/parent/ExportsTable.tsx` (new)
- `components/parent/CreateExportButton.tsx` (new)
- `components/parent/HashVerifier.tsx` (new)
- `components/parent/CustodyTimeline.tsx` (new)
- `components/parent/ParentSidebar.tsx` (new)
- `components/parent/EvidenceVaultView.tsx` (new)
- `components/parent/SafetyPlaybookHub.tsx` (new)

8. **Step-Up / Sensitive Actions Layer**
- `components/stepup/StepUpModal.tsx` (new)
- `components/auth/StepUpGuard.tsx` (new)
- Ø±Ø¨Ø·Ù‡Ø§ Ø¯Ø§Ø®Ù„ `App.tsx` Ùˆ `components/SettingsView.tsx` Ùˆ `components/EvidenceVaultView.tsx`

9. **Upgrade Simplified Files**
- `services/MapView.tsx` (ØªØ±Ù‚ÙŠØ©/Ø¥Ø²Ø§Ù„Ø© deprecated stub)
- `components/ChildAppView.tsx` (Ø±ÙØ¹ Ù…Ù† Ù†Ø³Ø®Ø© Ù…Ø¨Ø³Ø·Ø© Ø¥Ù„Ù‰ flow Ø£Ø´Ù…Ù„)

10. **Background Workers and Backend Backlog**
- `workers/evidencePackageWorker.ts` (new, backlog integration)
- `workers/evidencePurgeWorker.ts` (new, backlog integration)
- Ù…Ù„ÙØ§Øª `app/api/*` ØªØ¨Ù‚Ù‰ Backlog Ø­ØªÙ‰ Ø§Ø¹ØªÙ…Ø§Ø¯ ÙˆØ§Ø¬Ù‡Ø© Ø¨Ø§Ùƒ-Ø¥Ù†Ø¯.

11. **QA + Hardening + Release**
- `firestore.rules`
- `firestore.indexes.json`
- `tests/*`
- Build + Regression + smoke

---

## 4) ØªÙØ§ØµÙŠÙ„ Ø§Ù„ØªØ¹Ø¯ÙŠÙ„Ø§Øª Ù…Ù„ÙÙ‹Ø§ Ø¨Ù…Ù„Ù (What + Why)

## A) Ù…Ù„ÙØ§Øª Ù…ÙˆØ¬ÙˆØ¯Ø© ÙˆØ³ÙŠØªÙ… ØªØ¹Ø¯ÙŠÙ„Ù‡Ø§

| Ø§Ù„Ù…Ù„Ù | Ø§Ù„ÙˆØ¸Ø§Ø¦Ù/Ø§Ù„Ù…Ù…ÙŠØ²Ø§Øª Ø§Ù„Ù…ØªØ£Ø«Ø±Ø© | Ø§Ù„ØªØ¹Ø¯ÙŠÙ„ Ø§Ù„Ù…Ø·Ù„ÙˆØ¨ | Ø³Ø¨Ø¨ Ø§Ù„ØªØ¹Ø¯ÙŠÙ„ |
|---|---|---|---|
| `types.ts` | Ù†Ù…Ø§Ø°Ø¬ Ø§Ù„Ø­ÙˆØ§Ø¯Ø«ØŒ Ø³Ù„Ø³Ù„Ø© Ø§Ù„Ø­ÙŠØ§Ø²Ø©ØŒ playbooksØŒ Ø§Ù„Ø£ÙˆØ§Ù…Ø± | Ø¥Ø¶Ø§ÙØ©/ØªÙˆØ­ÙŠØ¯ Ø§Ù„Ø£Ù†ÙˆØ§Ø¹ Ø§Ù„Ù†Ø§Ù‚ØµØ©: `SafetyPlaybook`, `EvidenceCustody`, `CommandAudit`, `IncidentExportMeta` | Ù…Ù†Ø¹ Ø§Ù„ØªØ¶Ø§Ø±Ø¨ Ø¨ÙŠÙ† Ù…Ù„ÙØ§Øª Ù…Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ¶Ù…Ø§Ù† Type Safety |
| `translations.ts` | Ù…ÙØ§ØªÙŠØ­ Ø§Ù„ÙˆØ§Ø¬Ù‡Ø© Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© | Ø¥Ø¶Ø§ÙØ© Ù…ÙØ§ØªÙŠØ­ ØªØ±Ø¬Ù…Ø© Ù„Ù„Ù…ÙŠØ²Ø§Øª Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø© (Step-Up, War Room, Custody, Playbooks, Ops Console) | ØªÙˆØ­ÙŠØ¯ Ø§Ù„Ù„ØºØ© ÙˆÙ…Ù†Ø¹ hardcoded strings |
| `config/featureFlags.ts` | ØªÙ…ÙƒÙŠÙ† ØªØ¯Ø±ÙŠØ¬ÙŠ Ù„Ù„Ù…ÙŠØ²Ø§Øª | Ø¥Ø¶Ø§ÙØ© flags Ø¬Ø¯ÙŠØ¯Ø© Ù…Ø«Ù„: `stepUp`, `incidentWarRoom`, `playbookHub`, `parentOpsConsole`, `forensics` | ØªÙØ¹ÙŠÙ„ Ø¢Ù…Ù† ØªØ¯Ø±ÙŠØ¬ÙŠ Ø¯ÙˆÙ† ÙƒØ³Ø± Ø§Ù„Ù†Ø³Ø®Ø© Ø§Ù„Ø­Ø§Ù„ÙŠØ© |
| `constants.tsx` | Ø¹Ù†Ø§ØµØ± Ø§Ù„ØªÙ†Ù‚Ù„/Ø§Ù„Ø£ÙŠÙ‚ÙˆÙ†Ø§Øª/Ø§Ù„Ø®Ø±Ø§Ø¦Ø· | ØªÙˆØ³ÙŠØ¹ ØªØ¹Ø±ÙŠÙØ§Øª Ø§Ù„ÙˆØ§Ø¬Ù‡Ø§Øª ÙˆØ§Ù„Ù‚ÙˆØ§Ø¦Ù… Ù„ØªØ¶Ù… Ø§Ù„Ø´Ø§Ø´Ø§Øª Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ±Ø¨Ø· Ø£ÙŠÙ‚ÙˆÙ†Ø§ØªÙ‡Ø§ | Ø¥Ø¯Ù…Ø§Ø¬ Ø§Ù„Ù…ÙŠØ²Ø§Øª ÙÙŠ UX Ø¨Ø´ÙƒÙ„ Ù…Ù†Ø¸Ù… |
| `App.tsx` | Orchestration + navigation + handlers | Ø±Ø¨Ø· Ø§Ù„Ø´Ø§Ø´Ø§Øª Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø© Ø¹Ø¨Ø± navigation Ø¯Ø§Ø®Ù„ÙŠ ÙˆØ±Ø¨Ø· Ø§Ù„Ù€ feature flagsØŒ ÙˆØ±Ø¨Ø· handlers Ø¨Ø§Ù„Ø£Ù‚Ø³Ø§Ù… Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© | Ø¬Ø¹Ù„ Ø§Ù„Ù…ÙŠØ²Ø§Øª Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© Ù‚Ø§Ø¨Ù„Ø© Ù„Ù„ÙˆØµÙˆÙ„ Ø¨Ø¯ÙˆÙ† ÙƒØ³Ø± Ø§Ù„ØªØ¯ÙÙ‚ Ø§Ù„Ø­Ø§Ù„ÙŠ |
| `services/firestoreService.ts` | CRUD Ù„Ù„Ù…ÙŠØ²Ø§Øª Ø§Ù„Ø£Ù…Ù†ÙŠØ© | Ø¥Ø¶Ø§ÙØ© ÙˆØ¸Ø§Ø¦Ù Ù„Ø¬Ù„Ø¨/Ø­ÙØ¸ playbooksØŒ Ø£Ø­Ø¯Ø§Ø« custodyØŒ Ø³Ø¬Ù„Ø§Øª auditØŒ Ø£ÙˆØ§Ù…Ø± Ø§Ù„Ø£Ø¬Ù‡Ø²Ø© Ø§Ù„Ù…ÙˆØ³Ø¹Ø© | ØªÙˆØ­ÙŠØ¯ Ø·Ø¨Ù‚Ø© Ø§Ù„Ø¨ÙŠØ§Ù†Ø§Øª Ø¨Ø¯Ù„ Ø§Ù„ØªØ´ØªØª Ø¯Ø§Ø®Ù„ UI |
| `services/mockDataService.ts` | Ø¨ÙŠØ§Ù†Ø§Øª Ø§Ù„Ø§Ø®ØªØ¨Ø§Ø± | ØªÙˆØ³ÙŠØ¹ Ù†Ø·Ø§Ù‚ Ø­Ù‚Ù†/Ø­Ø°Ù Ø§Ù„Ø¨ÙŠØ§Ù†Ø§Øª Ø§Ù„ÙˆÙ‡Ù…ÙŠØ© Ù„ØªØ´Ù…Ù„ Ø§Ù„ÙˆØ­Ø¯Ø§Øª Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© (incidents, playbooks, custody, commands) | Ø¯Ø¹Ù… QA Ø³Ø±ÙŠØ¹ Ø¨Ø¯ÙˆÙ† Ø§Ù†ØªØ¸Ø§Ø± Ø¨ÙŠØ§Ù†Ø§Øª Ø­Ù‚ÙŠÙ‚ÙŠØ© |
| `services/ruleEngineService.ts` | Ø§Ù„ØªÙ†ÙÙŠØ° Ø§Ù„ØªÙ„Ù‚Ø§Ø¦ÙŠ | Ø±Ø¨Ø· Ø§Ù„Ù‚ÙˆØ§Ø¹Ø¯ Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø© (Defense Rules/Policy) Ù…Ø¹ Auto Execution Ø§Ù„Ø­Ø§Ù„ÙŠ | Ø¯Ù…Ø¬ Ø§Ù„Ø°ÙƒØ§Ø¡ Ø§Ù„ØªØ´Ø®ÙŠØµÙŠ Ù…Ø¹ Ø§Ù„Ø§Ø³ØªØ¬Ø§Ø¨Ø© Ø§Ù„Ø¢Ù„ÙŠØ© |
| `components/PsychologicalInsightView.tsx` | `buildSuggestedPlan`, `runAutoExecutionPlan`, `saveExecutionTimelineToVault` | ØªÙˆØ³ÙŠØ¹ Ø§Ù„Ù…Ø®Ø±Ø¬Ø§Øª Ù„ØªØºØ°ÙŠØ© playbooks ÙˆØ§Ù„Ø¯ÙØ§Ø¹ Ø§Ù„Ø§Ø³ØªØ¨Ø§Ù‚ÙŠ + ØªØ­Ø³ÙŠÙ† Ø§Ù„Ø³Ø¬Ù„ Ø§Ù„Ø²Ù…Ù†ÙŠ ÙˆØ§Ù„ØªÙˆØ§ÙÙ‚ Ù…Ø¹ custody/audit | Ø¬Ø¹Ù„ Ø§Ù„Ù†Ø¨Ø¶ Ø§Ù„Ù†ÙØ³ÙŠ Ø¨ÙˆØ§Ø¨Ø© Ø§Ù„Ù‚Ø±Ø§Ø± Ø§Ù„Ø¹Ù„ÙŠØ§ Ù„Ø¨Ø§Ù‚ÙŠ Ø§Ù„Ø£Ù†Ø¸Ù…Ø© |
| `components/LiveMonitorView.tsx` | `startStream`, `changeVideoSource`, `changeAudioSource`, `startPushToTalk`, `toggleEmergencyLock` | Ø±Ø¨Ø· Ø£Ù‚ÙˆÙ‰ Ù…Ø¹ Ø£ÙˆØ§Ù…Ø± Ø§Ù„Ø£Ù…Ù† (siren/lockdown/stream source) ÙˆØªÙˆØ­ÙŠØ¯ ØªØ³Ø¬ÙŠÙ„ Ø§Ù„Ø£Ø¯Ù„Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø¹Ù…Ù‚ Ù…ÙŠØ²Ø© Ø§Ù„Ø¨Ø« Ø§Ù„Ù…Ø¨Ø§Ø´Ø± ÙˆØ§Ù„ØªØ­ÙƒÙ… Ø§Ù„ÙÙˆØ±ÙŠ |
| `components/ModesView.tsx` | `handleSaveMode` + advanced mode fields | ØªÙˆØ³ÙŠØ¹ Ø­Ù‚ÙˆÙ„ Ø§Ù„ÙˆØ¶Ø¹ Ø§Ù„Ø°ÙƒÙŠ (Ù…ØµØ§Ø¯Ø± Ø¨Ø«ØŒ Ø­Ø¸Ø±ØŒ Ø¥Ø¬Ø±Ø§Ø¡Ø§Øª ÙÙˆØ±ÙŠØ©) ÙˆØ±Ø¨Ø·Ù‡Ø§ Ø¨Ø§Ù„Ù€ playbooks | ØªÙˆØ­ÙŠØ¯ ØªØ¹Ø±ÙŠÙ Ø§Ù„ÙˆØ¶Ø¹ Ø¨ÙŠÙ† Ø§Ù„Ù†Ø¨Ø¶ Ø§Ù„Ù†ÙØ³ÙŠ ÙˆØ§Ù„ØªÙ†ÙÙŠØ° |
| `components/EvidenceVaultView.tsx` | `handleExport`, `handleSave`, `handleDelete`, filters | ØªÙˆØ³ÙŠØ¹ Ø§Ù„Ø¹Ø±Ø¶ Ù„ÙŠØ´Ù…Ù„ custody metadata Ùˆincident linkage ÙˆØ¹Ù…Ù„ÙŠØ§Øª Ø§Ù„ØªØ­Ù‚Ù‚ | ØªØ±Ø³ÙŠØ® Ø§Ù„Ø£Ø¯Ù„Ø© ÙƒØ³Ø¬Ù„ Ù…ÙˆØ«ÙˆÙ‚ Ù‚Ø§Ø¨Ù„ Ù„Ù„ØªØ¯Ù‚ÙŠÙ‚ |
| `components/SettingsView.tsx` | `handleInjectMockData`, `handleClearMockData`, child/device editing | Ø¯Ø¹Ù… Ù†Ø·Ø§Ù‚Ø§Øª mock Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© + Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª flags Ø§Ù„Ø­Ø³Ø§Ø³Ø© + Ø±Ø¨Ø· Step-Up Ù„Ù„Ø¹Ù…Ù„ÙŠØ§Øª Ø§Ù„Ø­Ø±Ø¬Ø© | Ù…Ù†Ø¹ ØªØºÙŠÙŠØ±Ø§Øª Ø­Ø³Ø§Ø³Ø© Ø¨Ø¯ÙˆÙ† ØªØ­Ù‚Ù‚ Ø¥Ø¶Ø§ÙÙŠ |
| `components/DevicesView.tsx` | Ø£ÙˆØ§Ù…Ø± Ø§Ù„Ø¬Ù‡Ø§Ø² ÙˆØ­Ø§Ù„Ø© Ø§Ù„Ø±Ø¨Ø· | ØªÙˆØ³ÙŠØ¹ ÙˆØ§Ø¬Ù‡Ø© Ø§Ù„Ø£ÙˆØ§Ù…Ø± ÙˆØ±Ø¨Ø·Ù‡Ø§ Ø¨Ø®Ø¯Ù…Ø§Øª audit/rbac Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© | Ø²ÙŠØ§Ø¯Ø© Ø§Ù„Ø§Ø¹ØªÙ…Ø§Ø¯ÙŠØ© Ø§Ù„ØªØ´ØºÙŠÙ„ÙŠØ© |
| `components/IncidentsCenterView.tsx` | Ø¥Ø¯Ø§Ø±Ø© Ø§Ù„Ø­ÙˆØ§Ø¯Ø« | Ø±Ø¨Ø·Ù‡ Ù…Ø¹ War Room ÙˆCustody Timeline ÙˆØªØµÙÙŠØ© Ø­Ø³Ø¨ Ø§Ù„Ø´Ø¯Ø©/Ø§Ù„Ø­Ø§Ù„Ø© | ØªØ­ÙˆÙŠÙ„ Ù‚Ø§Ø¦Ù…Ø© Ø§Ù„Ø­ÙˆØ§Ø¯Ø« Ø¥Ù„Ù‰ Ù…Ø±ÙƒØ² Ø¹Ù…Ù„ÙŠØ§Øª ÙØ¹Ù„ÙŠ |
| `components/MapView.tsx` | ØªØªØ¨Ø¹ Ø§Ù„Ù…ÙˆÙ‚Ø¹ + geo intelligence | Ø§Ù„ØªØ£ÙƒØ¯ Ù…Ù† ØªÙˆØ§ÙÙ‚Ù‡ Ù…Ø¹ Ù†Ø³Ø®Ø© Ø§Ù„Ø®Ø¯Ù…Ø§Øª/Ø§Ù„Ø®Ø±Ø§Ø¦Ø· Ø§Ù„Ø¬Ø¯ÙŠØ¯Ø© | Ø§Ø³ØªÙ‚Ø±Ø§Ø± Ù…ÙŠØ²Ø© ØªØªØ¨Ø¹ Ø§Ù„Ù…ÙˆÙ‚Ø¹ Ù…Ø¹ Ø§Ø³ØªØ±Ø¬Ø§Ø¹ Ø§Ù„Ø¯ÙØ§Ø¹ Ø§Ù„Ø¬ØºØ±Ø§ÙÙŠ |
| `firestore.rules` | ØµÙ„Ø§Ø­ÙŠØ§Øª Ø§Ù„ÙˆØµÙˆÙ„ | Ø¥Ø¶Ø§ÙØ© Ù‚ÙˆØ§Ø¹Ø¯ Ù„ÙˆØ­Ø¯Ø§Øª Ø¬Ø¯ÙŠØ¯Ø©: custody, playbooks, audits, exports | Ø£Ù…Ø§Ù† Ø§Ù„Ø¨ÙŠØ§Ù†Ø§Øª ÙˆÙ…Ù†Ø¹ permission regressions |
| `firestore.indexes.json` | Ø§Ø³ØªØ¹Ù„Ø§Ù…Ø§Øª Ù…Ø±ÙƒØ¨Ø© | Ø¥Ø¶Ø§ÙØ© Ø§Ù„ÙÙ‡Ø§Ø±Ø³ Ø§Ù„Ù…Ø·Ù„ÙˆØ¨Ø© Ù„Ø§Ø³ØªØ¹Ù„Ø§Ù…Ø§Øª incidents/custody/exports | Ù…Ù†Ø¹ Ø£Ø®Ø·Ø§Ø¡ index ÙÙŠ ÙˆÙ‚Øª Ø§Ù„ØªØ´ØºÙŠÙ„ |

## B) Ù…Ù„ÙØ§Øª Ø¬Ø¯ÙŠØ¯Ø© Ø³ÙŠØªÙ… Ø¥Ù†Ø´Ø§Ø¤Ù‡Ø§/Ø§Ø³ØªØ¹Ø§Ø¯ØªÙ‡Ø§

| Ø§Ù„Ù…Ù„Ù Ø§Ù„Ø¬Ø¯ÙŠØ¯ | Ø§Ù„Ù…ÙŠØ²Ø© | Ù…Ø§Ø°Ø§ Ø³Ù†ÙØ¹Ù„ | Ø³Ø¨Ø¨ Ø§Ù„Ø¥Ø¶Ø§ÙØ© |
|---|---|---|---|
| `services/forensicsService.ts` | ØªØ­Ù‚Ù‚ integrity ÙˆØ³Ù„Ø³Ù„Ø© Ø§Ù„Ø­ÙŠØ§Ø²Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ¸Ø§Ø¦Ù Ø§Ù„ØªØ­Ù‚Ù‚ ÙˆØ§Ù„Ø±Ø¨Ø· Ù…Ø¹ Evidence Vault | ØªÙˆØ«ÙŠÙ‚ Ø¬Ù†Ø§Ø¦ÙŠ Ù…ÙˆØ«ÙˆÙ‚ |
| `services/rbacService.ts` | Ø§Ù„ØªØ­ÙƒÙ… Ø¨Ø§Ù„ØµÙ„Ø§Ø­ÙŠØ§Øª | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø·Ø¨Ù‚Ø© Role/Permission checks | Ø¹Ø²Ù„ Ø§Ù„ØµÙ„Ø§Ø­ÙŠØ§Øª Ø­Ø³Ø¨ Ø§Ù„Ø¯ÙˆØ± |
| `services/auditService.ts` | Ø³Ø¬Ù„Ø§Øª ØªØ¯Ù‚ÙŠÙ‚ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© write/read logs Ù„Ù„Ø¹Ù…Ù„ÙŠØ§Øª Ø§Ù„Ø­Ø³Ø§Ø³Ø© | ØªØªØ¨Ø¹ ÙˆÙ…Ø³Ø§Ø¡Ù„Ø© |
| `services/backupService.ts` | Ø¯Ø¹Ù… Ø§Ù„Ù†Ø³Ø® Ø§Ù„Ø§Ø­ØªÙŠØ§Ø·ÙŠ/Ø§Ø³ØªØ±Ø¬Ø§Ø¹ Ø§Ù„Ø­Ø§Ù„Ø§Øª | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ¸Ø§Ø¦Ù Ø§Ù„Ù†Ø³Ø® Ù„Ù„Ø­Ø§Ù„Ø§Øª Ø§Ù„Ø­Ø±Ø¬Ø© ÙˆØ§Ù„Ø¨ÙŠØ§Ù†Ø§Øª | ØªØ­Ø³ÙŠÙ† Ø§Ù„Ø§Ø³ØªÙ…Ø±Ø§Ø±ÙŠØ© |
| `components/IncidentWarRoom.tsx` | Ø¥Ø¯Ø§Ø±Ø© Ø­Ø§Ø¯Ø« Ù…Ø±ÙƒØ²ÙŠ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„Ø´Ø§Ø´Ø© ÙˆØ±Ø¨Ø·Ù‡Ø§ Ø¨Ø§Ù„Ø­ÙˆØ§Ø¯Ø« Ø§Ù„Ø­Ø§Ù„ÙŠØ© | Ø§Ø³ØªØ¬Ø§Ø¨Ø© Ø£Ø³Ø±Ø¹ ÙˆØ¯Ù‚ÙŠÙ‚Ø© |
| `components/ChainOfCustodyView.tsx` | Ø¹Ø±Ø¶ Ø³Ù„Ø³Ù„Ø© Ø§Ù„Ø­ÙŠØ§Ø²Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© timeline integrity | ØªÙˆØ«ÙŠÙ‚ Ø§Ù„Ø£Ø¯Ù„Ø© Ù‚Ø§Ù†ÙˆÙ†ÙŠÙ‹Ø§ |
| `components/FamilyIncidentResponseView.tsx` | ØªÙ†Ø³ÙŠÙ‚ Ø§Ø³ØªØ¬Ø§Ø¨Ø© Ø§Ù„Ø£Ø³Ø±Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ§Ø¬Ù‡Ø© Ø§Ù„ØªØ¯Ø®Ù„ Ø§Ù„Ø£Ø³Ø±ÙŠ | ØªØ­Ø³ÙŠÙ† Ø¢Ù„ÙŠØ© Ø§Ù„ØªØ¯Ø®Ù„ |
| `components/ExportBundleModal.tsx` | ØªØµØ¯ÙŠØ± Ø­Ø²Ù…Ø© Ø§Ù„Ø£Ø¯Ù„Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© modal Ø§Ù„ØªØµØ¯ÙŠØ± ÙˆØ§Ù„ØªØ­Ù‚Ù‚ | Ù…Ø´Ø§Ø±ÙƒØ© Ø£Ø¯Ù„Ø© Ù…Ù†Ø¸Ù…Ø© |
| `components/SystemSecurityReportView.tsx` | ØªÙ‚Ø§Ø±ÙŠØ± Ø£Ù…Ù† Ø§Ù„Ù†Ø¸Ø§Ù… | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ØµÙØ­Ø© Ø§Ù„ØªÙ‚Ø±ÙŠØ± ÙˆØ±Ø¨Ø·Ù‡Ø§ Ø¨Ø§Ù„Ù…Ø¤Ø´Ø±Ø§Øª | Ø±Ø¤ÙŠØ© Ø£Ù…Ù†ÙŠØ© Ø¹Ù„ÙŠØ§ |
| `components/VisualBenchmarkView.tsx` | Ù‚ÙŠØ§Ø³ Ø§Ù„Ø£Ø¯Ø§Ø¡ Ø§Ù„Ù…Ø±Ø¦ÙŠ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„Ù‚ÙŠØ§Ø³Ø§Øª ÙˆØ§Ù„ØªØ­Ø³ÙŠÙ†Ø§Øª | ØªØ´Ø®ÙŠØµ Ø¬ÙˆØ¯Ø© Ø§Ù„Ø±ØµØ¯ |
| `components/SafetyPlaybookHub.tsx` | Ø¥Ø¯Ø§Ø±Ø© playbooks | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ§Ø¬Ù‡Ø© playbooks Ø§Ù„Ø¹Ø§Ù…Ø© | Ù‚Ø±Ø§Ø± Ø£Ù…Ù†ÙŠ Ù‚Ø§Ø¨Ù„ Ù„Ù„ØªØ®ØµÙŠØµ |
| `components/SafetyProtocolStudio.tsx` | ØªØµÙ…ÙŠÙ… Ø§Ù„Ø¨Ø±ÙˆØªÙˆÙƒÙˆÙ„Ø§Øª | Ø§Ø³ØªØ¹Ø§Ø¯Ø© studio Ù„ØªÙƒÙˆÙŠÙ† Ø§Ù„ØªØ¯Ø®Ù„Ø§Øª | Ù…Ø±ÙˆÙ†Ø© Ø£Ø¹Ù„Ù‰ ÙÙŠ Ø§Ù„Ø³ÙŠØ§Ø³Ø§Øª |
| `components/PlatformSOCView.tsx` | Ù„ÙˆØ­Ø© SOC | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ù…Ø±Ø§Ù‚Ø¨Ø© Ø§Ù„ØªÙ‡Ø¯ÙŠØ¯Ø§Øª Ø§Ù„Ø¹Ø§Ù…Ø© | Ù…Ø±Ø§Ù‚Ø¨Ø© ØªØ´ØºÙŠÙ„ÙŠØ© Ø´Ø§Ù…Ù„Ø© |
| `components/DeveloperResolutionHub.tsx` | Ø¯Ø¹Ù… Ø§Ù„ØªØ·ÙˆÙŠØ± ÙˆØ§Ù„ØªØ­Ù„ÙŠÙ„ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø´Ø§Ø´Ø© Ø§Ù„ØªØ´Ø®ÙŠØµ Ø§Ù„Ø¯Ø§Ø®Ù„ÙŠ | ØªØ³Ø±ÙŠØ¹ Ø­Ù„ Ø§Ù„Ø£Ø¹Ø·Ø§Ù„ |
| `components/stepup/StepUpModal.tsx` | ØªØ­Ù‚Ù‚ Ø¥Ø¶Ø§ÙÙŠ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ§Ø¬Ù‡Ø© Ø§Ù„Ù…ØµØ§Ø¯Ù‚Ø© Ø§Ù„Ø­Ø³Ø§Ø³Ø© | Ø£Ù…Ø§Ù† Ø§Ù„Ø¹Ù…Ù„ÙŠØ§Øª Ø§Ù„Ø­Ø±Ø¬Ø© |
| `components/auth/StepUpGuard.tsx` | Ø­Ù…Ø§ÙŠØ© Ø§Ù„Ø¯Ø®ÙˆÙ„ Ù„Ù„Ø¹Ù…Ù„ÙŠØ§Øª | Ø§Ø³ØªØ¹Ø§Ø¯Ø© guard Ù‚Ø§Ø¨Ù„ Ù„Ø¥Ø¹Ø§Ø¯Ø© Ø§Ù„Ø§Ø³ØªØ®Ø¯Ø§Ù… | ØªÙ‚Ù„ÙŠÙ„ Ù…Ø®Ø§Ø·Ø± Ø¥Ø³Ø§Ø¡Ø© Ø§Ù„Ø§Ø³ØªØ®Ø¯Ø§Ù… |
| `components/parent/DeviceCommandsDashboard.tsx` | Ù„ÙˆØ­Ø© Ø£ÙˆØ§Ù…Ø± Ø§Ù„Ø£Ø¬Ù‡Ø²Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© dashboard Ø§Ù„Ø£ÙˆØ§Ù…Ø± | Ø¥Ø¯Ø§Ø±Ø© Ù…Ø±ÙƒØ²ÙŠØ© Ù„Ù„Ø£Ø¬Ù‡Ø²Ø© |
| `components/parent/DeviceCommandControl.tsx` | Ø§Ù„ØªØ­ÙƒÙ… Ø§Ù„Ù…Ø¨Ø§Ø´Ø± | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø£Ø¯ÙˆØ§Øª command dispatch | ØªØ´ØºÙŠÙ„ Ø£Ø³Ø±Ø¹ Ù„Ù„Ø£ÙˆØ§Ù…Ø± |
| `components/parent/CommandsStatusTable.tsx` | ØªØªØ¨Ø¹ Ø§Ù„Ø£ÙˆØ§Ù…Ø± | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø¹Ø±Ø¶ Ø§Ù„Ø­Ø§Ù„Ø§Øª ÙˆØ§Ù„ØªÙ‚Ø¯Ù… | Ø´ÙØ§ÙÙŠØ© ØªÙ†ÙÙŠØ°ÙŠØ© |
| `components/parent/IncidentsTable.tsx` | Ø¬Ø¯ÙˆÙ„ Ø§Ù„Ø­ÙˆØ§Ø¯Ø« | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø¹Ø±Ø¶ Ø´Ø§Ù…Ù„ Ù„Ù„Ø­ÙˆØ§Ø¯Ø« | ÙÙ„ØªØ±Ø© ÙˆØªØ­Ù„ÙŠÙ„ Ø£ÙØ¶Ù„ |
| `components/parent/IncidentDetailsTabs.tsx` | ØªÙØ§ØµÙŠÙ„ Ø­Ø§Ø¯Ø« | Ø§Ø³ØªØ¹Ø§Ø¯Ø© tabs Ø´Ø§Ù…Ù„Ø© | ØªÙ‚Ù„ÙŠÙ„ ØªØ¨Ø¯ÙŠÙ„ Ø§Ù„Ø´Ø§Ø´Ø§Øª |
| `components/parent/NotificationCenterView.tsx` | Ù…Ø±ÙƒØ² Ø§Ù„ØªÙ†Ø¨ÙŠÙ‡Ø§Øª | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ù…Ø±ÙƒØ² Ø§Ù„Ø¥Ø´Ø¹Ø§Ø±Ø§Øª Ø§Ù„Ù…ÙˆØ³Ø¹ | ØªØ­Ø³ÙŠÙ† Ø§Ù„Ø§Ø³ØªØ¬Ø§Ø¨Ø© |
| `components/parent/EvidenceVaultTable.tsx` | Ø¬Ø¯Ø§ÙˆÙ„ Ø§Ù„Ø£Ø¯Ù„Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© table ØªÙØµÙŠÙ„ÙŠ | Ø¨Ø­Ø« ÙˆØªØµÙÙŠØ© Ø£Ø¯Ù‚ |
| `components/parent/EvidenceList.tsx` | Ù‚Ø§Ø¦Ù…Ø© Ø§Ù„Ø£Ø¯Ù„Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© list Ù…Ø®ØµØµ | ÙˆØ§Ø¬Ù‡Ø© Ø£Ø³Ø±Ø¹ Ù„Ù„Ù…Ø±Ø§Ø¬Ø¹Ø© |
| `components/parent/ExportsTable.tsx` | Ø³Ø¬Ù„Ø§Øª Ø§Ù„ØªØµØ¯ÙŠØ± | Ø§Ø³ØªØ¹Ø§Ø¯Ø© history Ù„Ù„ØªØµØ¯ÙŠØ± | ØªØªØ¨Ø¹ Ø§Ù„Ø§Ø³ØªÙ‡Ù„Ø§Ùƒ ÙˆØ§Ù„ØªØ­Ù‚Ù‚ |
| `components/parent/CreateExportButton.tsx` | Ø¥Ù†Ø´Ø§Ø¡ ØªØµØ¯ÙŠØ± | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø²Ø± Ùˆflow Ù…Ø³ØªÙ‚Ù„ | ØªØ¨Ø³ÙŠØ· Ø¥Ø¬Ø±Ø§Ø¡ Ø§Ù„ØªØµØ¯ÙŠØ± |
| `components/parent/HashVerifier.tsx` | ØªØ­Ù‚Ù‚ hash | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ§Ø¬Ù‡Ø© Ø§Ù„ØªØ­Ù‚Ù‚ | Ù…ØµØ¯Ø§Ù‚ÙŠØ© Ø§Ù„Ø¯Ù„ÙŠÙ„ |
| `components/parent/CustodyTimeline.tsx` | timeline custody | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø¹Ø±Ø¶ Ø²Ù…Ù†ÙŠ Ù…ØªÙƒØ§Ù…Ù„ | Ù…ØªØ§Ø¨Ø¹Ø© Ø§Ù„Ø³Ù„Ø³Ù„Ø© Ø¨Ø³Ù‡ÙˆÙ„Ø© |
| `components/parent/GeoFenceManager.tsx` | Ø¥Ø¯Ø§Ø±Ø© Ø§Ù„Ø³ÙŠØ§Ø¬ Ø§Ù„Ø¬ØºØ±Ø§ÙÙŠ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª geofence | Ø­Ù…Ø§ÙŠØ© Ù…ÙƒØ§Ù†ÙŠØ© Ø£Ø¹Ù…Ù‚ |
| `components/parent/DefenseRulesView.tsx` | Ù‚ÙˆØ§Ø¹Ø¯ Ø§Ù„Ø¯ÙØ§Ø¹ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø¥Ø¯Ø§Ø±Ø© rule sets | Ø£ØªÙ…ØªØ© Ø£Ø¯Ù‚ Ù„Ù„Ø±Ø¯ÙˆØ¯ |
| `components/parent/DefensePolicyView.tsx` | Ø³ÙŠØ§Ø³Ø§Øª Ø§Ù„Ø¯ÙØ§Ø¹ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© policy control | ØªÙˆØ­ÙŠØ¯ ØªÙ†ÙÙŠØ° Ø§Ù„Ø¥Ø¬Ø±Ø§Ø¡Ø§Øª |
| `components/parent/ParentSidebar.tsx` | ØªÙ†Ù‚Ù„ parent console | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„Ø´Ø±ÙŠØ· Ø§Ù„Ø¬Ø§Ù†Ø¨ÙŠ | ØªØ¬Ø±Ø¨Ø© ØªØ´ØºÙŠÙ„ÙŠØ© Ù…ØªÙ…Ø§Ø³ÙƒØ© |
| `components/parent/EvidenceVaultView.tsx` | Ø¹Ø±Ø¶ Ø£Ø¯Ù„Ø© Ù…Ø®ØµØµ Ù„Ù„ÙˆØ§Ù„Ø¯ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ù†Ø³Ø®Ø© Ù…ÙˆØ¬Ù‡Ø© Ù„Ù„Ø¹Ù…Ù„ÙŠØ§Øª | Ø³ÙŠØ± Ø¹Ù…Ù„ Ø£Ø³Ø±Ø¹ |
| `components/parent/SafetyPlaybookHub.tsx` | playbooks Ù„Ù„ÙˆØ§Ù„Ø¯ | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ØªØ®ØµÙŠØµ playbooks Ù„ÙƒÙ„ Ø¹Ø§Ø¦Ù„Ø© | Ù…ÙˆØ§Ø¡Ù…Ø© Ø§Ù„Ø§Ø³ØªØ¬Ø§Ø¨Ø© Ø­Ø³Ø¨ Ø§Ù„Ø­Ø§Ù„Ø© |
| `components/CommandCenter.tsx` | Ù…Ø±ÙƒØ² Ù‚ÙŠØ§Ø¯Ø© Ø¹Ø§Ù… | Ø§Ø³ØªØ¹Ø§Ø¯Ø© ÙˆØ§Ø¬Ù‡Ø© Ù‚ÙŠØ§Ø¯Ø© Ù…ÙˆØ­Ø¯Ø© | Ù†Ù‚Ø·Ø© ØªØ­ÙƒÙ… ÙˆØ§Ø­Ø¯Ø© |

## C) Ù…Ù„ÙØ§Øª Ù…Ø¨Ø³Ø·Ø© ØªØ­ØªØ§Ø¬ ØªØ±Ù‚ÙŠØ©

| Ø§Ù„Ù…Ù„Ù | Ø§Ù„ÙˆØ¶Ø¹ Ø§Ù„Ø­Ø§Ù„ÙŠ | Ø§Ù„ØªØ±Ù‚ÙŠØ© Ø§Ù„Ù…Ø·Ù„ÙˆØ¨Ø© | Ø§Ù„Ø³Ø¨Ø¨ |
|---|---|---|---|
| `services/MapView.tsx` | Deprecated stub ÙŠØ±Ø¬Ø¹ `null` | Ø¥Ù…Ø§ Ø¥Ø²Ø§Ù„Ø© ØªØ§Ù…Ø© Ù…Ø¹ ØªÙ†Ø¸ÙŠÙ Ø§Ù„Ø§Ø³ØªØ¯Ø¹Ø§Ø¡Ø§Øª Ø£Ùˆ Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„ØªÙ†ÙÙŠØ° Ø§Ù„ÙƒØ§Ù…Ù„ Ù…Ù† Ø§Ù„Ù†Ø³Ø® Ø§Ù„Ù…Ø±Ø¬Ø¹ÙŠØ© | ØªØ¬Ù†Ø¨ Ù…Ù„Ù Ù…ÙŠØª ÙˆØ¥Ø±Ø¬Ø§Ø¹ Ù…ÙŠØ²Ø© Ø§Ù„Ø®Ø±Ø§Ø¦Ø· Ø§Ù„Ù…Ø³Ø§Ù†Ø¯Ø© |
| `components/ChildAppView.tsx` | Ù†Ø³Ø®Ø© Ù…Ø®ØªØµØ±Ø© | Ø§Ø³ØªØ¹Ø§Ø¯Ø© flow Ø£Ø´Ù…Ù„: pairing token + onboarding + optional calculator shell mode + unlock flow | Ø§Ø³ØªØ±Ø¬Ø§Ø¹ Ø¹Ù…Ù‚ Ù…Ø³Ø§Ø± ØªØ·Ø¨ÙŠÙ‚ Ø§Ù„Ø·ÙÙ„ |

---

## 5) Ø§Ù„ÙˆØ¸Ø§Ø¦Ù (Functions) Ø§Ù„ØªÙŠ Ø³ÙŠØªÙ… ØªØ¹Ø¯ÙŠÙ„Ù‡Ø§ Ù…Ø¨Ø§Ø´Ø±Ø©

1. `App.tsx`
- `handleApplyMode`
- `handleSaveExecutionEvidence`
- `handleUpdateDeviceControls`
- `handleToggleDeviceLock`
- Ø§Ù„Ø³Ø¨Ø¨: Ø±Ø¨Ø· Ø§Ù„Ù…Ø­Ø±Ùƒ Ø§Ù„Ø­Ø§Ù„ÙŠ Ù…Ø¹ Ø§Ù„ÙˆØ­Ø¯Ø§Øª Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø©.

2. `components/PsychologicalInsightView.tsx`
- `buildSuggestedPlan`
- `runAutoExecutionPlan`
- `saveExecutionTimelineToVault`
- Ø§Ù„Ø³Ø¨Ø¨: Ø¬Ø¹Ù„ Ø®Ø·Ø© Ø§Ù„Ù†Ø¨Ø¶ Ø§Ù„Ù†ÙØ³ÙŠ ØªÙ†ØªØ¬ Ø¥Ø¬Ø±Ø§Ø¡Ø§Øª Ù…ØªÙˆØ§ÙÙ‚Ø© Ù…Ø¹ playbooks/custody/audit.

3. `components/LiveMonitorView.tsx`
- `startStream`
- `changeVideoSource`
- `changeAudioSource`
- `startPushToTalk`
- `stopPushToTalk`
- `toggleEmergencyLock`
- Ø§Ù„Ø³Ø¨Ø¨: Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„ØªØ­ÙƒÙ… Ø§Ù„Ø¹Ù…ÙŠÙ‚ Ø§Ù„Ù…Ø¨Ø§Ø´Ø± Ù…Ù† Ø¬Ù‡Ø§Ø² Ø§Ù„Ø·ÙÙ„.

4. `components/ModesView.tsx`
- `handleSaveMode`
- Ø§Ù„Ø³Ø¨Ø¨: ØªÙˆØ­ÙŠØ¯ Ù†Ù…ÙˆØ°Ø¬ Ø§Ù„Ø£ÙˆØ¶Ø§Ø¹ Ù…Ø¹ Ø§Ù„Ø­Ù‚ÙˆÙ„ Ø§Ù„Ù…ØªÙ‚Ø¯Ù…Ø© Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø©.

5. `components/SettingsView.tsx`
- `handleInjectMockData`
- `handleClearMockData`
- `handleSaveDeviceLink`
- Ø§Ù„Ø³Ø¨Ø¨: Ø¯Ø¹Ù… Ø§Ø®ØªØ¨Ø§Ø± ÙˆØ­Ø¯Ø§Øª Ø¬Ø¯ÙŠØ¯Ø© ÙˆØ±Ø¨Ø· Ø§Ù„Ø£Ø¬Ù‡Ø²Ø©/Ø§Ù„Ø¹Ù…Ù„ÙŠØ§Øª Ø§Ù„Ø­Ø³Ø§Ø³Ø©.

6. `components/EvidenceVaultView.tsx`
- `handleExport`
- `handleSave`
- `handleDelete`
- `clearAllFilters`
- Ø§Ù„Ø³Ø¨Ø¨: Ø±ÙØ¹ Ø§Ù„Ø®Ø²Ù†Ø© Ù…Ù† Ø¹Ø±Ø¶ Ø¨Ø³ÙŠØ· Ø¥Ù„Ù‰ Ù…Ù†Ø¸ÙˆÙ…Ø© ØªØªØ¨Ø¹/ØªØµØ¯ÙŠØ±/ØªØ­Ù‚Ù‚.

---

## 6) ØªØ±ØªÙŠØ¨ Ø§Ù„ØªØ¹Ø¯ÙŠÙ„ Ø§Ù„ØªÙØµÙŠÙ„ÙŠ Ø¹Ù„Ù‰ Ù…Ø³ØªÙˆÙ‰ Ø§Ù„ÙƒÙˆÙ…ÙŠØªØ§Øª

1. **Commit 1: Contracts + Flags**
- ØªØ¹Ø¯ÙŠÙ„: `types.ts`, `translations.ts`, `config/featureFlags.ts`, `constants.tsx`
- Ø§Ù„Ø³Ø¨Ø¨: ØªØ¬Ù‡ÙŠØ² Ø§Ù„Ø£Ø±Ø¶ÙŠØ© Ù‚Ø¨Ù„ Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø£ÙŠ Ø´Ø§Ø´Ø©.

2. **Commit 2: Data Services Baseline**
- ØªØ¹Ø¯ÙŠÙ„: `services/firestoreService.ts`, `services/mockDataService.ts`, `services/ruleEngineService.ts`
- Ø¥Ø¶Ø§ÙØ©: `services/forensicsService.ts`, `services/rbacService.ts`, `services/auditService.ts`, `services/backupService.ts`
- Ø§Ù„Ø³Ø¨Ø¨: Ø£ÙŠ UI Ù…Ø³ØªØ¹Ø§Ø¯ ÙŠØ­ØªØ§Ø¬ data contracts ÙˆØ®Ø¯Ù…Ø§Øª Ø¬Ø§Ù‡Ø²Ø©.

3. **Commit 3: App Integration Skeleton**
- ØªØ¹Ø¯ÙŠÙ„: `App.tsx`
- Ø¥Ø¶Ø§ÙØ© placeholders Ù„Ù„Ø´Ø§Ø´Ø§Øª Ø§Ù„Ù…Ø³ØªØ¹Ø§Ø¯Ø© Ø®Ù„Ù feature flags
- Ø§Ù„Ø³Ø¨Ø¨: Ø±Ø¨Ø· Ù…ØªØ­ÙƒÙ… Ù…Ø±ÙƒØ²ÙŠ Ù‚Ø¨Ù„ Ø¶Ø® ÙˆØ§Ø¬Ù‡Ø§Øª ÙƒØ«ÙŠØ±Ø©.

4. **Commit 4: Incident/Forensics UI Wave**
- Ø¥Ø¶Ø§ÙØ©: `components/IncidentWarRoom.tsx`, `components/ChainOfCustodyView.tsx`, `components/FamilyIncidentResponseView.tsx`, `components/ExportBundleModal.tsx`, `components/SystemSecurityReportView.tsx`, `components/VisualBenchmarkView.tsx`
- Ø§Ù„Ø³Ø¨Ø¨: Ø§Ø³ØªØ±Ø¬Ø§Ø¹ Ø£Ø¹Ù…Ù‚ Ø¬Ø²Ø¡ Ø¹Ù…Ù„ÙŠ ÙÙŠ Ø¥Ø¯Ø§Ø±Ø© Ø§Ù„Ø­ÙˆØ§Ø¯Ø« ÙˆØ§Ù„Ø£Ø¯Ù„Ø©.

5. **Commit 5: Defense/Playbook UI Wave**
- Ø¥Ø¶Ø§ÙØ©: `components/SafetyPlaybookHub.tsx`, `components/SafetyProtocolStudio.tsx`, `components/PlatformSOCView.tsx`, `components/parent/DefenseRulesView.tsx`, `components/parent/DefensePolicyView.tsx`, `components/parent/GeoFenceManager.tsx`
- Ø§Ù„Ø³Ø¨Ø¨: Ø¥ÙƒÙ…Ø§Ù„ Ø·Ø¨Ù‚Ø© Ø§Ù„Ù‚Ø±Ø§Ø± Ø§Ù„ÙˆÙ‚Ø§Ø¦ÙŠ Ø§Ù„ØªÙ„Ù‚Ø§Ø¦ÙŠ.

6. **Commit 6: Parent Ops Console Wave**
- Ø¥Ø¶Ø§ÙØ©: Ø¨Ù‚ÙŠØ© Ù…Ù„ÙØ§Øª `components/parent/*` Ø§Ù„Ù…Ø°ÙƒÙˆØ±Ø© ÙÙŠ Ø§Ù„Ù‚Ø³Ù… 4
- Ø§Ù„Ø³Ø¨Ø¨: ØªÙ‚Ø¯ÙŠÙ… ÙƒÙˆÙ†Ø³ÙˆÙ„ ØªØ´ØºÙŠÙ„ÙŠ Ù…ØªÙƒØ§Ù…Ù„ Ø¨Ø¯Ù„ Ø´Ø§Ø´Ø§Øª Ù…ØªÙØ±Ù‚Ø©.

7. **Commit 7: Step-Up Security Wave**
- Ø¥Ø¶Ø§ÙØ©: `components/stepup/StepUpModal.tsx`, `components/auth/StepUpGuard.tsx`
- ØªØ¹Ø¯ÙŠÙ„: `App.tsx`, `components/SettingsView.tsx`, `components/EvidenceVaultView.tsx`
- Ø§Ù„Ø³Ø¨Ø¨: Ø­Ù…Ø§ÙŠØ© Ø§Ù„Ø¹Ù…Ù„ÙŠØ§Øª Ø§Ù„Ø­Ø³Ø§Ø³Ø© Ù‚Ø¨Ù„ Ø§Ù„ØªÙØ¹ÙŠÙ„ Ø§Ù„Ø¹Ø§Ù….

8. **Commit 8: Upgrade Simplified Files**
- ØªØ¹Ø¯ÙŠÙ„: `services/MapView.tsx`, `components/ChildAppView.tsx`
- Ø§Ù„Ø³Ø¨Ø¨: Ø¥Ø²Ø§Ù„Ø©/ØªØ±Ù‚ÙŠØ© Ù†Ù‚Ø§Ø· Ø§Ù„Ø¶Ø¹Ù Ø§Ù„ÙˆØ¸ÙŠÙÙŠ.

9. **Commit 9: Hardening + Rules + Indexes**
- ØªØ¹Ø¯ÙŠÙ„: `firestore.rules`, `firestore.indexes.json`
- Ø§Ù„Ø³Ø¨Ø¨: Ù…Ù†Ø¹ Ø£Ø®Ø·Ø§Ø¡ Ø§Ù„ØµÙ„Ø§Ø­ÙŠØ§Øª ÙˆØ§Ù„Ø§Ø³ØªØ¹Ù„Ø§Ù…Ø§Øª Ø¨Ø¹Ø¯ Ø§Ù„Ø§Ø³ØªØ¹Ø§Ø¯Ø©.

10. **Commit 10: QA + Regression**
- ØªØ¹Ø¯ÙŠÙ„/Ø¥Ø¶Ø§ÙØ©: `tests/*`
- ØªØ´ØºÙŠÙ„: `npm run build`, `npm run test:run`
- Ø§Ù„Ø³Ø¨Ø¨: Ø¥ØºÙ„Ø§Ù‚ Ø§Ù„Ù…Ø®Ø§Ø·Ø± Ù‚Ø¨Ù„ Ø§Ù„Ø§Ù†ØªÙ‚Ø§Ù„ Ù„Ù„Ù…Ø±Ø­Ù„Ø© Ø§Ù„ØªØ§Ù„ÙŠØ©.

---

## 7) Ø§Ù„Ø£ÙˆÙ„ÙˆÙŠØ© Ø§Ù„Ø¹Ù…Ù„ÙŠØ© Ø§Ù„Ø¢Ù† (Ø§Ù„Ù€ Next 3 ØªÙ†ÙÙŠØ°Ù‹Ø§)
1. ØªÙ†ÙÙŠØ° Commit 1.
2. ØªÙ†ÙÙŠØ° Commit 2.
3. ØªÙ†ÙÙŠØ° Commit 3.

Ø¨Ø¹Ø¯ Ù‡Ø°Ù‡ Ø§Ù„Ø«Ù„Ø§Ø«Ø© Ø³Ù†ÙƒÙˆÙ† Ø¬Ø§Ù‡Ø²ÙŠÙ† Ù„Ø¨Ø¯Ø¡ Ø§Ø³ØªØ¹Ø§Ø¯Ø© Ø§Ù„ÙˆØ§Ø¬Ù‡Ø§Øª Ø§Ù„Ø«Ù‚ÙŠÙ„Ø© Ø¨Ø¯ÙˆÙ† Ø¥Ø¹Ø§Ø¯Ø© Ø¹Ù…Ù„.

