import { AlertSeverity, Category } from '../types';

export type PulseTimelineStatus = 'done' | 'error' | 'skipped' | 'info';

export interface PulseTimelineEntryInput {
  title: string;
  detail: string;
  status: PulseTimelineStatus;
  at: string;
}

export interface PulseExecutionEvidenceInput {
  childId: string;
  childName: string;
  scenarioId: string;
  scenarioTitle: string;
  severity: AlertSeverity;
  dominantPlatform: string;
  summary: { done: number; failed: number; skipped: number };
  timeline: PulseTimelineEntryInput[];
}

export interface PulseExecutionEvidenceBuildResult {
  compactSummary: string;
  timelineForLog: PulseTimelineEntryInput[];
  alertData: {
    type: 'PULSE_EXECUTION';
    childName: string;
    platform: string;
    content: string;
    category: Category;
    severity: AlertSeverity;
    suspectId: string;
    suspectUsername: string;
    aiAnalysis: string;
    actionTaken: string;
    latency: string;
    conversationLog: Array<{
      sender: string;
      text: string;
      time: string;
      isSuspect: boolean;
    }>;
  };
}

export const buildPulseExecutionEvidenceAlert = (
  payload: PulseExecutionEvidenceInput,
  lang: 'ar' | 'en'
): PulseExecutionEvidenceBuildResult => {
  const timelineForLog = [...payload.timeline]
    .sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime())
    .slice(-20);

  const compactSummary =
    lang === 'ar'
      ? `تم:${payload.summary.done} | تخطي:${payload.summary.skipped} | فشل:${payload.summary.failed}`
      : `Done:${payload.summary.done} | Skipped:${payload.summary.skipped} | Failed:${payload.summary.failed}`;

  const timelineText = timelineForLog
    .map((entry, idx) => `${idx + 1}. [${entry.status}] ${entry.title} - ${entry.detail}`)
    .join('\n');

  const aiAnalysis =
    lang === 'ar'
      ? `سيناريو: ${payload.scenarioTitle}\nالمنصة: ${payload.dominantPlatform}\nالملخص: ${compactSummary}\n\nTimeline:\n${timelineText}`
      : `Scenario: ${payload.scenarioTitle}\nPlatform: ${payload.dominantPlatform}\nSummary: ${compactSummary}\n\nTimeline:\n${timelineText}`;

  const alertData = {
    type: 'PULSE_EXECUTION' as const,
    childName: payload.childName,
    platform: `Pulse / ${payload.dominantPlatform}`,
    content:
      lang === 'ar'
        ? `تنفيذ خطة التوازن الرقمي (${payload.scenarioTitle})`
        : `Digital balance execution (${payload.scenarioTitle})`,
    category: Category.SAFE,
    severity: payload.severity,
    suspectId: `pulse-${payload.childId}`,
    suspectUsername: `pulse_${payload.scenarioId}`,
    aiAnalysis,
    actionTaken:
      lang === 'ar' ? 'حفظ سجل التنفيذ في الخزنة الجنائية' : 'Saved execution timeline in forensic vault',
    latency: compactSummary,
    conversationLog: timelineForLog.map((entry) => ({
      sender: entry.status === 'error' ? 'Engine Error' : 'Amanah Engine',
      text: `${entry.title}: ${entry.detail}`,
      time: new Date(entry.at).toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }),
      isSuspect: entry.status === 'error',
    })),
  };

  return {
    compactSummary,
    timelineForLog,
    alertData,
  };
};
